# Fusion analysis

## Decision

Project 2 is the base because its engine, renderer, input controller and play screen are more cohesive and scale to a larger world. Project 1 is the source of the product-completeness layer: lobby/chat/profile/leaderboard APIs, SSE transport, PWA offline shell and mobile-first lobby/control presentation.

## Kept from Project 2

- `src/game/engine.ts`: one fixed-step simulation, faster combat, tactical AI, pickups and multi-phase zone
- `src/game/render.ts`: camera, canvas effects, quality tiers and result presentation
- `src/game/input.ts`: keyboard, mouse, touch and gamepad normalization
- `src/components/GameClient.tsx`: solo/offline loop, prediction, smoothing and responsive play HUD
- `src/server/rooms.ts`: database-backed room simulation, bot fill, reconnect grace and rematch

## Integrated from Project 1

- social API surface: leaderboard and profile summaries
- room event stream endpoint for SSE-compatible clients
- offline/PWA shell
- explicit simulation smoke test and production documentation
- room/chat/ready/rematch capabilities retained through the more complete room model

## Intentionally not copied

- Project 1's smaller duplicate simulation (`src/game/core/sim.ts`) is not kept as a second engine.
- Project 1's renderer/input stack is not duplicated; Project 2's stack is the single client implementation.
- Old route names that would create two competing room protocols are not exposed.

## Validation

- TypeScript typecheck: pass
- Simulation smoke test: pass after making the test tolerant of normal AI elimination
- Production build: run with `DATABASE_URL` configured
- Lint: configured for the intentionally mutable 60 FPS render-loop refs
