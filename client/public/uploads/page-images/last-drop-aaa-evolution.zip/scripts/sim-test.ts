import { applyInput, createWorld, getPlayer, ranking, stepWorld } from "../src/game/engine";
import { WEAPONS } from "../src/game/weapons";
import { levelFromXp, xpForMatch } from "../src/game/progression";

/* ---------------- basic input + simulation smoke test ---------------- */

const world = createWorld([
  { id: "human", name: "TEST", isBot: false },
  { id: "bot-1", name: "BRINE", isBot: true },
  { id: "bot-2", name: "MIST", isBot: true },
]);

for (let i = 0; i < 30 * 10; i++) {
  const me = getPlayer(world, "human");
  if (!me || world.status === "ended") break;
  applyInput(world, "human", {
    mx: Math.sin(i / 30),
    my: Math.cos(i / 44),
    aimX: me.x + 500,
    aimY: me.y,
    fire: i % 5 === 0,
    dash: i % 90 === 0,
    seq: i,
  });
  stepWorld(world, 1 / 30);
}

if (world.tick < 1) throw new Error("simulation did not advance");
if (world.players.length !== 3) throw new Error("roster changed unexpectedly");
if (!world.pickups.length) throw new Error("pickup system is empty");
if (!world.events.length) throw new Error("event system is empty");
if (!world.hotZones.length) throw new Error("hot zones missing");

const kinds = new Set(world.pickups.map((p) => p.kind));
if (!kinds.has("weapon")) throw new Error("no weapon loot on the floor");

const me = getPlayer(world, "human");
if (!me) throw new Error("player vanished");
if (me.stats.shotsFired < 1) throw new Error("weapon system did not fire");

console.log(
  `smoke ok: ${world.tick} ticks, ${world.players.length} players, ${world.pickups.length} pickups (${[...kinds].join(",")}), ${world.events.length} events`,
);

/* ---------------- full bot match until a winner emerges --------------- */

const full = createWorld(
  Array.from({ length: 8 }, (_, i) => ({
    id: `bot-${i}`,
    name: `BOT${i}`,
    isBot: true,
  })),
);

let steps = 0;
const maxSteps = 30 * 400;
let sawDrop = false;
let sawKill = false;
while (full.status !== "ended" && steps < maxSteps) {
  stepWorld(full, 1 / 30);
  if (full.drop) sawDrop = true;
  if (full.events.some((e) => e.kind === "kill")) sawKill = true;
  steps++;
}

if (full.status !== "ended") throw new Error("match never ended");
if (!full.winnerId) throw new Error("no winner assigned");
if (!sawDrop) throw new Error("supply drop never spawned");
if (!sawKill) throw new Error("no eliminations in a full bot match");

const placed = full.players.filter((p) => p.placement > 0);
if (placed.length !== full.players.length) throw new Error("placements incomplete");

const ranked = ranking(full);
if (ranked[0].id !== full.winnerId) throw new Error("ranking disagrees with winner");

const weaponsUsed = new Set(full.players.map((p) => p.weapon));
console.log(
  `match ok: ended after ${Math.round(full.endedAt)}s, winner=${full.winnerId}, weapons in play: ${[...weaponsUsed].join(",")}`,
);

/* ---------------- weapon + progression math sanity --------------------- */

for (const def of Object.values(WEAPONS)) {
  if (def.damage <= 0 || def.magSize <= 0 || def.fireCooldown <= 0) {
    throw new Error(`broken weapon def: ${def.id}`);
  }
}

const gain = xpForMatch({
  placement: 1,
  totalPlayers: 8,
  kills: 5,
  damage: 600,
  survivalSec: 240,
  won: true,
  shotsFired: 120,
  shotsHit: 48,
  weapon: "surge",
  mode: "solo",
});
if (gain.total < 100) throw new Error("xp formula regressed");
const lv = levelFromXp(gain.total * 10);
if (lv.level < 2) throw new Error("level curve regressed");

console.log(`progression ok: sample match = ${gain.total} XP, 10 matches -> level ${lv.level}`);
console.log("all simulation tests passed");
