// Shared game types — used by both the client (browser) and the authoritative
// server simulation. Keep these free of DOM / Node specific types.

import type { Rarity, WeaponId } from "./weapons";

export type Vec = { x: number; y: number };

export type Input = {
  /** normalized movement direction, -1..1 */
  mx: number;
  my: number;
  /** world-space aim point */
  aimX: number;
  aimY: number;
  fire: boolean;
  dash: boolean;
  seq: number;
};

export const EMPTY_INPUT: Input = {
  mx: 0,
  my: 0,
  aimX: 0,
  aimY: 0,
  fire: false,
  dash: false,
  seq: 0,
};

export type BotPersona = "aggressive" | "defensive" | "tactical";

export type AIState = {
  targetId: string | null;
  strafe: number;
  retargetIn: number;
  jitter: number;
  persona: BotPersona;
  /** time left of heightened alert after taking damage */
  alert: number;
  /** id of pickup the bot committed to */
  lootId: number | null;
  /** how long the bot keeps fleeing */
  fleeing: number;
  /** aim error in radians, personality + situation driven */
  aimErr: number;
};

/** per-match combat statistics, tracked server-side */
export type MatchStats = {
  damageDealt: number;
  shotsFired: number;
  shotsHit: number;
  timeAlive: number;
  pickups: number;
};

export type Player = {
  id: string;
  name: string;
  color: string;
  isBot: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  hp: number;
  shield: number;
  alive: boolean;
  /** rounds left in the magazine of the equipped weapon */
  ammo: number;
  /** equipped weapon + rarity */
  weapon: WeaponId;
  rarity: Rarity;
  /** seconds of reload remaining (0 = ready) */
  reload: number;
  fireCd: number;
  dashCd: number;
  dashTime: number;
  kills: number;
  score: number;
  /** 1 = winner, higher = eliminated earlier */
  placement: number;
  hitFlash: number;
  protect: number;
  connected: boolean;
  input: Input;
  ai: AIState;
  stats: MatchStats;
};

export type Bullet = {
  id: number;
  ownerId: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  r: number;
  damage: number;
  color: string;
  weapon: WeaponId;
  /** explosion radius on impact (0 = none) */
  blast: number;
  knock: number;
};

export type PickupKind = "water" | "medkit" | "shield" | "ammo" | "weapon";

export type Pickup = {
  id: number;
  kind: PickupKind;
  x: number;
  y: number;
  r: number;
  bob: number;
  /** only for kind === "weapon" */
  weapon?: WeaponId;
  rarity?: Rarity;
};

export type HotZone = { x: number; y: number; r: number };

export type SupplyDrop = {
  x: number;
  y: number;
  /** seconds until it lands */
  fall: number;
  landed: boolean;
  taken: boolean;
};

export type WorldEventKind =
  | "start"
  | "hit"
  | "death"
  | "kill"
  | "pickup"
  | "shoot"
  | "dash"
  | "reload"
  | "explosion"
  | "airdrop"
  | "airdrop_land"
  | "zone";

export type WorldEvent = {
  id: number;
  kind: WorldEventKind;
  x: number;
  y: number;
  /** angle / magnitude */
  a: number;
  /** primary player id (victim for hit/kill) */
  p: string;
  /** strength 0..1 */
  s: number;
  /** secondary id — attacker for hit/kill, weapon id for shoot/pickup */
  q?: string;
  /** numeric payload — damage amount for hit events */
  v?: number;
};

export type Zone = {
  x: number;
  y: number;
  r: number;
  targetR: number;
  phase: number;
  timer: number;
  shrinking: boolean;
};

export type World = {
  tick: number;
  time: number;
  acc: number;
  status: "countdown" | "playing" | "ended";
  countdown: number;
  players: Player[];
  bullets: Bullet[];
  pickups: Pickup[];
  events: WorldEvent[];
  eventSeq: number;
  nextId: number;
  zone: Zone;
  hotZones: HotZone[];
  drop: SupplyDrop | null;
  /** seconds until the next supply drop (-1 = no more) */
  nextDropIn: number;
  winnerId: string | null;
  endedAt: number;
  timeLimit: number;
};

export type LobbyPlayer = {
  playerId: string;
  name: string;
  isHost: boolean;
  isReady: boolean;
  isBot: boolean;
  connection: "online" | "grace" | "gone";
};

export type ChatMessage = {
  id: string;
  playerId: string;
  name: string;
  body: string;
  at: number;
};

export type LobbyState = {
  code: string;
  hostId: string;
  status: "lobby" | "countdown" | "playing" | "ended";
  players: LobbyPlayer[];
  chat: ChatMessage[];
  fillBots: boolean;
  maxPlayers: number;
  updatedAt: number;
};

export type SyncResponse = {
  ok: boolean;
  error?: string;
  world: World | null;
  lobby: LobbyState | null;
  serverTime: number;
  ping: number;
};
