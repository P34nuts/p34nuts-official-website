/**
 * Weapon system — data-driven definitions shared by client and server.
 * Every weapon is a WeaponDef; rarity applies stat multipliers on top.
 */

export type WeaponType =
  | "pistol"
  | "ar"
  | "shotgun"
  | "smg"
  | "sniper"
  | "special";

export type WeaponId =
  | "hydro"
  | "surge"
  | "tide"
  | "mist"
  | "longdrop"
  | "storm";

export type Rarity = "common" | "rare" | "epic" | "legendary";

export const RARITY_ORDER: Rarity[] = ["common", "rare", "epic", "legendary"];

export const RARITY_COLOR: Record<Rarity, string> = {
  common: "#9FB4BC",
  rare: "#3D9BFF",
  epic: "#C79BFF",
  legendary: "#FFC53D",
};

export const RARITY_LABEL: Record<Rarity, string> = {
  common: "Common",
  rare: "Rare",
  epic: "Epic",
  legendary: "Legendary",
};

/** damage / handling multipliers per rarity */
export const RARITY_MULT: Record<Rarity, { dmg: number; reload: number }> = {
  common: { dmg: 1, reload: 1 },
  rare: { dmg: 1.12, reload: 0.92 },
  epic: { dmg: 1.25, reload: 0.84 },
  legendary: { dmg: 1.4, reload: 0.74 },
};

export type WeaponDef = {
  id: WeaponId;
  name: string;
  type: WeaponType;
  /** damage per projectile (before rarity multiplier) */
  damage: number;
  /** projectiles per trigger pull */
  pellets: number;
  /** seconds between shots */
  fireCooldown: number;
  /** radians of random spread per projectile */
  spread: number;
  /** projectile speed, world units / s */
  speed: number;
  /** projectile lifetime in seconds (range = speed * life) */
  life: number;
  magSize: number;
  reloadTime: number;
  /** knockback applied on hit */
  knock: number;
  /** explosion radius (0 = no blast) */
  blast: number;
  /** projectile radius */
  bulletR: number;
  /** sound key suffix */
  sfx: "shoot" | "shoot_ar" | "shoot_shotgun" | "shoot_smg" | "shoot_sniper" | "shoot_special";
  /** short HUD hint */
  tag: string;
};

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  hydro: {
    id: "hydro",
    name: "Hydro Pistol",
    type: "pistol",
    damage: 13,
    pellets: 1,
    fireCooldown: 0.24,
    spread: 0.028,
    speed: 1040,
    life: 0.95,
    magSize: 12,
    reloadTime: 1.1,
    knock: 110,
    blast: 0,
    bulletR: 8,
    sfx: "shoot",
    tag: "Sidearm",
  },
  surge: {
    id: "surge",
    name: "Surge Rifle",
    type: "ar",
    damage: 10,
    pellets: 1,
    fireCooldown: 0.135,
    spread: 0.045,
    speed: 1140,
    life: 1.05,
    magSize: 30,
    reloadTime: 1.65,
    knock: 95,
    blast: 0,
    bulletR: 8,
    sfx: "shoot_ar",
    tag: "Assault",
  },
  tide: {
    id: "tide",
    name: "Tidebreaker",
    type: "shotgun",
    damage: 7,
    pellets: 6,
    fireCooldown: 0.82,
    spread: 0.19,
    speed: 920,
    life: 0.4,
    magSize: 5,
    reloadTime: 1.9,
    knock: 230,
    blast: 0,
    bulletR: 7,
    sfx: "shoot_shotgun",
    tag: "Close range",
  },
  mist: {
    id: "mist",
    name: "Mist SMG",
    type: "smg",
    damage: 6.5,
    pellets: 1,
    fireCooldown: 0.074,
    spread: 0.085,
    speed: 990,
    life: 0.78,
    magSize: 34,
    reloadTime: 1.45,
    knock: 55,
    blast: 0,
    bulletR: 6.5,
    sfx: "shoot_smg",
    tag: "Spray",
  },
  longdrop: {
    id: "longdrop",
    name: "Longdrop",
    type: "sniper",
    damage: 46,
    pellets: 1,
    fireCooldown: 1.3,
    spread: 0.004,
    speed: 1900,
    life: 1.35,
    magSize: 3,
    reloadTime: 2.2,
    knock: 280,
    blast: 0,
    bulletR: 9,
    sfx: "shoot_sniper",
    tag: "Precision",
  },
  storm: {
    id: "storm",
    name: "Stormcaller",
    type: "special",
    damage: 26,
    pellets: 1,
    fireCooldown: 0.95,
    spread: 0.02,
    speed: 780,
    life: 1.5,
    magSize: 4,
    reloadTime: 2.25,
    knock: 180,
    blast: 130,
    bulletR: 12,
    sfx: "shoot_special",
    tag: "Explosive",
  },
};

/** ids that can spawn as floor loot (special is airdrop only) */
export const FLOOR_WEAPONS: WeaponId[] = ["surge", "tide", "mist", "longdrop"];

export function rarityRank(r: Rarity): number {
  return RARITY_ORDER.indexOf(r);
}

export function weaponDamage(id: WeaponId, rarity: Rarity): number {
  return WEAPONS[id].damage * RARITY_MULT[rarity].dmg;
}

export function weaponReload(id: WeaponId, rarity: Rarity): number {
  return WEAPONS[id].reloadTime * RARITY_MULT[rarity].reload;
}

/** effective range used by AI decision making */
export function weaponRange(id: WeaponId): number {
  const d = WEAPONS[id];
  return Math.min(1100, d.speed * d.life * 0.82);
}

/** roll a floor-loot rarity. lateGame shifts quality upward. */
export function rollRarity(rand: () => number, lateGame: boolean): Rarity {
  const t = rand();
  if (lateGame) {
    if (t < 0.4) return "common";
    if (t < 0.75) return "rare";
    if (t < 0.95) return "epic";
    return "legendary";
  }
  if (t < 0.56) return "common";
  if (t < 0.85) return "rare";
  if (t < 0.98) return "epic";
  return "legendary";
}

export function rollFloorWeapon(rand: () => number): WeaponId {
  return FLOOR_WEAPONS[Math.floor(rand() * FLOOR_WEAPONS.length)];
}
