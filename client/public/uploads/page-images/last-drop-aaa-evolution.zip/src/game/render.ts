import { CFG } from "./engine";
import { RARITY_COLOR, WEAPONS } from "./weapons";
import type { Player, World, WorldEvent } from "./types";

export type Quality = "low" | "medium" | "high";

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind: "spark" | "drop" | "ring" | "smoke" | "text" | "shock";
  text?: string;
};

const INK = "#101E28";
const PAPER = "#F2EDE4";
const CYAN = "#00C2D1";
const ORANGE = "#FF4E20";
const GOLD = "#FFC53D";

export class Renderer {
  particles: Particle[] = [];
  shake = 0;
  /** hit-marker pulse for the local player, 0..1 */
  hitMarker = 0;
  private grain: HTMLCanvasElement | null = null;
  private grainPattern: CanvasPattern | null = null;
  private vignette: { key: string; grad: CanvasGradient } | null = null;
  private flash = 0;
  private localId = "";
  showDamageNumbers = true;

  constructor(private quality: Quality = "high", private reducedMotion = false) {}

  setQuality(q: Quality) {
    this.quality = q;
    this.grain = null;
    this.grainPattern = null;
    this.vignette = null;
  }
  setReducedMotion(v: boolean) {
    this.reducedMotion = v;
  }
  setLocalId(id: string) {
    this.localId = id;
  }

  private maxParticles() {
    if (this.reducedMotion) return 40;
    return this.quality === "low" ? 90 : this.quality === "medium" ? 220 : 420;
  }

  private emit(p: Particle) {
    if (this.particles.length >= this.maxParticles()) this.particles.shift();
    this.particles.push(p);
  }

  burst(
    x: number,
    y: number,
    color: string,
    count: number,
    speed: number,
    kind: Particle["kind"] = "spark",
  ) {
    const n = this.reducedMotion ? Math.ceil(count * 0.35) : count;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.35 + Math.random() * 0.9);
      this.emit({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0,
        maxLife: 0.3 + Math.random() * 0.5,
        size: 2 + Math.random() * 5,
        color,
        kind,
      });
    }
  }

  ring(x: number, y: number, color: string, size = 30) {
    this.emit({
      x,
      y,
      vx: 0,
      vy: 0,
      life: 0,
      maxLife: 0.42,
      size,
      color,
      kind: "ring",
    });
  }

  damageNumber(x: number, y: number, amount: number, color: string) {
    if (!this.showDamageNumbers || this.quality === "low") return;
    this.emit({
      x: x + (Math.random() - 0.5) * 24,
      y: y - 26,
      vx: (Math.random() - 0.5) * 50,
      vy: -120,
      life: 0,
      maxLife: 0.75,
      size: amount >= 30 ? 22 : 16,
      color,
      kind: "text",
      text: String(Math.max(1, Math.round(amount))),
    });
  }

  addShake(amount: number) {
    if (this.reducedMotion) return;
    this.shake = Math.min(26, this.shake + amount);
  }

  flashScreen(amount = 0.35) {
    this.flash = Math.max(this.flash, this.reducedMotion ? 0.12 : amount);
  }

  /** Consume world events (already filtered by the caller) into particles. */
  handleEvent(e: WorldEvent, world: World) {
    const target = world.players.find((p) => p.id === e.p);
    switch (e.kind) {
      case "hit": {
        this.burst(e.x, e.y, target?.color ?? ORANGE, 10, 260, "spark");
        if (e.v && e.v >= 1) {
          const mine = e.q === this.localId;
          this.damageNumber(e.x, e.y, e.v, mine ? "#FFFFFF" : "rgba(255,197,61,0.9)");
          if (mine) this.hitMarker = 1;
        }
        if (e.p === this.localId) this.addShake(3.2 * e.s);
        break;
      }
      case "death":
        this.burst(e.x, e.y, target?.color ?? CYAN, 34, 420, "drop");
        this.ring(e.x, e.y, ORANGE, 60);
        this.addShake(e.p === this.localId ? 14 : 6);
        if (e.p === this.localId) this.flashScreen(0.3);
        break;
      case "explosion":
        this.burst(e.x, e.y, GOLD, 26, 520, "spark");
        this.burst(e.x, e.y, ORANGE, 14, 320, "smoke");
        this.emit({
          x: e.x,
          y: e.y,
          vx: 0,
          vy: 0,
          life: 0,
          maxLife: 0.5,
          size: 120 * e.s,
          color: GOLD,
          kind: "shock",
        });
        this.addShake(8 * e.s);
        break;
      case "pickup":
        this.burst(e.x, e.y, e.q === "airdrop" ? GOLD : CYAN, 12, 210, "drop");
        this.ring(e.x, e.y, e.q === "airdrop" ? GOLD : CYAN, 34);
        break;
      case "shoot": {
        // muzzle flash directional burst
        const wid = e.q ? WEAPONS[e.q as keyof typeof WEAPONS] : undefined;
        const count = wid?.type === "shotgun" ? 8 : 3;
        for (let i = 0; i < count; i++) {
          const a = e.a + (Math.random() - 0.5) * 0.7;
          const s = 180 + Math.random() * 160;
          this.emit({
            x: e.x + Math.cos(e.a) * 34,
            y: e.y + Math.sin(e.a) * 34,
            vx: Math.cos(a) * s,
            vy: Math.sin(a) * s,
            life: 0,
            maxLife: 0.14 + Math.random() * 0.12,
            size: 2.5 + Math.random() * 3,
            color: wid?.blast ? GOLD : "#FFE9B8",
            kind: "spark",
          });
        }
        if (e.p === this.localId && wid?.type === "sniper") this.addShake(5);
        if (e.p === this.localId && wid?.type === "shotgun") this.addShake(4);
        break;
      }
      case "dash":
        this.burst(e.x, e.y, target?.color ?? CYAN, 12, 200, "smoke");
        break;
      case "zone":
        this.ring(e.x, e.y, ORANGE, 320);
        break;
      case "airdrop":
        this.ring(e.x, e.y, GOLD, 220);
        break;
      case "airdrop_land":
        this.burst(e.x, e.y, GOLD, 22, 360, "spark");
        this.ring(e.x, e.y, GOLD, 90);
        this.addShake(5);
        break;
      case "start":
        this.flashScreen(0.3);
        break;
    }
  }

  private updateParticles(dt: number) {
    for (const p of this.particles) {
      p.life += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.kind === "text") {
        p.vy += 60 * dt;
      } else {
        p.vx *= 1 - Math.min(0.9, dt * 2.2);
        p.vy *= 1 - Math.min(0.9, dt * 2.2);
        if (p.kind !== "ring" && p.kind !== "shock") p.vy += 120 * dt;
      }
    }
    if (this.particles.length) {
      this.particles = this.particles.filter((p) => p.life < p.maxLife);
    }
    this.shake *= 1 - Math.min(1, dt * 6);
    this.flash *= 1 - Math.min(1, dt * 3.4);
    this.hitMarker = Math.max(0, this.hitMarker - dt * 4.5);
  }

  private makeGrain() {
    const c = document.createElement("canvas");
    c.width = 180;
    c.height = 180;
    const g = c.getContext("2d");
    if (!g) return c;
    const img = g.createImageData(180, 180);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = 120 + Math.random() * 135;
      img.data[i] = v;
      img.data[i + 1] = v;
      img.data[i + 2] = v;
      img.data[i + 3] = Math.random() * 26;
    }
    g.putImageData(img, 0, 0);
    return c;
  }

  draw(
    ctx: CanvasRenderingContext2D,
    world: World,
    width: number,
    height: number,
    focus: { x: number; y: number },
    dt: number,
    localId: string,
  ) {
    this.localId = localId;
    this.updateParticles(dt);

    const zoom = Math.max(
      0.42,
      Math.min(1.05, Math.min(width, height) / 760),
    );

    let camX = focus.x;
    let camY = focus.y;
    if (this.shake > 0.2) {
      camX += (Math.random() - 0.5) * this.shake;
      camY += (Math.random() - 0.5) * this.shake;
    }

    const halfW = width / 2 / zoom;
    const halfH = height / 2 / zoom;
    camX = Math.max(halfW * 0.35, Math.min(CFG.worldW - halfW * 0.35, camX));
    camY = Math.max(halfH * 0.35, Math.min(CFG.worldH - halfH * 0.35, camY));

    const toScreen = (x: number, y: number) => ({
      x: (x - camX) * zoom + width / 2,
      y: (y - camY) * zoom + height / 2,
    });

    ctx.save();
    ctx.fillStyle = "#06171D";
    ctx.fillRect(0, 0, width, height);

    // --- arena floor -------------------------------------------------
    const tl = toScreen(0, 0);
    const br = toScreen(CFG.worldW, CFG.worldH);
    ctx.fillStyle = "#0C2A33";
    ctx.fillRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);

    // hot zones — loot-rich districts
    for (const hz of world.hotZones) {
      const s = toScreen(hz.x, hz.y);
      const r = hz.r * zoom;
      ctx.beginPath();
      ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,194,209,0.05)";
      ctx.fill();
      ctx.setLineDash([10, 14]);
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = "rgba(0,194,209,0.18)";
      ctx.stroke();
      ctx.setLineDash([]);
    }

    const grid = 200;
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(46,125,140,0.22)";
    ctx.beginPath();
    for (let x = 0; x <= CFG.worldW; x += grid) {
      const s = toScreen(x, 0);
      ctx.moveTo(s.x, tl.y);
      ctx.lineTo(s.x, br.y);
    }
    for (let y = 0; y <= CFG.worldH; y += grid) {
      const s = toScreen(0, y);
      ctx.moveTo(tl.x, s.y);
      ctx.lineTo(br.x, s.y);
    }
    ctx.stroke();

    // world border
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(0,194,209,0.5)";
    ctx.strokeRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);

    // --- bleach outside the pool -------------------------------------
    const zc = toScreen(world.zone.x, world.zone.y);
    const zr = world.zone.r * zoom;
    ctx.beginPath();
    ctx.rect(0, 0, width, height);
    ctx.arc(zc.x, zc.y, zr, 0, Math.PI * 2, true);
    ctx.fillStyle = "rgba(242,237,228,0.9)";
    ctx.fill();

    ctx.save();
    ctx.beginPath();
    ctx.arc(zc.x, zc.y, zr, 0, Math.PI * 2);
    ctx.lineWidth = 26;
    ctx.strokeStyle = "rgba(255,78,32,0.16)";
    ctx.stroke();
    ctx.lineWidth = 7;
    ctx.strokeStyle = ORANGE;
    ctx.setLineDash([26, 18]);
    ctx.lineDashOffset = -world.time * 26;
    ctx.stroke();
    ctx.restore();

    ctx.beginPath();
    ctx.arc(zc.x, zc.y, zr, 0, Math.PI * 2);
    ctx.lineWidth = 5;
    ctx.strokeStyle = CYAN;
    ctx.shadowColor = "rgba(0,194,209,0.9)";
    ctx.shadowBlur = 26;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // --- supply drop ---------------------------------------------------
    if (world.drop && !world.drop.taken) {
      const s = toScreen(world.drop.x, world.drop.y);
      const d = world.drop;
      // landing marker
      ctx.beginPath();
      ctx.arc(s.x, s.y, 34 * zoom, 0, Math.PI * 2);
      ctx.setLineDash([8, 8]);
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = GOLD;
      ctx.stroke();
      ctx.setLineDash([]);
      if (!d.landed) {
        // crate falling from the sky with a drag line
        const t = d.fall / CFG.dropFallTime;
        const fy = s.y - t * 480 * zoom;
        ctx.strokeStyle = "rgba(255,197,61,0.35)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(s.x, fy);
        ctx.lineTo(s.x, s.y);
        ctx.stroke();
        drawCrate(ctx, s.x, fy, 20 * zoom, world.time);
      } else {
        drawCrate(ctx, s.x, s.y, 22 * zoom, world.time);
        // beacon
        ctx.beginPath();
        ctx.arc(s.x, s.y, (30 + Math.sin(world.time * 5) * 8) * zoom, 0, Math.PI * 2);
        ctx.lineWidth = 2;
        ctx.strokeStyle = `rgba(255,197,61,${0.5 + Math.sin(world.time * 5) * 0.25})`;
        ctx.stroke();
      }
    }

    // --- pickups -----------------------------------------------------
    for (const pk of world.pickups) {
      const s = toScreen(pk.x, pk.y);
      if (s.x < -60 || s.y < -60 || s.x > width + 60 || s.y > height + 60) continue;
      const bob = Math.sin(pk.bob) * 3 * zoom;
      const r = pk.r * zoom;
      switch (pk.kind) {
        case "water":
          drawDroplet(ctx, s.x, s.y + bob, r, "rgba(0,194,209,0.85)");
          break;
        case "medkit": {
          ctx.fillStyle = "rgba(61,214,140,0.9)";
          ctx.shadowColor = "rgba(61,214,140,0.7)";
          ctx.shadowBlur = 14;
          ctx.fillRect(s.x - r * 0.8, s.y - r * 0.8 + bob, r * 1.6, r * 1.6);
          ctx.shadowBlur = 0;
          ctx.fillStyle = "#06171D";
          ctx.fillRect(s.x - r * 0.5, s.y - r * 0.14 + bob, r, r * 0.28);
          ctx.fillRect(s.x - r * 0.14, s.y - r * 0.5 + bob, r * 0.28, r);
          break;
        }
        case "shield": {
          ctx.beginPath();
          for (let i = 0; i < 6; i++) {
            const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
            const px = s.x + Math.cos(a) * r * 0.9;
            const py = s.y + Math.sin(a) * r * 0.9 + bob;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fillStyle = "rgba(111,168,255,0.85)";
          ctx.shadowColor = "rgba(111,168,255,0.8)";
          ctx.shadowBlur = 14;
          ctx.fill();
          ctx.shadowBlur = 0;
          ctx.lineWidth = 1.6;
          ctx.strokeStyle = "rgba(242,237,228,0.85)";
          ctx.stroke();
          break;
        }
        case "ammo": {
          ctx.fillStyle = "rgba(242,237,228,0.88)";
          ctx.shadowColor = "rgba(242,237,228,0.5)";
          ctx.shadowBlur = 10;
          ctx.fillRect(s.x - r * 0.7, s.y - r * 0.55 + bob, r * 1.4, r * 1.1);
          ctx.shadowBlur = 0;
          ctx.fillStyle = "#0C2A33";
          for (let i = -1; i <= 1; i++) {
            ctx.fillRect(s.x + i * r * 0.36 - r * 0.09, s.y - r * 0.3 + bob, r * 0.18, r * 0.6);
          }
          break;
        }
        case "weapon": {
          const color = RARITY_COLOR[pk.rarity ?? "common"];
          // rarity glow pad
          ctx.beginPath();
          ctx.arc(s.x, s.y + bob, r * 1.25, 0, Math.PI * 2);
          ctx.fillStyle = `${color}22`;
          ctx.fill();
          ctx.beginPath();
          ctx.arc(s.x, s.y + bob, r * 1.25, 0, Math.PI * 2);
          ctx.lineWidth = 2;
          ctx.strokeStyle = color;
          ctx.globalAlpha = 0.65 + Math.sin(pk.bob * 2) * 0.2;
          ctx.stroke();
          ctx.globalAlpha = 1;
          // stylized gun silhouette
          ctx.save();
          ctx.translate(s.x, s.y + bob);
          ctx.rotate(-0.5);
          ctx.fillStyle = color;
          ctx.shadowColor = color;
          ctx.shadowBlur = 12;
          ctx.fillRect(-r * 0.75, -r * 0.18, r * 1.5, r * 0.36);
          ctx.fillRect(-r * 0.25, 0, r * 0.3, r * 0.55);
          ctx.restore();
          ctx.shadowBlur = 0;
          break;
        }
      }
    }

    // --- bullets -----------------------------------------------------
    for (const b of world.bullets) {
      const s = toScreen(b.x, b.y);
      const ang = Math.atan2(b.vy, b.vx);
      const def = WEAPONS[b.weapon];
      const len = (def.type === "sniper" ? 30 : 17) * zoom;
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(ang);
      const grad = ctx.createLinearGradient(-len, 0, len * 0.6, 0);
      grad.addColorStop(0, "rgba(255,255,255,0)");
      grad.addColorStop(1, b.color);
      ctx.fillStyle = grad;
      ctx.fillRect(-len, -b.r * zoom * 0.55, len * 1.7, b.r * zoom * 1.1);
      ctx.fillStyle = b.blast > 0 ? GOLD : "#FFFFFF";
      ctx.beginPath();
      ctx.arc(len * 0.55, 0, b.r * zoom * 0.45, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // --- players -----------------------------------------------------
    for (const p of world.players) {
      if (!p.alive) continue;
      const s = toScreen(p.x, p.y);
      if (s.x < -120 || s.y < -120 || s.x > width + 120 || s.y > height + 120) continue;
      const r = CFG.playerRadius * zoom;
      const isLocal = p.id === localId;

      ctx.beginPath();
      ctx.ellipse(s.x, s.y + r * 0.75, r * 0.95, r * 0.42, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(4,18,24,0.32)";
      ctx.fill();

      const speed = Math.hypot(p.vx, p.vy);
      const dirAng = speed > 30 ? Math.atan2(p.vy, p.vx) : p.angle;
      const tail = Math.min(1.5, 0.25 + speed / 420);

      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(dirAng);
      ctx.beginPath();
      ctx.moveTo(-r * (1.1 + tail), 0);
      ctx.bezierCurveTo(-r * 0.65, -r * 0.95, r * 1.02, -r * 0.82, r * 1.02, 0);
      ctx.bezierCurveTo(r * 1.02, r * 0.82, -r * 0.65, r * 0.95, -r * (1.1 + tail), 0);
      ctx.fillStyle = p.hitFlash > 0 ? "#FFFFFF" : p.color;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = INK;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(r * 0.12, -r * 0.3, r * 0.3, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.fill();
      ctx.restore();

      // weapon barrel — length and color based on the equipped weapon
      const def = WEAPONS[p.weapon];
      const barrelLen = def.type === "sniper" ? 2.15 : def.type === "shotgun" ? 1.5 : 1.7;
      ctx.beginPath();
      ctx.moveTo(s.x + Math.cos(p.angle) * r * 0.6, s.y + Math.sin(p.angle) * r * 0.6);
      ctx.lineTo(
        s.x + Math.cos(p.angle) * r * barrelLen,
        s.y + Math.sin(p.angle) * r * barrelLen,
      );
      ctx.lineWidth = def.type === "sniper" ? 3 : def.type === "shotgun" ? 6 : 4;
      ctx.strokeStyle = isLocal ? "#FFFFFF" : RARITY_COLOR[p.rarity];
      ctx.stroke();

      // shield aura
      if (p.shield > 0) {
        ctx.beginPath();
        ctx.arc(s.x, s.y, r * 1.45, 0, Math.PI * 2);
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = `rgba(111,168,255,${0.25 + 0.4 * (p.shield / CFG.shieldMax)})`;
        ctx.stroke();
      }

      if (p.protect > 0) {
        ctx.beginPath();
        ctx.arc(s.x, s.y, r * 1.75, 0, Math.PI * 2);
        ctx.lineWidth = 2;
        ctx.strokeStyle = `rgba(255,255,255,${0.25 + 0.35 * Math.abs(Math.sin(world.time * 6))})`;
        ctx.stroke();
      }

      // reload spinner
      if (p.reload > 0) {
        const total = WEAPONS[p.weapon].reloadTime;
        const t = 1 - p.reload / Math.max(0.2, total);
        ctx.beginPath();
        ctx.arc(s.x, s.y, r * 1.28, -Math.PI / 2, -Math.PI / 2 + t * Math.PI * 2);
        ctx.lineWidth = 3;
        ctx.strokeStyle = "rgba(255,197,61,0.85)";
        ctx.stroke();
      }

      const labelY = s.y - r * 2.35;
      ctx.font = `700 ${Math.round(13 * Math.max(0.85, zoom))}px "Space Grotesk", system-ui, sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(6,23,29,0.85)";
      ctx.strokeText(p.name, s.x, labelY);
      ctx.fillStyle = isLocal ? "#FFFFFF" : PAPER;
      ctx.fillText(p.name, s.x, labelY);

      const barW = 62 * Math.max(0.9, zoom);
      const barH = 5;
      const bx = s.x - barW / 2;
      const by = labelY + 8;
      ctx.fillStyle = "rgba(6,23,29,0.7)";
      ctx.fillRect(bx, by, barW, barH + (p.shield > 0 ? 3 : 0));
      ctx.fillStyle = p.hp > 45 ? CYAN : p.hp > 22 ? "#FFC53D" : ORANGE;
      ctx.fillRect(bx, by, barW * (p.hp / CFG.hp), barH);
      if (p.shield > 0) {
        ctx.fillStyle = "#6FA8FF";
        ctx.fillRect(bx, by + barH, barW * (p.shield / CFG.shieldMax), 3);
      }
    }

    // --- particles ---------------------------------------------------
    for (const p of this.particles) {
      const s = toScreen(p.x, p.y);
      const t = p.life / p.maxLife;
      const alpha = 1 - t;
      if (p.kind === "ring") {
        ctx.beginPath();
        ctx.arc(s.x, s.y, p.size * zoom * (0.3 + t * 1.6), 0, Math.PI * 2);
        ctx.lineWidth = 3 * (1 - t) + 0.5;
        ctx.strokeStyle = p.color;
        ctx.globalAlpha = alpha * 0.8;
        ctx.stroke();
        ctx.globalAlpha = 1;
      } else if (p.kind === "shock") {
        ctx.beginPath();
        ctx.arc(s.x, s.y, p.size * zoom * (0.2 + t * 1.3), 0, Math.PI * 2);
        ctx.lineWidth = 9 * (1 - t) + 1;
        ctx.strokeStyle = p.color;
        ctx.globalAlpha = alpha * 0.55;
        ctx.stroke();
        ctx.globalAlpha = 1;
      } else if (p.kind === "text") {
        ctx.font = `800 ${Math.round(p.size * Math.max(0.8, zoom))}px "Space Grotesk", system-ui, sans-serif`;
        ctx.textAlign = "center";
        ctx.globalAlpha = alpha;
        ctx.lineWidth = 3;
        ctx.strokeStyle = "rgba(6,23,29,0.8)";
        ctx.strokeText(p.text ?? "", s.x, s.y);
        ctx.fillStyle = p.color;
        ctx.fillText(p.text ?? "", s.x, s.y);
        ctx.globalAlpha = 1;
      } else {
        const size = p.size * zoom * (1 - t * 0.55);
        ctx.beginPath();
        ctx.arc(s.x, s.y, size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha * (p.kind === "smoke" ? 0.4 : 0.9);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }

    // --- hit marker (local player landed a shot) ----------------------
    if (this.hitMarker > 0.02) {
      const cx = width / 2;
      const cy = height / 2;
      const g = 10 + (1 - this.hitMarker) * 8;
      const l = 9;
      ctx.save();
      ctx.globalAlpha = this.hitMarker * 0.9;
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#FFFFFF";
      ctx.beginPath();
      for (const [sx, sy] of [
        [-1, -1],
        [1, -1],
        [-1, 1],
        [1, 1],
      ]) {
        ctx.moveTo(cx + sx * g, cy + sy * g);
        ctx.lineTo(cx + sx * (g + l), cy + sy * (g + l));
      }
      ctx.stroke();
      ctx.restore();
    }

    // --- minimap -------------------------------------------------------
    this.drawMinimap(ctx, world, width, height, localId);

    // --- vignette / grain -------------------------------------------
    const vKey = `${Math.round(width)}x${Math.round(height)}`;
    if (!this.vignette || this.vignette.key !== vKey) {
      const vg = ctx.createRadialGradient(
        width / 2,
        height / 2,
        Math.min(width, height) * 0.32,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.78,
      );
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(3,12,16,0.62)");
      this.vignette = { key: vKey, grad: vg };
    }
    ctx.fillStyle = this.vignette.grad;
    ctx.fillRect(0, 0, width, height);

    if (this.quality !== "low") {
      if (!this.grain) this.grain = this.makeGrain();
      if (!this.grainPattern) this.grainPattern = ctx.createPattern(this.grain, "repeat");
      if (this.grainPattern) {
        ctx.globalAlpha = 0.055;
        ctx.fillStyle = this.grainPattern;
        ctx.fillRect(0, 0, width, height);
        ctx.globalAlpha = 1;
      }
    }

    if (this.flash > 0.01) {
      ctx.fillStyle = `rgba(242,237,228,${this.flash * 0.5})`;
      ctx.fillRect(0, 0, width, height);
    }

    ctx.restore();
  }

  private drawMinimap(
    ctx: CanvasRenderingContext2D,
    world: World,
    width: number,
    height: number,
    localId: string,
  ) {
    const size = Math.min(132, Math.max(96, width * 0.12));
    const pad = 12;
    const mx = width - size - pad;
    const my = height - size - pad;
    const k = size / CFG.worldW;

    ctx.save();
    ctx.globalAlpha = 0.88;
    ctx.fillStyle = "rgba(6,23,29,0.78)";
    ctx.fillRect(mx, my, size, size);
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = "rgba(0,194,209,0.5)";
    ctx.strokeRect(mx, my, size, size);

    // zone
    ctx.beginPath();
    ctx.arc(mx + world.zone.x * k, my + world.zone.y * k, world.zone.r * k, 0, Math.PI * 2);
    ctx.strokeStyle = CYAN;
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // supply drop
    if (world.drop && !world.drop.taken) {
      ctx.fillStyle = GOLD;
      const dx = mx + world.drop.x * k;
      const dy = my + world.drop.y * k;
      ctx.fillRect(dx - 3, dy - 3, 6, 6);
    }

    // local player + alive enemies (late game only shows count fairness: always show)
    for (const p of world.players) {
      if (!p.alive) continue;
      const px = mx + p.x * k;
      const py = my + p.y * k;
      if (p.id === localId) {
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.arc(px, py, 3.4, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = "rgba(255,78,32,0.85)";
        ctx.beginPath();
        ctx.arc(px, py, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  /** screen -> world helper matching the camera used in draw() */
  screenToWorld(
    sx: number,
    sy: number,
    width: number,
    height: number,
    focus: { x: number; y: number },
  ) {
    const zoom = Math.max(0.42, Math.min(1.05, Math.min(width, height) / 760));
    const halfW = width / 2 / zoom;
    const halfH = height / 2 / zoom;
    const camX = Math.max(halfW * 0.35, Math.min(CFG.worldW - halfW * 0.35, focus.x));
    const camY = Math.max(halfH * 0.35, Math.min(CFG.worldH - halfH * 0.35, focus.y));
    return {
      x: (sx - width / 2) / zoom + camX,
      y: (sy - height / 2) / zoom + camY,
    };
  }
}

function drawDroplet(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  fill: string,
) {
  ctx.beginPath();
  ctx.moveTo(x, y - r * 1.25);
  ctx.bezierCurveTo(x + r * 1.05, y - r * 0.1, x + r * 0.85, y + r, x, y + r);
  ctx.bezierCurveTo(x - r * 0.85, y + r, x - r * 1.05, y - r * 0.1, x, y - r * 1.25);
  ctx.fillStyle = fill;
  ctx.shadowColor = "rgba(0,194,209,0.8)";
  ctx.shadowBlur = 18;
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = "rgba(242,237,228,0.85)";
  ctx.stroke();
}

function drawCrate(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  time: number,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = "#16343E";
  ctx.strokeStyle = GOLD;
  ctx.lineWidth = 2.5;
  ctx.shadowColor = "rgba(255,197,61,0.55)";
  ctx.shadowBlur = 14 + Math.sin(time * 4) * 5;
  ctx.fillRect(-r, -r, r * 2, r * 2);
  ctx.strokeRect(-r, -r, r * 2, r * 2);
  ctx.shadowBlur = 0;
  ctx.beginPath();
  ctx.moveTo(-r, 0);
  ctx.lineTo(r, 0);
  ctx.moveTo(0, -r);
  ctx.lineTo(0, r);
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = "rgba(255,197,61,0.6)";
  ctx.stroke();
  ctx.restore();
}

export function eventColor(e: WorldEvent, world: World): string {
  const p: Player | undefined = world.players.find((x) => x.id === e.p);
  return p?.color ?? CYAN;
}
