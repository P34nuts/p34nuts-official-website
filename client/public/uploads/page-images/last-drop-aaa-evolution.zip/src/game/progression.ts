/**
 * Progression math — shared between the API (authoritative) and the client
 * (display only). XP is granted per match from placement, kills, damage and
 * survival time.
 */

export type MatchResult = {
  placement: number;
  totalPlayers: number;
  kills: number;
  damage: number;
  survivalSec: number;
  won: boolean;
  shotsFired: number;
  shotsHit: number;
  weapon: string;
  mode: "solo" | "multi";
};

export function xpForMatch(r: MatchResult): { total: number; parts: { label: string; xp: number }[] } {
  const parts: { label: string; xp: number }[] = [];
  parts.push({ label: "Match played", xp: 25 });
  if (r.kills > 0) parts.push({ label: `${r.kills} elimination${r.kills > 1 ? "s" : ""}`, xp: r.kills * 20 });
  const surv = Math.round(Math.min(600, Math.max(0, r.survivalSec)) * 0.5);
  if (surv > 0) parts.push({ label: "Survival time", xp: surv });
  const dmg = Math.round(Math.min(1500, Math.max(0, r.damage)) * 0.1);
  if (dmg > 0) parts.push({ label: "Damage dealt", xp: dmg });
  if (r.won) parts.push({ label: "Victory", xp: 100 });
  else if (r.placement > 0 && r.placement <= 3) parts.push({ label: "Top 3 finish", xp: 40 });
  else if (r.placement > 0 && r.placement <= 5) parts.push({ label: "Top 5 finish", xp: 15 });
  if (r.mode === "multi") parts.push({ label: "Online match", xp: 15 });
  const total = parts.reduce((s, p) => s + p.xp, 0);
  return { total, parts };
}

/** XP needed to go from `level` to `level + 1` */
export function xpForLevel(level: number): number {
  return Math.round(90 + level * 35 + Math.pow(level, 1.6) * 8);
}

export function levelFromXp(totalXp: number): { level: number; into: number; need: number } {
  let level = 1;
  let rest = Math.max(0, totalXp);
  // soft cap loop; level 200 requires ~1.3M XP
  while (level < 200) {
    const need = xpForLevel(level);
    if (rest < need) return { level, into: rest, need };
    rest -= need;
    level++;
  }
  return { level, into: rest, need: xpForLevel(level) };
}

export function levelTitle(level: number): string {
  if (level >= 50) return "Tsunami";
  if (level >= 35) return "Riptide";
  if (level >= 25) return "Breaker";
  if (level >= 15) return "Swell";
  if (level >= 8) return "Current";
  if (level >= 4) return "Stream";
  return "Droplet";
}
