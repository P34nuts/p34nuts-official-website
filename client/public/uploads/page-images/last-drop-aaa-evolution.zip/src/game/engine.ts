import {
  EMPTY_INPUT,
  type AIState,
  type BotPersona,
  type Input,
  type Pickup,
  type PickupKind,
  type Player,
  type World,
  type WorldEventKind,
} from "./types";
import {
  RARITY_COLOR,
  WEAPONS,
  rarityRank,
  rollFloorWeapon,
  rollRarity,
  weaponDamage,
  weaponRange,
  weaponReload,
  type Rarity,
  type WeaponId,
} from "./weapons";

export const CFG = {
  worldW: 2600,
  worldH: 2600,
  playerRadius: 25,
  speed: 335,
  hp: 100,
  shieldMax: 50,
  dashSpeed: 940,
  dashTime: 0.17,
  dashCooldown: 1.8,
  pickupRadius: 21,
  waterHeal: 20,
  medkitHeal: 50,
  shieldCell: 25,
  pickupScore: 45,
  pickupCount: 46,
  weaponPickupCount: 14,
  matchTimeLimit: 300,
  zoneStartR: 1180,
  zoneDamageBase: 5.5,
  dropTimes: [40, 140] as number[],
  dropFallTime: 5,
};

export const ZONE_RADII = [920, 690, 500, 350, 225, 125, 45];
export const ZONE_HOLDS = [15, 13, 12, 11, 10, 9, 9];
export const ZONE_SHRINK_TIME = 12;

export const PLAYER_COLORS = [
  "#00C2D1",
  "#FF4E20",
  "#FFC53D",
  "#3DD68C",
  "#FF6FA5",
  "#6FA8FF",
  "#C79BFF",
  "#9BE15D",
];

const TAU = Math.PI * 2;
const PERSONAS: BotPersona[] = ["aggressive", "defensive", "tactical"];

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function norm(x: number, y: number) {
  const d = Math.hypot(x, y);
  return d > 0.0001 ? { x: x / d, y: y / d } : { x: 0, y: 0 };
}

function pushEvent(
  w: World,
  kind: WorldEventKind,
  x: number,
  y: number,
  a = 0,
  p = "",
  s = 1,
  q?: string,
  v?: number,
) {
  w.events.push({ id: w.eventSeq++, kind, x, y, a, p, s, q, v });
  if (w.events.length > 110) w.events.splice(0, w.events.length - 110);
}

function makeAI(index: number): AIState {
  return {
    targetId: null,
    strafe: Math.random() > 0.5 ? 1 : -1,
    retargetIn: 0,
    jitter: Math.random() * 10,
    persona: PERSONAS[index % PERSONAS.length],
    alert: 0,
    lootId: null,
    fleeing: 0,
    aimErr: 0.05 + Math.random() * 0.06,
  };
}

export function makePlayer(
  id: string,
  name: string,
  isBot: boolean,
  index: number,
  total: number,
): Player {
  const ring = total <= 1 ? 0 : 760;
  const ang = (index / Math.max(1, total)) * TAU + 0.4;
  return {
    id,
    name,
    color: PLAYER_COLORS[index % PLAYER_COLORS.length],
    isBot,
    x: CFG.worldW / 2 + Math.cos(ang) * ring + rand(-70, 70),
    y: CFG.worldH / 2 + Math.sin(ang) * ring + rand(-70, 70),
    vx: 0,
    vy: 0,
    angle: ang,
    hp: CFG.hp,
    shield: 0,
    alive: true,
    ammo: WEAPONS.hydro.magSize,
    weapon: "hydro",
    rarity: "common",
    reload: 0,
    fireCd: 0,
    dashCd: 0,
    dashTime: 0,
    kills: 0,
    score: 0,
    placement: 0,
    hitFlash: 0,
    protect: 2.2,
    connected: !isBot,
    input: { ...EMPTY_INPUT },
    ai: makeAI(index),
    stats: { damageDealt: 0, shotsFired: 0, shotsHit: 0, timeAlive: 0, pickups: 0 },
  };
}

/* ------------------------------------------------------------------ */
/* Loot                                                                */
/* ------------------------------------------------------------------ */

function lootPosition(w: World): { x: number; y: number } {
  // 55% of loot concentrates in hot zones, the rest scatters
  if (w.hotZones.length && Math.random() < 0.55) {
    const hz = w.hotZones[Math.floor(Math.random() * w.hotZones.length)];
    const a = Math.random() * TAU;
    const d = Math.sqrt(Math.random()) * hz.r;
    return {
      x: Math.min(CFG.worldW - 120, Math.max(120, hz.x + Math.cos(a) * d)),
      y: Math.min(CFG.worldH - 120, Math.max(120, hz.y + Math.sin(a) * d)),
    };
  }
  const margin = 160;
  return {
    x: rand(margin, CFG.worldW - margin),
    y: rand(margin, CFG.worldH - margin),
  };
}

function rollPickupKind(): PickupKind {
  const t = Math.random();
  if (t < 0.4) return "water";
  if (t < 0.58) return "shield";
  if (t < 0.72) return "ammo";
  if (t < 0.82) return "medkit";
  return "weapon";
}

function spawnPickup(w: World, forceKind?: PickupKind) {
  const pos = lootPosition(w);
  const kind = forceKind ?? rollPickupKind();
  const pk: Pickup = {
    id: w.nextId++,
    kind,
    x: pos.x,
    y: pos.y,
    r: CFG.pickupRadius,
    bob: Math.random() * TAU,
  };
  if (kind === "weapon") {
    pk.weapon = rollFloorWeapon(Math.random);
    pk.rarity = rollRarity(Math.random, w.zone.phase >= 3);
    pk.r = 25;
  }
  w.pickups.push(pk);
}

export function createWorld(
  roster: { id: string; name: string; isBot: boolean }[],
  opts: { timeLimit?: number } = {},
): World {
  // hot zones: loot-rich districts placed on a ring around the center
  const hotZones = [0, 1, 2, 3].map((i) => {
    const a = (i / 4) * TAU + rand(-0.4, 0.4);
    const d = rand(520, 860);
    return {
      x: CFG.worldW / 2 + Math.cos(a) * d,
      y: CFG.worldH / 2 + Math.sin(a) * d,
      r: rand(210, 300),
    };
  });

  const w: World = {
    tick: 0,
    time: 0,
    acc: 0,
    status: "countdown",
    countdown: 3.2,
    players: [],
    bullets: [],
    pickups: [],
    events: [],
    eventSeq: 1,
    nextId: 1,
    zone: {
      x: CFG.worldW / 2,
      y: CFG.worldH / 2,
      r: CFG.zoneStartR,
      targetR: CFG.zoneStartR,
      phase: 0,
      timer: ZONE_HOLDS[0],
      shrinking: false,
    },
    hotZones,
    drop: null,
    nextDropIn: CFG.dropTimes[0] ?? -1,
    winnerId: null,
    endedAt: 0,
    timeLimit: opts.timeLimit ?? CFG.matchTimeLimit,
  };
  roster.forEach((r, i) =>
    w.players.push(makePlayer(r.id, r.name, r.isBot, i, roster.length)),
  );
  for (let i = 0; i < CFG.pickupCount; i++) spawnPickup(w);
  for (let i = 0; i < CFG.weaponPickupCount; i++) spawnPickup(w, "weapon");
  return w;
}

export function getPlayer(w: World, id: string) {
  return w.players.find((p) => p.id === id);
}

/** Apply one input packet to a player (server + prediction). */
export function applyInput(w: World, id: string, input: Partial<Input>) {
  const p = getPlayer(w, id);
  if (!p) return;
  const mx = clamp(Number(input.mx ?? 0), -1, 1);
  const my = clamp(Number(input.my ?? 0), -1, 1);
  const mag = Math.hypot(mx, my);
  const aimX = Number(input.aimX ?? p.x);
  const aimY = Number(input.aimY ?? p.y);
  p.input = {
    mx: mag > 1 ? mx / mag : mx,
    my: mag > 1 ? my / mag : my,
    aimX: Number.isFinite(aimX) ? clamp(aimX, -400, CFG.worldW + 400) : p.x,
    aimY: Number.isFinite(aimY) ? clamp(aimY, -400, CFG.worldH + 400) : p.y,
    fire: Boolean(input.fire),
    dash: Boolean(input.dash),
    seq: Number(input.seq ?? 0),
  };
}

function clamp(v: number, lo: number, hi: number) {
  return v < lo ? lo : v > hi ? hi : v;
}

function damagePlayer(
  w: World,
  p: Player,
  amount: number,
  sourceId: string | null,
  angle: number,
  knock = 0,
  silent = false,
) {
  if (!p.alive || p.protect > 0) return;

  // shield soaks damage first
  let remaining = amount;
  if (p.shield > 0) {
    const absorbed = Math.min(p.shield, remaining);
    p.shield -= absorbed;
    remaining -= absorbed;
  }
  p.hp -= remaining;
  p.hitFlash = 0.22;
  if (knock > 0) {
    p.vx += Math.cos(angle) * knock;
    p.vy += Math.sin(angle) * knock;
  }
  if (sourceId && sourceId !== p.id) {
    const attacker = getPlayer(w, sourceId);
    if (attacker) {
      attacker.stats.damageDealt += amount;
      attacker.stats.shotsHit += silent ? 0 : 1;
      attacker.score += Math.round(amount * 1.2);
    }
    // bots remember who shot them
    if (p.isBot) {
      p.ai.alert = 4;
      if (!p.ai.targetId || Math.random() < 0.65) p.ai.targetId = sourceId;
    }
  }
  if (!silent) {
    pushEvent(
      w,
      "hit",
      p.x,
      p.y,
      angle,
      p.id,
      Math.min(1, amount / 24),
      sourceId ?? undefined,
      Math.round(amount),
    );
  }
  if (p.hp <= 0) {
    p.hp = 0;
    p.alive = false;
    p.stats.timeAlive = w.time;
    const aliveCount = w.players.filter((x) => x.alive).length;
    p.placement = aliveCount + 1;
    pushEvent(w, "death", p.x, p.y, angle, p.id, 1);
    if (sourceId && sourceId !== p.id) {
      const killer = getPlayer(w, sourceId);
      if (killer) {
        killer.kills += 1;
        killer.score += 260;
        pushEvent(w, "kill", p.x, p.y, 0, p.id, 1, killer.id);
      }
    } else {
      pushEvent(w, "kill", p.x, p.y, 0, p.id, 1);
    }
  }
}

function explode(w: World, x: number, y: number, radius: number, damage: number, ownerId: string) {
  pushEvent(w, "explosion", x, y, 0, ownerId, Math.min(1, radius / 140));
  for (const p of w.players) {
    if (!p.alive) continue;
    const d = Math.hypot(p.x - x, p.y - y);
    if (d < radius + CFG.playerRadius) {
      const falloff = 1 - Math.min(1, d / (radius + CFG.playerRadius)) * 0.65;
      const ang = Math.atan2(p.y - y, p.x - x);
      // self-damage is halved so the special weapon stays usable up close
      const dmg = damage * falloff * (p.id === ownerId ? 0.5 : 1);
      damagePlayer(w, p, dmg, p.id === ownerId ? null : ownerId, ang, 260 * falloff);
    }
  }
}

function endMatch(w: World) {
  if (w.status === "ended") return;
  w.status = "ended";
  w.endedAt = w.time;
  const alive = w.players.filter((p) => p.alive);
  for (const p of alive) p.stats.timeAlive = w.time;
  [...alive]
    .sort((a, b) => b.score - a.score)
    .forEach((p, i) => (p.placement = i + 1));
  const sorted = [...w.players].sort((a, b) => {
    if (a.placement !== b.placement) return a.placement - b.placement;
    return b.score - a.score;
  });
  w.winnerId = sorted[0]?.id ?? null;
  pushEvent(w, "zone", w.zone.x, w.zone.y, 0, "", 1);
}

function equipWeapon(p: Player, id: WeaponId, rarity: Rarity) {
  p.weapon = id;
  p.rarity = rarity;
  p.ammo = WEAPONS[id].magSize;
  p.reload = 0;
  p.fireCd = Math.max(p.fireCd, 0.18);
}

/** should a player auto-equip this weapon pickup? */
function wantsWeapon(p: Player, id: WeaponId, rarity: Rarity): boolean {
  if (p.weapon === "hydro") return true;
  if (rarityRank(rarity) > rarityRank(p.rarity)) return true;
  if (rarityRank(rarity) === rarityRank(p.rarity) && id !== p.weapon && p.weapon !== "storm") {
    // sidegrade only when the current mag is empty — feels intentional
    return p.ammo <= 0 && p.reload > 0;
  }
  return false;
}

function fireWeapon(w: World, p: Player) {
  const def = WEAPONS[p.weapon];
  p.fireCd = def.fireCooldown;
  p.ammo -= 1;
  p.stats.shotsFired += def.pellets > 1 ? 1 : 1;
  const r = CFG.playerRadius;
  const dmg = weaponDamage(p.weapon, p.rarity);
  for (let i = 0; i < def.pellets; i++) {
    const a = p.angle + rand(-def.spread, def.spread);
    w.bullets.push({
      id: w.nextId++,
      ownerId: p.id,
      x: p.x + Math.cos(a) * (r + 12),
      y: p.y + Math.sin(a) * (r + 12),
      vx: Math.cos(a) * def.speed + p.vx * 0.25,
      vy: Math.sin(a) * def.speed + p.vy * 0.25,
      life: def.life,
      r: def.bulletR,
      damage: dmg / (def.pellets > 1 ? 1 : 1),
      color: def.blast > 0 ? "#FFC53D" : p.color,
      weapon: p.weapon,
      blast: def.blast,
      knock: def.knock,
    });
  }
  pushEvent(w, "shoot", p.x, p.y, p.angle, p.id, 1, p.weapon);
  if (p.ammo <= 0) {
    p.reload = weaponReload(p.weapon, p.rarity);
    pushEvent(w, "reload", p.x, p.y, 0, p.id, 1, p.weapon);
  }
}

function collectPickup(w: World, p: Player, pk: Pickup) {
  switch (pk.kind) {
    case "water":
      p.hp = Math.min(CFG.hp, p.hp + CFG.waterHeal);
      break;
    case "medkit":
      p.hp = Math.min(CFG.hp, p.hp + CFG.medkitHeal);
      break;
    case "shield":
      p.shield = Math.min(CFG.shieldMax, p.shield + CFG.shieldCell);
      break;
    case "ammo":
      // instant tactical reload
      p.ammo = WEAPONS[p.weapon].magSize;
      p.reload = 0;
      break;
    case "weapon": {
      if (pk.weapon && pk.rarity && wantsWeapon(p, pk.weapon, pk.rarity)) {
        equipWeapon(p, pk.weapon, pk.rarity);
      } else {
        return; // leave it on the ground
      }
      break;
    }
  }
  p.score += CFG.pickupScore;
  p.stats.pickups += 1;
  pushEvent(w, "pickup", pk.x, pk.y, 0, p.id, 1, pk.kind);
  pk.id = -1;
}

/* ------------------------------------------------------------------ */
/* Simulation                                                          */
/* ------------------------------------------------------------------ */

/** Advance the authoritative simulation by a fixed timestep. */
export function stepWorld(w: World, dt: number) {
  w.tick++;

  if (w.status === "countdown") {
    w.countdown -= dt;
    if (w.countdown <= 0) {
      w.countdown = 0;
      w.status = "playing";
      w.time = 0;
      pushEvent(w, "start", w.zone.x, w.zone.y, 0, "", 1);
    }
    return;
  }
  if (w.status !== "playing") return;

  w.time += dt;

  // --- supply drop -----------------------------------------------------
  if (w.nextDropIn > 0) {
    w.nextDropIn -= dt;
    if (w.nextDropIn <= 0) {
      const a = Math.random() * TAU;
      const d = Math.sqrt(Math.random()) * Math.max(120, w.zone.r * 0.6);
      w.drop = {
        x: clamp(w.zone.x + Math.cos(a) * d, 200, CFG.worldW - 200),
        y: clamp(w.zone.y + Math.sin(a) * d, 200, CFG.worldH - 200),
        fall: CFG.dropFallTime,
        landed: false,
        taken: false,
      };
      pushEvent(w, "airdrop", w.drop.x, w.drop.y, 0, "", 1);
      const idx = CFG.dropTimes.findIndex((t) => t > w.time);
      w.nextDropIn = idx >= 0 ? CFG.dropTimes[idx] - w.time : -1;
    }
  }
  if (w.drop && !w.drop.taken) {
    if (!w.drop.landed) {
      w.drop.fall -= dt;
      if (w.drop.fall <= 0) {
        w.drop.landed = true;
        pushEvent(w, "airdrop_land", w.drop.x, w.drop.y, 0, "", 1);
      }
    } else {
      for (const p of w.players) {
        if (!p.alive) continue;
        if (Math.hypot(p.x - w.drop.x, p.y - w.drop.y) < CFG.playerRadius + 30) {
          w.drop.taken = true;
          const special: WeaponId = Math.random() < 0.6 ? "storm" : "longdrop";
          equipWeapon(p, special, "legendary");
          p.shield = CFG.shieldMax;
          p.hp = Math.min(CFG.hp, p.hp + 30);
          p.score += 180;
          pushEvent(w, "pickup", w.drop.x, w.drop.y, 0, p.id, 1, "airdrop");
          break;
        }
      }
    }
  }

  // --- players ---------------------------------------------------------
  for (const p of w.players) {
    if (!p.alive) continue;
    p.hitFlash = Math.max(0, p.hitFlash - dt);
    p.protect = Math.max(0, p.protect - dt);
    p.fireCd = Math.max(0, p.fireCd - dt);
    p.dashCd = Math.max(0, p.dashCd - dt);
    p.dashTime = Math.max(0, p.dashTime - dt);
    if (p.reload > 0) {
      p.reload = Math.max(0, p.reload - dt);
      if (p.reload === 0) p.ammo = WEAPONS[p.weapon].magSize;
    }

    const input = p.isBot ? botInput(w, p, dt) : p.input;

    const mag = Math.hypot(input.mx, input.my);
    const dirX = mag > 0.01 ? input.mx / mag : 0;
    const dirY = mag > 0.01 ? input.my / mag : 0;

    if (input.dash && p.dashCd <= 0 && mag > 0.01) {
      p.dashCd = CFG.dashCooldown;
      p.dashTime = CFG.dashTime;
      p.vx = dirX * CFG.dashSpeed;
      p.vy = dirY * CFG.dashSpeed;
      pushEvent(w, "dash", p.x, p.y, Math.atan2(dirY, dirX), p.id, 1);
    }

    const speed = CFG.speed * (p.dashTime > 0 ? 1.75 : 1);
    const targetVx = dirX * speed;
    const targetVy = dirY * speed;
    const blend = Math.min(1, dt * (p.dashTime > 0 ? 3 : 13));
    if (p.dashTime <= 0) {
      p.vx += (targetVx - p.vx) * blend;
      p.vy += (targetVy - p.vy) * blend;
    }

    p.x += p.vx * dt;
    p.y += p.vy * dt;

    const r = CFG.playerRadius;
    if (p.x < r) {
      p.x = r;
      p.vx = Math.abs(p.vx) * 0.35;
    }
    if (p.x > CFG.worldW - r) {
      p.x = CFG.worldW - r;
      p.vx = -Math.abs(p.vx) * 0.35;
    }
    if (p.y < r) {
      p.y = r;
      p.vy = Math.abs(p.vy) * 0.35;
    }
    if (p.y > CFG.worldH - r) {
      p.y = CFG.worldH - r;
      p.vy = -Math.abs(p.vy) * 0.35;
    }

    const aimAng = Math.atan2(input.aimY - p.y, input.aimX - p.x);
    if (Number.isFinite(aimAng)) p.angle = aimAng;

    if (input.fire && p.fireCd <= 0 && p.reload <= 0 && p.ammo > 0) {
      fireWeapon(w, p);
    }
  }

  // --- bullets ---------------------------------------------------------
  for (const b of w.bullets) {
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    if (
      b.life <= 0 ||
      b.x < -60 ||
      b.y < -60 ||
      b.x > CFG.worldW + 60 ||
      b.y > CFG.worldH + 60
    ) {
      if (b.blast > 0 && b.life <= 0 && b.x > 0 && b.y > 0 && b.x < CFG.worldW && b.y < CFG.worldH) {
        explode(w, b.x, b.y, b.blast, b.damage, b.ownerId);
      }
      b.life = -1;
      continue;
    }
    for (const p of w.players) {
      if (!p.alive || p.id === b.ownerId) continue;
      const dx = p.x - b.x;
      const dy = p.y - b.y;
      const rr = CFG.playerRadius + b.r;
      if (dx * dx + dy * dy <= rr * rr) {
        b.life = -1;
        if (b.blast > 0) {
          explode(w, b.x, b.y, b.blast, b.damage, b.ownerId);
        } else {
          damagePlayer(w, p, b.damage, b.ownerId, Math.atan2(b.vy, b.vx), b.knock);
        }
        break;
      }
    }
  }
  if (w.bullets.some((b) => b.life <= 0)) {
    w.bullets = w.bullets.filter((b) => b.life > 0);
  }

  // --- pickups ---------------------------------------------------------
  for (const pk of w.pickups) {
    pk.bob += dt * 2.1;
    for (const p of w.players) {
      if (!p.alive) continue;
      const dx = p.x - pk.x;
      const dy = p.y - pk.y;
      const rr = CFG.playerRadius + pk.r;
      if (dx * dx + dy * dy <= rr * rr) {
        collectPickup(w, p, pk);
        if (pk.id === -1) break;
      }
    }
  }
  const consumed = w.pickups.filter((p) => p.id === -1).length;
  if (consumed > 0) {
    w.pickups = w.pickups.filter((p) => p.id !== -1);
    for (let i = 0; i < consumed; i++) spawnPickup(w);
  }

  // --- zone ------------------------------------------------------------
  const z = w.zone;
  z.timer -= dt;
  if (!z.shrinking && z.timer <= 0 && z.phase < ZONE_RADII.length) {
    z.shrinking = true;
    z.timer = ZONE_SHRINK_TIME;
    z.targetR = ZONE_RADII[z.phase];
    pushEvent(w, "zone", z.x, z.y, 0, "", 1);
    const alive = w.players.filter((p) => p.alive);
    if (alive.length > 0) {
      const cx = alive.reduce((s, p) => s + p.x, 0) / alive.length;
      const cy = alive.reduce((s, p) => s + p.y, 0) / alive.length;
      z.x += (cx - z.x) * 0.22;
      z.y += (cy - z.y) * 0.22;
    }
  } else if (z.shrinking) {
    const k = Math.min(1, dt / ZONE_SHRINK_TIME);
    z.r += (z.targetR - z.r) * k * 2.2;
    if (Math.abs(z.r - z.targetR) < 2) {
      z.r = z.targetR;
      z.shrinking = false;
      z.phase++;
      z.timer = ZONE_HOLDS[Math.min(z.phase, ZONE_HOLDS.length - 1)];
    }
  }

  const zoneDmg = CFG.zoneDamageBase + z.phase * 1.9;
  for (const p of w.players) {
    if (!p.alive) continue;
    const d = Math.hypot(p.x - z.x, p.y - z.y);
    if (d > z.r - CFG.playerRadius * 0.4) {
      damagePlayer(w, p, zoneDmg * dt, null, Math.atan2(z.y - p.y, z.x - p.x), 0, true);
      if (Math.random() < dt * 6) {
        pushEvent(w, "hit", p.x, p.y, Math.random() * TAU, p.id, 0.25);
      }
    }
  }

  // --- survival score --------------------------------------------------
  for (const p of w.players) {
    if (p.alive) p.score += dt * 9;
  }

  // --- end conditions --------------------------------------------------
  const aliveCount = w.players.filter((p) => p.alive).length;
  if (aliveCount <= 1 || w.time >= w.timeLimit) endMatch(w);
}

/* ------------------------------------------------------------------ */
/* Bot AI — persona driven                                             */
/* ------------------------------------------------------------------ */

const IDLE: Input = { ...EMPTY_INPUT };

function personaTuning(persona: BotPersona) {
  switch (persona) {
    case "aggressive":
      return { vision: 1150, engage: 1.15, preferred: 250, fleeAt: 24, lootBias: 0.7 };
    case "defensive":
      return { vision: 900, engage: 0.85, preferred: 480, fleeAt: 48, lootBias: 1.3 };
    default:
      return { vision: 1000, engage: 1, preferred: 380, fleeAt: 34, lootBias: 1 };
  }
}

function nearestPickup(
  w: World,
  p: Player,
  filter: (pk: Pickup) => boolean,
  maxDist: number,
): Pickup | null {
  let best: Pickup | null = null;
  let bestD = maxDist;
  for (const pk of w.pickups) {
    if (!filter(pk)) continue;
    // ignore loot deep outside the zone
    const zd = Math.hypot(pk.x - w.zone.x, pk.y - w.zone.y);
    if (zd > w.zone.r + 120) continue;
    const d = Math.hypot(pk.x - p.x, pk.y - p.y);
    if (d < bestD) {
      bestD = d;
      best = pk;
    }
  }
  return best;
}

function botInput(w: World, p: Player, dt: number): Input {
  const ai = p.ai;
  const tune = personaTuning(ai.persona);
  ai.retargetIn -= dt;
  ai.jitter += dt;
  ai.alert = Math.max(0, ai.alert - dt);
  ai.fleeing = Math.max(0, ai.fleeing - dt);

  // ------- perception: choose a target --------------------------------
  const vision = tune.vision * (ai.alert > 0 ? 1.35 : 1);
  if (ai.retargetIn <= 0 || !ai.targetId || !getPlayer(w, ai.targetId)?.alive) {
    ai.retargetIn = 0.6 + Math.random() * 0.7;
    let best: Player | null = null;
    let bestScore = -Infinity;
    for (const o of w.players) {
      if (!o.alive || o.id === p.id) continue;
      const d = Math.hypot(o.x - p.x, o.y - p.y);
      if (d > vision) continue;
      // prefer close + weak targets
      const weakness = (CFG.hp + CFG.shieldMax - o.hp - o.shield) / 150;
      const s = -d / vision + weakness * 0.55 * tune.engage;
      if (s > bestScore) {
        bestScore = s;
        best = o;
      }
    }
    ai.targetId = best?.id ?? ai.targetId;
    if (best && Math.random() < 0.35) ai.strafe *= -1;
    if (!best && ai.alert <= 0) ai.targetId = null;
  }

  const target = ai.targetId ? getPlayer(w, ai.targetId) : undefined;
  const hpTotal = p.hp + p.shield;

  let mx = 0;
  let my = 0;
  let aimX = p.x + Math.cos(p.angle) * 300;
  let aimY = p.y + Math.sin(p.angle) * 300;
  let fire = false;
  let dash = false;

  const z = w.zone;
  const distToZoneCenter = Math.hypot(p.x - z.x, p.y - z.y);
  const outside = distToZoneCenter > z.r - 120;

  // ------- survival first: get back into the zone ----------------------
  if (outside) {
    const dir = norm(z.x - p.x, z.y - p.y);
    mx = dir.x;
    my = dir.y;
    dash = p.dashCd <= 0 && distToZoneCenter > z.r + 120;
    if (target) {
      aimX = target.x;
      aimY = target.y;
      fire = Math.hypot(target.x - p.x, target.y - p.y) < weaponRange(p.weapon) * 0.9 && p.ammo > 0;
    }
    return { mx, my, aimX, aimY, fire, dash, seq: 0 };
  }

  // ------- flee when critically hurt -----------------------------------
  if (hpTotal < tune.fleeAt || ai.fleeing > 0) {
    if (hpTotal < tune.fleeAt && ai.fleeing <= 0) ai.fleeing = 1.6;
    const heal = nearestPickup(
      w,
      p,
      (pk) => pk.kind === "water" || pk.kind === "medkit" || pk.kind === "shield",
      1100,
    );
    if (heal) {
      const dir = norm(heal.x - p.x, heal.y - p.y);
      mx = dir.x;
      my = dir.y;
      dash = p.dashCd <= 0 && Math.random() < 0.03;
    } else if (target) {
      const dir = norm(p.x - target.x, p.y - target.y);
      // flee toward the zone center, not into the wall
      const zc = norm(z.x - p.x, z.y - p.y);
      mx = dir.x * 0.7 + zc.x * 0.5;
      my = dir.y * 0.7 + zc.y * 0.5;
    }
    if (target) {
      aimX = target.x;
      aimY = target.y;
      const d = Math.hypot(target.x - p.x, target.y - p.y);
      fire = d < weaponRange(p.weapon) * 0.75 && p.ammo > 0 && ai.persona !== "defensive";
    }
    return { mx, my, aimX, aimY, fire, dash, seq: 0 };
  }

  // ------- loot runs ----------------------------------------------------
  const wantsGun = p.weapon === "hydro";
  const wantsShield = p.shield < 20;
  const wantsHeal = p.hp < 62;
  if ((wantsGun || wantsShield || wantsHeal) && (!target || Math.random() < 0.6 * tune.lootBias)) {
    const pk = nearestPickup(
      w,
      p,
      (pk) =>
        (wantsGun && pk.kind === "weapon") ||
        (wantsHeal && (pk.kind === "water" || pk.kind === "medkit")) ||
        (wantsShield && pk.kind === "shield"),
      wantsGun ? 1400 : 820,
    );
    if (pk) {
      const dir = norm(pk.x - p.x, pk.y - p.y);
      mx = dir.x;
      my = dir.y;
      if (target) {
        const d = Math.hypot(target.x - p.x, target.y - p.y);
        const lead = Math.min(0.32, d / WEAPONS[p.weapon].speed);
        aimX = target.x + target.vx * lead;
        aimY = target.y + target.vy * lead;
        fire = d < weaponRange(p.weapon) * 0.8 && p.ammo > 0;
      }
      return { mx, my, aimX, aimY, fire, dash: false, seq: 0 };
    }
  }

  // ------- supply drop greed (aggressive + tactical) --------------------
  if (
    w.drop &&
    w.drop.landed &&
    !w.drop.taken &&
    ai.persona !== "defensive" &&
    Math.hypot(w.drop.x - p.x, w.drop.y - p.y) < 900
  ) {
    const dir = norm(w.drop.x - p.x, w.drop.y - p.y);
    mx = dir.x;
    my = dir.y;
    if (target) {
      aimX = target.x;
      aimY = target.y;
      fire = Math.hypot(target.x - p.x, target.y - p.y) < weaponRange(p.weapon) * 0.8 && p.ammo > 0;
    }
    return { mx, my, aimX, aimY, fire, dash: false, seq: 0 };
  }

  // ------- combat -------------------------------------------------------
  if (target && target.alive) {
    const dx = target.x - p.x;
    const dy = target.y - p.y;
    const d = Math.hypot(dx, dy) || 1;
    const dirX = dx / d;
    const dirY = dy / d;
    const range = weaponRange(p.weapon);
    const preferred = Math.min(tune.preferred, range * 0.65);

    // aim with personality-based error that tightens late game
    const lead = Math.min(0.32, d / WEAPONS[p.weapon].speed);
    const err = ai.aimErr * (1 - Math.min(0.5, w.zone.phase * 0.09)) * (d / 500);
    const errA = Math.sin(ai.jitter * 2.7) * err;
    const ca = Math.cos(errA);
    const sa = Math.sin(errA);
    const tx = target.x + target.vx * lead - p.x;
    const ty = target.y + target.vy * lead - p.y;
    aimX = p.x + tx * ca - ty * sa;
    aimY = p.y + tx * sa + ty * ca;

    const closing = d > preferred ? 1 : d < preferred - 90 ? -1 : 0;
    const wobble = Math.sin(ai.jitter * 1.6) * 0.35;
    mx = dirX * closing + -dirY * ai.strafe * (0.75 + wobble);
    my = dirY * closing + dirX * ai.strafe * (0.75 + wobble);

    // hold fire until in effective range; defensive bots are pickier
    const discipline = ai.persona === "defensive" ? 0.72 : 0.95;
    fire = d < range * discipline && p.ammo > 0 && p.reload <= 0;
    if (d < 190 && p.dashCd <= 0 && Math.random() < (ai.persona === "aggressive" ? 0.035 : 0.015)) {
      dash = true;
    }
  } else {
    // patrol: tactical bots orbit the zone edge, others wander hot zones
    if (ai.persona === "tactical" && z.r > 300) {
      const edgeA = Math.atan2(p.y - z.y, p.x - z.x) + 0.55;
      const ex = z.x + Math.cos(edgeA) * z.r * 0.68;
      const ey = z.y + Math.sin(edgeA) * z.r * 0.68;
      const dir = norm(ex - p.x, ey - p.y);
      mx = dir.x * 0.7;
      my = dir.y * 0.7;
    } else {
      const ang = ai.jitter * 0.4 + p.angle;
      mx = Math.cos(ang) * 0.5;
      my = Math.sin(ang) * 0.5;
    }
    aimX = p.x + mx * 400;
    aimY = p.y + my * 400;
  }

  // keep inside the shrinking ring
  const margin = z.r - 180;
  if (distToZoneCenter > margin) {
    const dir = norm(z.x - p.x, z.y - p.y);
    mx = mx * 0.35 + dir.x * 0.9;
    my = my * 0.35 + dir.y * 0.9;
  }

  return { mx, my, aimX, aimY, fire, dash, seq: 0 };
}

export function ranking(w: World) {
  return [...w.players].sort((a, b) => {
    if (a.placement && b.placement && a.placement !== b.placement)
      return a.placement - b.placement;
    if (a.alive !== b.alive) return a.alive ? -1 : 1;
    return b.score - a.score;
  });
}

export { RARITY_COLOR, WEAPONS, IDLE as EMPTY_BOT_INPUT };
