import { desc } from "drizzle-orm";
import { db } from "@/db";
import { scores } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(scores).orderBy(desc(scores.score)).limit(20);
  return Response.json({
    ok: true,
    entries: rows.map((row, index) => ({
      rank: index + 1,
      name: row.name,
      score: row.score,
      kills: row.kills,
      placement: row.placement,
      mode: row.mode,
      at: row.createdAt.getTime(),
    })),
  });
}
