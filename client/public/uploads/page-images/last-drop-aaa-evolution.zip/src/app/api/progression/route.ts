import { NextRequest, NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import {
  levelFromXp,
  levelTitle,
  xpForMatch,
  type MatchResult,
} from "@/game/progression";

export const runtime = "nodejs";

function sanitizeId(raw: unknown): string {
  return String(raw ?? "")
    .replace(/[^a-zA-Z0-9_-]/g, "")
    .slice(0, 40);
}

function clampInt(v: unknown, lo: number, hi: number): number {
  const n = Math.round(Number(v ?? 0));
  if (!Number.isFinite(n)) return lo;
  return Math.max(lo, Math.min(hi, n));
}

function serializeProfile(row: typeof profiles.$inferSelect) {
  const lv = levelFromXp(row.xp);
  const accuracy =
    row.shotsFired > 0 ? Math.round((row.shotsHit / row.shotsFired) * 100) : 0;
  const favorite =
    Object.entries(row.weaponUsage ?? {}).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
  return {
    playerId: row.playerId,
    name: row.name,
    xp: row.xp,
    level: lv.level,
    levelInto: lv.into,
    levelNeed: lv.need,
    title: levelTitle(lv.level),
    matches: row.matches,
    wins: row.wins,
    kills: row.kills,
    deaths: row.deaths,
    damage: row.damage,
    timePlayed: row.timePlayed,
    accuracy,
    bestPlacement: row.bestPlacement,
    favoriteWeapon: favorite,
  };
}

export async function GET(req: NextRequest) {
  const playerId = sanitizeId(req.nextUrl.searchParams.get("playerId"));
  if (!playerId) {
    return NextResponse.json({ ok: false, error: "playerId required" }, { status: 400 });
  }
  try {
    const rows = await db.select().from(profiles).where(eq(profiles.playerId, playerId)).limit(1);
    if (!rows.length) {
      return NextResponse.json({ ok: true, profile: null });
    }
    return NextResponse.json({ ok: true, profile: serializeProfile(rows[0]) });
  } catch {
    return NextResponse.json({ ok: false, error: "database unavailable" }, { status: 503 });
  }
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ ok: false, error: "invalid body" }, { status: 400 });
  }

  const playerId = sanitizeId(body.playerId);
  if (!playerId) {
    return NextResponse.json({ ok: false, error: "playerId required" }, { status: 400 });
  }
  const name = String(body.name ?? "PLAYER")
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 16) || "PLAYER";

  // server-side validation: clamp every number to sane per-match bounds
  const result: MatchResult = {
    placement: clampInt(body.placement, 1, 99),
    totalPlayers: clampInt(body.totalPlayers, 1, 99),
    kills: clampInt(body.kills, 0, 30),
    damage: clampInt(body.damage, 0, 4000),
    survivalSec: clampInt(body.survivalSec, 0, 900),
    won: Boolean(body.won),
    shotsFired: clampInt(body.shotsFired, 0, 3000),
    shotsHit: clampInt(body.shotsHit, 0, 3000),
    weapon: String(body.weapon ?? "hydro").slice(0, 16),
    mode: body.mode === "multi" ? "multi" : "solo",
  };
  if (result.shotsHit > result.shotsFired) result.shotsHit = result.shotsFired;
  if (result.won && result.placement !== 1) result.won = false;

  const gain = xpForMatch(result);

  try {
    const existing = await db
      .select()
      .from(profiles)
      .where(eq(profiles.playerId, playerId))
      .limit(1);

    const prevXp = existing[0]?.xp ?? 0;
    const prevLevel = levelFromXp(prevXp).level;
    const usage: Record<string, number> = { ...(existing[0]?.weaponUsage ?? {}) };
    usage[result.weapon] = (usage[result.weapon] ?? 0) + 1;

    if (!existing.length) {
      await db.insert(profiles).values({
        playerId,
        name,
        xp: gain.total,
        level: levelFromXp(gain.total).level,
        matches: 1,
        wins: result.won ? 1 : 0,
        kills: result.kills,
        deaths: result.won ? 0 : 1,
        damage: result.damage,
        timePlayed: result.survivalSec,
        shotsFired: result.shotsFired,
        shotsHit: result.shotsHit,
        bestPlacement: result.placement,
        weaponUsage: usage,
      });
    } else {
      await db
        .update(profiles)
        .set({
          name,
          xp: sql`${profiles.xp} + ${gain.total}`,
          level: levelFromXp(prevXp + gain.total).level,
          matches: sql`${profiles.matches} + 1`,
          wins: sql`${profiles.wins} + ${result.won ? 1 : 0}`,
          kills: sql`${profiles.kills} + ${result.kills}`,
          deaths: sql`${profiles.deaths} + ${result.won ? 0 : 1}`,
          damage: sql`${profiles.damage} + ${result.damage}`,
          timePlayed: sql`${profiles.timePlayed} + ${result.survivalSec}`,
          shotsFired: sql`${profiles.shotsFired} + ${result.shotsFired}`,
          shotsHit: sql`${profiles.shotsHit} + ${result.shotsHit}`,
          bestPlacement:
            existing[0].bestPlacement === 0
              ? result.placement
              : sql`least(${profiles.bestPlacement}, ${result.placement})`,
          weaponUsage: usage,
          updatedAt: new Date(),
        })
        .where(eq(profiles.playerId, playerId));
    }

    const rows = await db.select().from(profiles).where(eq(profiles.playerId, playerId)).limit(1);
    const newLevel = levelFromXp(rows[0].xp).level;

    return NextResponse.json({
      ok: true,
      xpGained: gain.total,
      breakdown: gain.parts,
      leveledUp: newLevel > prevLevel,
      profile: serializeProfile(rows[0]),
    });
  } catch {
    // progression is a nice-to-have — report gracefully when DB is missing
    return NextResponse.json({ ok: false, error: "database unavailable" }, { status: 503 });
  }
}
