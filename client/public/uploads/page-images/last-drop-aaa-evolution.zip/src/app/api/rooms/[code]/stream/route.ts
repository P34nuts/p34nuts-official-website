import { EMPTY_INPUT } from "@/game/types";
import { syncRoom } from "@/server/rooms";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const playerId = new URL(req.url).searchParams.get("playerId") ?? "";
  if (!playerId) return Response.json({ ok: false, error: "Missing playerId" }, { status: 400 });

  const encoder = new TextEncoder();
  let closed = false;
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (payload: unknown) => controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\\n\\n`));
      try {
        for (let i = 0; i < 200 && !closed; i++) {
          const result = await syncRoom(code.toUpperCase(), playerId, EMPTY_INPUT);
          send(result);
          if (!result.ok || result.world?.status === "ended") break;
          await new Promise((resolve) => setTimeout(resolve, 50));
        }
      } finally {
        closed = true;
        controller.close();
      }
    },
    cancel() { closed = true; },
  });

  return new Response(stream, { headers: { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive" } });
}
