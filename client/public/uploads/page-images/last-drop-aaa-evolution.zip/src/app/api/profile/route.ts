import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { scores } from "@/db/schema";
import { sanitizeName } from "@/server/rooms";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const raw = url.searchParams.get("name") ?? url.searchParams.get("id") ?? "PLAYER";
  const name = sanitizeName(raw);
  const rows = await db.select().from(scores).where(eq(scores.name, name)).orderBy(desc(scores.createdAt)).limit(50);
  return Response.json({
    ok: true,
    profile: {
      name,
      matches: rows.length,
      wins: rows.filter((row) => row.placement === 1).length,
      kills: rows.reduce((sum, row) => sum + row.kills, 0),
      bestScore: rows.reduce((best, row) => Math.max(best, row.score), 0),
      recent: rows.slice(0, 10).map((row) => ({ score: row.score, kills: row.kills, placement: row.placement, mode: row.mode, at: row.createdAt.getTime() })),
    },
  });
}
