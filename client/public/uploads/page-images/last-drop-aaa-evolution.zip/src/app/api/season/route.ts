import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { challenges, profiles, seasons } from "@/db/schema";

export const runtime = "nodejs";

/**
 * Season + challenge overview. Challenge progress is derived from the
 * player's career profile, so it is always consistent with validated
 * match submissions and needs no extra writes.
 */
export async function GET(req: NextRequest) {
  const playerId = String(req.nextUrl.searchParams.get("playerId") ?? "")
    .replace(/[^a-zA-Z0-9_-]/g, "")
    .slice(0, 40);

  try {
    const seasonRows = await db
      .select()
      .from(seasons)
      .where(eq(seasons.active, true))
      .limit(1);
    if (!seasonRows.length) {
      return NextResponse.json({ ok: true, season: null, challenges: [] });
    }
    const season = seasonRows[0];
    const challengeRows = await db
      .select()
      .from(challenges)
      .where(eq(challenges.seasonId, season.id));

    let profile: typeof profiles.$inferSelect | null = null;
    if (playerId) {
      const rows = await db
        .select()
        .from(profiles)
        .where(eq(profiles.playerId, playerId))
        .limit(1);
      profile = rows[0] ?? null;
    }

    const metricValue = (metric: string): number => {
      if (!profile) return 0;
      switch (metric) {
        case "wins":
          return profile.wins;
        case "kills":
          return profile.kills;
        case "matches":
          return profile.matches;
        case "damage":
          return profile.damage;
        default:
          return 0;
      }
    };

    return NextResponse.json({
      ok: true,
      season: { number: season.number, name: season.name },
      challenges: challengeRows.map((c) => {
        const progress = Math.min(c.target, metricValue(c.metric));
        return {
          code: c.code,
          title: c.title,
          target: c.target,
          progress,
          completed: progress >= c.target,
          xpReward: c.xpReward,
        };
      }),
    });
  } catch {
    return NextResponse.json({ ok: false, error: "database unavailable" }, { status: 503 });
  }
}
