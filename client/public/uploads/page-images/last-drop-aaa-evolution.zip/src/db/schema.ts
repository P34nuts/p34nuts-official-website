import {
  boolean,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import type { ChatMessage, World } from "@/game/types";

export const rooms = pgTable("rooms", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: varchar("code", { length: 8 }).notNull().unique(),
  hostId: varchar("host_id", { length: 64 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("lobby"),
  world: jsonb("world").$type<World | null>(),
  maxPlayers: integer("max_players").notNull().default(8),
  fillBots: boolean("fill_bots").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }).notNull().defaultNow(),
});

export const roomPlayers = pgTable(
  "room_players",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    roomId: uuid("room_id")
      .notNull()
      .references(() => rooms.id, { onDelete: "cascade" }),
    playerId: varchar("player_id", { length: 64 }).notNull(),
    name: varchar("name", { length: 20 }).notNull(),
    isHost: boolean("is_host").notNull().default(false),
    isReady: boolean("is_ready").notNull().default(false),
    isBot: boolean("is_bot").notNull().default(false),
    connection: varchar("connection", { length: 12 }).notNull().default("online"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    joinedAt: timestamp("joined_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("room_player_unique").on(t.roomId, t.playerId)],
);

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  roomId: uuid("room_id")
    .notNull()
    .references(() => rooms.id, { onDelete: "cascade" }),
  playerId: varchar("player_id", { length: 64 }).notNull(),
  name: varchar("name", { length: 20 }).notNull(),
  body: varchar("body", { length: 160 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const scores = pgTable("scores", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 20 }).notNull(),
  score: integer("score").notNull(),
  kills: integer("kills").notNull().default(0),
  placement: integer("placement").notNull().default(1),
  mode: varchar("mode", { length: 12 }).notNull().default("solo"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Progression — persistent career profile per player id               */
/* ------------------------------------------------------------------ */

export const profiles = pgTable("profiles", {
  playerId: varchar("player_id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 20 }).notNull().default("PLAYER"),
  xp: integer("xp").notNull().default(0),
  level: integer("level").notNull().default(1),
  matches: integer("matches").notNull().default(0),
  wins: integer("wins").notNull().default(0),
  kills: integer("kills").notNull().default(0),
  deaths: integer("deaths").notNull().default(0),
  damage: integer("damage").notNull().default(0),
  timePlayed: integer("time_played").notNull().default(0),
  shotsFired: integer("shots_fired").notNull().default(0),
  shotsHit: integer("shots_hit").notNull().default(0),
  bestPlacement: integer("best_placement").notNull().default(0),
  /** weapon id -> matches where it was the final weapon */
  weaponUsage: jsonb("weapon_usage").$type<Record<string, number>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Season system — architecture prepared, no monetization              */
/* ------------------------------------------------------------------ */

export const seasons = pgTable("seasons", {
  id: uuid("id").primaryKey().defaultRandom(),
  number: integer("number").notNull().unique(),
  name: varchar("name", { length: 48 }).notNull(),
  active: boolean("active").notNull().default(false),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull().defaultNow(),
  endsAt: timestamp("ends_at", { withTimezone: true }),
});

export const challenges = pgTable("challenges", {
  id: uuid("id").primaryKey().defaultRandom(),
  seasonId: uuid("season_id").references(() => seasons.id, { onDelete: "cascade" }),
  code: varchar("code", { length: 48 }).notNull().unique(),
  title: varchar("title", { length: 96 }).notNull(),
  /** stat key the challenge tracks: kills | wins | matches | damage */
  metric: varchar("metric", { length: 24 }).notNull(),
  target: integer("target").notNull(),
  xpReward: integer("xp_reward").notNull().default(50),
});

export const playerChallenges = pgTable(
  "player_challenges",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    playerId: varchar("player_id", { length: 64 }).notNull(),
    challengeId: uuid("challenge_id")
      .notNull()
      .references(() => challenges.id, { onDelete: "cascade" }),
    progress: integer("progress").notNull().default(0),
    completedAt: timestamp("completed_at", { withTimezone: true }),
  },
  (t) => [uniqueIndex("player_challenge_unique").on(t.playerId, t.challengeId)],
);

/* ------------------------------------------------------------------ */
/* Cosmetics — architecture prepared, everything unlockable via play   */
/* ------------------------------------------------------------------ */

export const cosmetics = pgTable("cosmetics", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: varchar("code", { length: 48 }).notNull().unique(),
  kind: varchar("kind", { length: 24 }).notNull(), // skin | banner | emote | weapon_skin | color
  name: varchar("name", { length: 64 }).notNull(),
  rarity: varchar("rarity", { length: 16 }).notNull().default("common"),
  /** display payload — color hex, banner text, etc. */
  data: jsonb("data").$type<Record<string, unknown>>().notNull().default({}),
  /** level required to unlock (0 = default unlocked) */
  unlockLevel: integer("unlock_level").notNull().default(0),
});

export const playerCosmetics = pgTable(
  "player_cosmetics",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    playerId: varchar("player_id", { length: 64 }).notNull(),
    cosmeticId: uuid("cosmetic_id")
      .notNull()
      .references(() => cosmetics.id, { onDelete: "cascade" }),
    equipped: boolean("equipped").notNull().default(false),
    unlockedAt: timestamp("unlocked_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("player_cosmetic_unique").on(t.playerId, t.cosmeticId)],
);

export type ChatRow = typeof chatMessages.$inferSelect;
export type ScoreRow = typeof scores.$inferSelect;
export type RoomRow = typeof rooms.$inferSelect;
export type RoomPlayerRow = typeof roomPlayers.$inferSelect;
export type ProfileRow = typeof profiles.$inferSelect;

export type StoredChat = ChatMessage;
