"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  IconChevron,
  IconClose,
  IconCopy,
  IconDrop,
  IconGear,
  IconHelp,
  IconPlay,
  IconShare,
  IconTrophy,
  IconUsers,
} from "@/components/icons";
import {
  createRoom,
  fetchProfile,
  fetchScores,
  fetchSeason,
  getLobby,
  inviteLink,
  joinRoom,
  lobbyAction,
  type ProfileSummary,
  type SeasonInfo,
} from "@/lib/net-client";
import {
  DEFAULT_SETTINGS,
  EMPTY_STATS,
  loadSettings,
  loadStats,
  playerId,
  saveSettings,
  vibrate,
  type Settings,
  type Stats,
} from "@/lib/settings";
import type { LobbyState } from "@/game/types";

type View = "menu" | "lobby" | "join" | "howto" | "settings" | "leaderboard";
type Conn = "checking" | "online" | "offline";

type ScoreEntry = {
  name: string;
  score: number;
  kills: number;
  placement: number;
  mode: string;
};

const SLABS = [
  {
    id: "solo",
    index: "01",
    label: "Play Solo",
    sub: "Droplet royale vs. bots",
    accent: "cyan",
    icon: IconPlay,
  },
  {
    id: "create",
    index: "02",
    label: "Create Room",
    sub: "Private code, play with friends",
    accent: "ink",
    icon: IconUsers,
  },
  {
    id: "join",
    index: "03",
    label: "Join Room",
    sub: "Got a code? Drop it in",
    accent: "ink",
    icon: IconChevron,
  },
  {
    id: "howto",
    index: "04",
    label: "How To Play",
    sub: "60 seconds, then you know",
    accent: "ink",
    icon: IconHelp,
  },
  {
    id: "leaderboard",
    index: "05",
    label: "Leaderboard",
    sub: "Best drops on this server",
    accent: "ink",
    icon: IconTrophy,
  },
  {
    id: "settings",
    index: "06",
    label: "Settings",
    sub: "Audio, graphics, vibration",
    accent: "ink",
    icon: IconGear,
  },
] as const;

export default function MenuScreen() {
  const [view, setView] = useState<View>("menu");
  const [name, setName] = useState("");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [stats, setStats] = useState<Stats>(EMPTY_STATS);
  const [conn, setConn] = useState<Conn>("checking");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [joinCode, setJoinCode] = useState("");
  const [inviteCode, setInviteCode] = useState<string | null>(null);
  const [room, setRoom] = useState<LobbyState | null>(null);
  const [chatInput, setChatInput] = useState("");
  const [scores, setScores] = useState<ScoreEntry[]>([]);
  const [copied, setCopied] = useState<string | null>(null);
  const [profile, setProfile] = useState<ProfileSummary | null>(null);
  const [season, setSeason] = useState<SeasonInfo | null>(null);

  // career profile + season challenges (server-side progression)
  useEffect(() => {
    let cancelled = false;
    const pid = playerId();
    void fetchProfile(pid).then((res) => {
      if (!cancelled && res.ok && res.profile) setProfile(res.profile);
    });
    void fetchSeason(pid).then((res) => {
      if (!cancelled && res.ok && res.season) setSeason(res);
    });
    return () => {
      cancelled = true;
    };
  }, []);
  const pidRef = useRef("");

  const displayName = name.trim() || "PLAYER";

  useEffect(() => {
    const s = loadSettings();
    setSettings(s);
    setName(s.name);
    setStats(loadStats());
    pidRef.current = playerId();

    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get("room");
    if (roomParam) {
      const code = roomParam.toUpperCase();
      setInviteCode(code);
      setJoinCode(code);
      if (params.get("autojoin") === "1") {
        setBusy(true);
        joinRoom({
          code,
          name: s.name || "PLAYER",
          playerId: pidRef.current,
        }).then((res) => {
          setBusy(false);
          if (res.ok) {
            setRoom(res.lobby);
            setView("lobby");
            setInviteCode(null);
          } else {
            setError(res.error);
          }
        });
      }
    }

    fetch("/api/health", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j) => setConn(j?.ok ? "online" : "offline"))
      .catch(() => setConn("offline"));

    fetchScores()
      .then((r) => r.ok && setScores(r.entries))
      .catch(() => undefined);

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("sw.js").catch(() => undefined);
    }
  }, []);

  const persistName = useCallback((value: string) => {
    setName(value);
    const s = { ...loadSettings(), name: value };
    saveSettings(s);
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
    vibrate(12, patch.vibration ?? true);
  }, []);

  useEffect(() => {
    if (!room || view !== "lobby") return;
    const id = window.setInterval(() => {
      getLobby(room.code).then((res) => {
        if (res.ok) setRoom(res.lobby);
      });
    }, 1400);
    return () => window.clearInterval(id);
  }, [room?.code, view]);

  useEffect(() => {
    if (room && (room.status === "countdown" || room.status === "playing")) {
      window.location.href = `/play?room=${room.code}&mode=multi`;
    }
  }, [room?.status, room?.code]);

  async function handleSlab(id: string) {
    setError(null);
    setNotice(null);
    vibrate(10, settings.vibration);
    if (id === "solo") {
      const s = { ...settings, name: displayName };
      saveSettings(s);
      window.location.href = `/play?mode=solo`;
      return;
    }
    if (id === "create") {
      setBusy(true);
      const res = await createRoom({
        name: displayName,
        playerId: pidRef.current,
        fillBots: true,
      });
      setBusy(false);
      if (!res.ok) {
        setError(res.error);
        return;
      }
      saveSettings({ ...settings, name: displayName });
      setRoom(res.lobby);
      setView("lobby");
      return;
    }
    if (id === "join") {
      setView("join");
      if (!joinCode) setNotice("Enter the room code your friend shared.");
      return;
    }
    setView(id as View);
  }

  async function doJoin(code?: string) {
    const target = (code ?? joinCode).trim().toUpperCase();
    if (target.length < 4) {
      setError("Room codes are 5 characters long.");
      return;
    }
    setBusy(true);
    setError(null);
    const res = await joinRoom({
      code: target,
      name: displayName,
      playerId: pidRef.current,
    });
    setBusy(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    saveSettings({ ...settings, name: displayName });
    setRoom(res.lobby);
    setInviteCode(null);
    setView("lobby");
  }

  async function act(payload: Record<string, unknown>) {
    if (!room) return;
    const res = await lobbyAction(room.code, pidRef.current, payload);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setRoom(res.lobby);
    setError(null);
    if (payload.action === "leave") {
      setRoom(null);
      setView("menu");
    }
    if (payload.action === "chat") setChatInput("");
    vibrate(8, settings.vibration);
  }

  async function sendChat() {
    const body = chatInput.trim();
    if (!body) return;
    await act({ action: "chat", body });
  }

  async function shareInvite() {
    if (!room) return;
    const url = inviteLink(room.code);
    const payload = {
      title: "Last Drop — Battle Royale",
      text: `Join my Last Drop room: ${room.code}`,
      url,
    };
    if (navigator.share) {
      try {
        await navigator.share(payload);
        return;
      } catch {
        /* user cancelled — fall through to copy */
      }
    }
    copyToClipboard(url, "link");
  }

  function copyToClipboard(text: string, key: string) {
    const done = () => {
      setCopied(key);
      setNotice(key === "code" ? "Room code copied." : "Invite link copied.");
      window.setTimeout(() => setCopied(null), 1800);
    };
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
    } else {
      fallbackCopy(text, done);
    }
  }

  function fallbackCopy(text: string, done: () => void) {
    const el = document.createElement("textarea");
    el.value = text;
    el.style.position = "fixed";
    el.style.opacity = "0";
    document.body.appendChild(el);
    el.select();
    try {
      document.execCommand("copy");
      done();
    } catch {
      setNotice("Copy failed — select the code manually.");
    }
    document.body.removeChild(el);
  }

  const myId = pidRef.current;
  const isHost = useMemo(
    () => Boolean(room && room.players.find((p) => p.playerId === myId)?.isHost),
    [room, myId],
  );
  const myReady = useMemo(
    () => Boolean(room && room.players.find((p) => p.playerId === myId)?.isReady),
    [room, myId],
  );
  const humanCount = room?.players.filter((p) => !p.isBot).length ?? 0;
  const allReady =
    room?.players.filter((p) => !p.isBot).every((p) => p.isReady) ?? false;

  return (
    <div className="relative min-h-dvh overflow-x-hidden paper-grain">
      {/* ---------- top instrument strip ---------- */}
      <header className="flex items-center justify-between gap-4 px-[max(1.15rem,var(--safe-left))] pt-[max(1.15rem,var(--safe-top))]">
        <div className="flex items-center gap-3">
          <IconDrop className="text-cyan" size={20} />
          <span className="micro">Last Drop</span>
          <span className="micro text-ink-soft">/ Battle Royale</span>
        </div>
        <div
          className={`chip ${conn === "online" ? "text-teal" : conn === "offline" ? "text-orange" : "text-ink-soft"}`}
        >
          <span className={`led ${conn === "checking" ? "led-blink" : ""}`} />
          {conn === "online" ? "Server Online" : conn === "offline" ? "Offline · Solo Ready" : "Checking"}
        </div>
      </header>

      {view === "lobby" && room ? (
        <LobbyView
          room={room}
          myId={myId}
          isHost={isHost}
          myReady={myReady}
          humanCount={humanCount}
          allReady={allReady}
          chatInput={chatInput}
          setChatInput={setChatInput}
          sendChat={sendChat}
          act={act}
          copied={copied}
          copyToClipboard={copyToClipboard}
          shareInvite={shareInvite}
          busy={busy}
          error={error}
          onLeave={() => act({ action: "leave" })}
          onStart={() => act({ action: "start" })}
          onReady={() => act({ action: "ready", ready: !myReady })}
          onToggleBots={() => act({ action: "settings", fillBots: !room.fillBots })}
        />
      ) : (
        <main className="mx-auto grid w-full max-w-[1360px] grid-cols-1 gap-10 px-[max(1.15rem,var(--safe-left))] pb-32 pt-8 lg:grid-cols-[1.08fr_0.92fr] lg:gap-14 lg:pt-12">
          {/* ---------- hero ---------- */}
          <section>
            <div className="relative">
              <img
                src="images/poster-band.jpg"
                alt=""
                width={1536}
                height={1024}
                className="absolute -top-6 left-0 h-[calc(100%+3rem)] w-[112%] object-cover opacity-[0.42] mix-blend-multiply"
              />
              <div className="relative">
                <div className="micro text-ink-soft">Season 01 — The Drying</div>
                <h1 className="display mt-4 text-[clamp(3.4rem,13vw,10.5rem)]">
                  <span className="block">Last</span>
                  <span className="mt-1 inline-block bg-cyan px-3 pb-2 text-ink">
                    Drop
                  </span>
                </h1>
                <div className="rule mt-7 pt-4">
                  <p className="max-w-[46ch] text-[clamp(1rem,2.2vw,1.22rem)] leading-[1.5] text-ink">
                    The arena is drying out. Collect water, land your shots, and stay
                    inside the shrinking pool.{" "}
                    <strong className="font-bold">The last drop standing wins.</strong>
                  </p>
                </div>
                <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2">
                  <Stat label="Matches" value={profile?.matches ?? stats.matches} />
                  <Stat label="Wins" value={profile?.wins ?? stats.wins} />
                  <Stat label="Best Score" value={stats.bestScore} />
                  <Stat label="Eliminations" value={profile?.kills ?? stats.kills} />
                  <Stat label="Win Streak" value={stats.bestStreak} />
                </div>

                {profile && (
                  <div className="mt-6 border-2 border-ink bg-paper/60 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="display text-[clamp(1.6rem,4vw,2.2rem)] leading-none">
                          LVL {profile.level}
                        </span>
                        <span className="micro ml-3 text-ink-soft">{profile.title}</span>
                      </div>
                      <span className="micro num text-ink-soft">
                        {profile.levelInto}/{profile.levelNeed} XP
                      </span>
                    </div>
                    <div className="mt-2 h-2 w-full bg-ink/15">
                      <div
                        className="h-full bg-cyan"
                        style={{
                          width: `${Math.min(100, Math.round((profile.levelInto / profile.levelNeed) * 100))}%`,
                        }}
                      />
                    </div>
                    <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1">
                      <span className="micro text-ink-soft">
                        Accuracy <span className="num font-bold text-ink">{profile.accuracy}%</span>
                      </span>
                      <span className="micro text-ink-soft">
                        Damage <span className="num font-bold text-ink">{profile.damage.toLocaleString()}</span>
                      </span>
                      <span className="micro text-ink-soft">
                        Time played{" "}
                        <span className="num font-bold text-ink">
                          {Math.round(profile.timePlayed / 60)}m
                        </span>
                      </span>
                      {profile.favoriteWeapon && (
                        <span className="micro text-ink-soft">
                          Favorite{" "}
                          <span className="font-bold text-ink uppercase">
                            {profile.favoriteWeapon}
                          </span>
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {season?.season && season.challenges.length > 0 && (
                  <div className="mt-4 border border-ink bg-paper/60 p-4">
                    <div className="micro text-ink-soft">
                      Season {String(season.season.number).padStart(2, "0")} challenges
                    </div>
                    <div className="mt-2 space-y-2">
                      {season.challenges.map((c) => (
                        <div key={c.code}>
                          <div className="flex items-center justify-between gap-3">
                            <span
                              className={`text-sm font-semibold ${
                                c.completed ? "text-teal line-through opacity-70" : ""
                              }`}
                            >
                              {c.title}
                            </span>
                            <span className="micro num whitespace-nowrap text-ink-soft">
                              {c.progress}/{c.target} · +{c.xpReward} XP
                            </span>
                          </div>
                          <div className="mt-1 h-1 w-full bg-ink/15">
                            <div
                              className={`h-full ${c.completed ? "bg-teal" : "bg-cyan"}`}
                              style={{
                                width: `${Math.min(100, Math.round((c.progress / c.target) * 100))}%`,
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-10 grid grid-cols-1 gap-px border border-ink bg-ink sm:grid-cols-3">
              {[
                ["Move", "WASD / Stick"],
                ["Aim + Fire", "Mouse / Drag"],
                ["Dash", "Shift / Button"],
              ].map(([k, v]) => (
                <div key={k} className="bg-paper px-4 py-3">
                  <div className="micro text-ink-soft">{k}</div>
                  <div className="mt-1 text-sm font-semibold">{v}</div>
                </div>
              ))}
            </div>
          </section>

          {/* ---------- slab menu ---------- */}
          <section>
            {inviteCode && (
              <div className="mb-6 border-2 border-orange p-5">
                <div className="micro text-orange">Room invite detected</div>
                <div className="display mt-2 text-[clamp(2rem,7vw,3.2rem)]">
                  {inviteCode}
                </div>
                <button
                  className="btn mt-4 w-full"
                  onClick={() => doJoin(inviteCode)}
                  disabled={busy}
                >
                  {busy ? "Joining…" : "Join this room"}
                  <IconChevron />
                </button>
              </div>
            )}

            <div className="mb-5">
              <label className="micro text-ink-soft" htmlFor="player-name">
                Player name
              </label>
              <input
                id="player-name"
                className="field mt-2"
                value={name}
                maxLength={16}
                placeholder="YOUR NAME"
                onChange={(e) => persistName(e.target.value)}
                autoComplete="off"
                spellCheck={false}
              />
            </div>

            {view === "join" && (
              <div className="mb-5 border border-ink p-5">
                <label className="micro text-ink-soft" htmlFor="room-code">
                  Room code
                </label>
                <input
                  id="room-code"
                  className="field mt-2 num"
                  value={joinCode}
                  maxLength={5}
                  placeholder="K7X4P"
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  onKeyDown={(e) => e.key === "Enter" && doJoin()}
                  autoComplete="off"
                  spellCheck={false}
                />
                <button
                  className="btn mt-4 w-full"
                  onClick={() => doJoin()}
                  disabled={busy}
                >
                  {busy ? "Joining…" : "Join Room"}
                </button>
              </div>
            )}

            {error && (
              <div
                role="alert"
                className="mb-5 border border-orange px-4 py-3 text-sm font-semibold text-orange"
              >
                {error}
              </div>
            )}
            {notice && !error && (
              <div className="mb-5 border border-teal px-4 py-3 text-sm font-semibold text-teal">
                {notice}
              </div>
            )}

            <div className="border border-ink">
              {SLABS.map((s) => (
                <button
                  key={s.id}
                  className="slab"
                  data-accent={s.accent}
                  onClick={() => handleSlab(s.id)}
                  disabled={busy}
                >
                  <span className="micro num w-6 opacity-60">{s.index}</span>
                  <span className="flex-1">
                    <span className="block text-[clamp(1.05rem,2.6vw,1.35rem)] font-bold leading-tight">
                      {s.label}
                    </span>
                    <span className="micro mt-1 block opacity-65">{s.sub}</span>
                  </span>
                  <s.icon size={20} />
                </button>
              ))}
            </div>

            <p className="micro mt-5 leading-[1.9] text-ink-soft">
              No account needed · Works on desktop &amp; touch · Installable as an app
            </p>
          </section>
        </main>
      )}

      {/* ---------- bottom instrument strip ---------- */}
      <footer className="fixed inset-x-0 bottom-0 z-20 border-t border-ink bg-paper/92 px-[max(1.15rem,var(--safe-left))] py-2.5 pb-[calc(0.65rem+var(--safe-bottom))] backdrop-blur">
        <div className="mx-auto flex max-w-[1360px] items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <span className="micro num text-ink-soft">v1.0.0</span>
            <span className="micro num hidden text-ink-soft sm:inline">
              {humanCount > 0 ? `Room ${room?.code ?? "—"}` : "Ready to play"}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="micro border border-ink px-3 py-2 transition-colors hover:bg-ink hover:text-paper"
              onClick={() => updateSettings({ sfx: !settings.sfx })}
            >
              SFX {settings.sfx ? "On" : "Off"}
            </button>
            <button
              className="micro border border-ink px-3 py-2 transition-colors hover:bg-ink hover:text-paper"
              onClick={() => {
                if (document.fullscreenElement) void document.exitFullscreen();
                else void document.documentElement.requestFullscreen?.();
              }}
            >
              Fullscreen
            </button>
            <button
              className="micro border border-ink px-3 py-2 transition-colors hover:bg-ink hover:text-paper"
              onClick={() => setView("settings")}
            >
              Settings
            </button>
          </div>
        </div>
      </footer>

      {/* ---------- overlays ---------- */}
      {view === "howto" && (
        <Overlay title="How To Play" onClose={() => setView("menu")}>
          <div className="space-y-5">
            {[
              ["Move", "WASD, arrow keys, left virtual stick or the left stick of a gamepad."],
              ["Aim + Fire", "Mouse + click, drag on the right half of the screen, or the right stick. Touch aiming auto-tracks the nearest droplet."],
              ["Dash", "Shift, right click, J, the on-screen dash button or a face button. Dash through bullets, not into the burn."],
              ["Volume", "Your health is your water. Green orbs refill it and add score."],
              ["The Pool", "The cyan ring is safe ground. Outside it the paper dries out and burns — the damage grows every phase."],
              ["Win", "Be the last drop alive. Eliminations are worth 260 points, survival pays out every second."],
            ].map(([k, v]) => (
              <div key={k} className="rule pt-4 first:border-0 first:pt-0">
                <div className="micro text-cyan">{k}</div>
                <p className="mt-2 text-[0.98rem] leading-[1.55]">{v}</p>
              </div>
            ))}
          </div>
        </Overlay>
      )}

      {view === "settings" && (
        <Overlay title="Settings" onClose={() => setView("menu")}>
          <div className="space-y-6">
            <ToggleRow
              label="Sound effects"
              value={settings.sfx}
              onChange={(v) => updateSettings({ sfx: v })}
            />
            <ToggleRow
              label="Music"
              value={settings.music}
              onChange={(v) => updateSettings({ music: v })}
            />
            <ToggleRow
              label="Vibration"
              value={settings.vibration}
              onChange={(v) => updateSettings({ vibration: v })}
            />
            <div>
              <div className="micro text-ink-soft">Master volume</div>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(settings.volume * 100)}
                onChange={(e) =>
                  updateSettings({ volume: Number(e.target.value) / 100 })
                }
                className="mt-3 w-full accent-cyan"
                aria-label="Master volume"
              />
            </div>
            <div>
              <div className="micro text-ink-soft">Graphics quality</div>
              <div className="mt-3 grid grid-cols-2 gap-px border border-ink bg-ink sm:grid-cols-4">
                {(["auto", "low", "medium", "high"] as const).map((q) => (
                  <button
                    key={q}
                    className={`px-3 py-3 text-xs font-bold uppercase tracking-[0.16em] transition-colors ${
                      settings.quality === q
                        ? "bg-cyan text-deep"
                        : "bg-paper hover:bg-ink hover:text-paper"
                    }`}
                    onClick={() => updateSettings({ quality: q })}
                  >
                    {q}
                  </button>
                ))}
              </div>
              <p className="micro mt-3 leading-[1.9] text-ink-soft">
                Quality only changes particles, grain and effect density — never
                gameplay or hit detection.
              </p>
            </div>
            <button
              className="btn btn-danger w-full"
              onClick={() => {
                saveSettings(DEFAULT_SETTINGS);
                setSettings(DEFAULT_SETTINGS);
                setName("");
                setNotice("Settings reset.");
              }}
            >
              Reset settings
            </button>
          </div>
        </Overlay>
      )}

      {view === "leaderboard" && (
        <Overlay title="Leaderboard" onClose={() => setView("menu")}>
          {scores.length === 0 ? (
            <p className="text-[0.98rem] leading-[1.6]">
              No scores recorded on this server yet. Finish a match and yours is the
              first name on the plate.
            </p>
          ) : (
            <ol className="divide-y divide-ink/15">
              {scores.map((s, i) => (
                <li key={`${s.name}-${i}`} className="flex items-center gap-4 py-3">
                  <span className="micro num w-8 text-ink-soft">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="flex-1 truncate text-base font-bold">{s.name}</span>
                  <span className="micro text-ink-soft">
                    {s.placement === 1 ? "Winner" : `#${s.placement}`}
                  </span>
                  <span className="micro num text-ink-soft">{s.kills} KO</span>
                  <span className="num text-lg font-bold">
                    {Math.round(s.score).toLocaleString()}
                  </span>
                </li>
              ))}
            </ol>
          )}
          <p className="micro mt-6 leading-[1.9] text-ink-soft">
            Scores are written by the match server at the end of a real game.
          </p>
        </Overlay>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="micro text-ink-soft">{label}</div>
      <div className="num mt-1 text-[clamp(1.35rem,3.4vw,1.95rem)] font-bold leading-none">
        {value.toLocaleString()}
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-base font-semibold">{label}</span>
      <button
        role="switch"
        aria-checked={value}
        aria-label={label}
        onClick={() => onChange(!value)}
        className={`relative h-9 w-[74px] border border-ink transition-colors ${
          value ? "bg-cyan" : "bg-paper"
        }`}
      >
        <span
          className={`absolute top-[3px] h-[29px] w-[32px] bg-ink transition-all ${
            value ? "left-[38px]" : "left-[3px]"
          }`}
        />
      </button>
    </div>
  );
}

function Overlay({
  title,
  children,
  onClose,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-deep/70 p-0 sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={onClose}
    >
      <div
        className="wipe-in max-h-[88dvh] w-full max-w-2xl overflow-y-auto scrollbar-thin border-2 border-ink bg-paper p-6 pb-[calc(1.5rem+var(--safe-bottom))] sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-6 flex items-center justify-between gap-4">
          <h2 className="display text-[clamp(1.9rem,6vw,2.9rem)]">{title}</h2>
          <button
            className="btn btn-ghost h-11 w-11 p-0"
            onClick={onClose}
            aria-label="Close"
          >
            <IconClose />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function LobbyView(props: {
  room: LobbyState;
  myId: string;
  isHost: boolean;
  myReady: boolean;
  humanCount: number;
  allReady: boolean;
  chatInput: string;
  setChatInput: (v: string) => void;
  sendChat: () => void;
  act: (p: Record<string, unknown>) => void;
  copied: string | null;
  copyToClipboard: (text: string, key: string) => void;
  shareInvite: () => void;
  busy: boolean;
  error: string | null;
  onLeave: () => void;
  onStart: () => void;
  onReady: () => void;
  onToggleBots: () => void;
}) {
  const {
    room,
    myId,
    isHost,
    myReady,
    humanCount,
    allReady,
    chatInput,
    setChatInput,
    sendChat,
    copied,
    copyToClipboard,
    shareInvite,
    error,
    onLeave,
    onStart,
    onReady,
    onToggleBots,
  } = props;

  return (
    <main className="mx-auto grid w-full max-w-[1360px] grid-cols-1 gap-8 px-[max(1.15rem,var(--safe-left))] pb-32 pt-8 lg:grid-cols-[1.05fr_0.95fr]">
      <section>
        <div className="micro text-ink-soft">Room code — share it</div>
        <div className="mt-3 flex flex-wrap items-end gap-4">
          <div className="display text-[clamp(3.2rem,12vw,7.5rem)] tracking-[0.02em]">
            {room.code}
          </div>
          <div className="flex gap-2 pb-2">
            <button
              className="btn btn-ghost"
              onClick={() => copyToClipboard(room.code, "code")}
            >
              <IconCopy /> {copied === "code" ? "Copied" : "Copy code"}
            </button>
            <button className="btn" onClick={shareInvite}>
              <IconShare /> Share
            </button>
          </div>
        </div>
        <div className="rule mt-5 pt-4">
          <p className="text-sm leading-[1.6] text-ink-soft">
            Friends can join with the code, or open{" "}
            <span className="font-semibold text-ink">{inviteLink(room.code)}</span>{" "}
            directly. Bots fill the arena so a duo still plays like a royale.
          </p>
        </div>

        <div className="mt-6 border border-ink">
          <div className="flex items-center justify-between border-b border-ink px-4 py-2.5">
            <span className="micro">Players</span>
            <span className="micro num text-ink-soft">
              {humanCount}/{room.maxPlayers} humans
            </span>
          </div>
          <ul>
            {room.players.map((p) => (
              <li
                key={p.playerId}
                className="flex items-center gap-3 border-b border-ink/12 px-4 py-3 last:border-0"
              >
                <span
                  className={`led ${p.connection === "online" ? "text-teal" : p.connection === "grace" ? "text-orange" : "text-sand"}`}
                />
                <span className="flex-1 truncate text-base font-bold">
                  {p.name}
                  {p.playerId === myId && (
                    <span className="micro ml-2 text-ink-soft">you</span>
                  )}
                </span>
                {p.isHost && (
                  <span className="micro border border-ink px-2 py-1">Host</span>
                )}
                <span
                  className={`micro border px-2 py-1 ${
                    p.isReady
                      ? "border-cyan bg-cyan text-deep"
                      : "border-ink/30 text-ink-soft"
                  }`}
                >
                  {p.isBot ? "Bot" : p.isReady ? "Ready" : "Not ready"}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {error && (
          <div
            role="alert"
            className="mt-4 border border-orange px-4 py-3 text-sm font-semibold text-orange"
          >
            {error}
          </div>
        )}

        <div className="mt-5 flex flex-wrap gap-2">
          <button className={`btn ${myReady ? "btn-ghost" : ""}`} onClick={onReady}>
            {myReady ? "Not ready" : "Ready up"}
          </button>
          {isHost && (
            <button
              className="btn"
              onClick={onStart}
              disabled={humanCount === 0 || (!allReady && humanCount > 1)}
            >
              <IconPlay /> Start match
            </button>
          )}
          <button className="btn btn-danger" onClick={onLeave}>
            Leave room
          </button>
        </div>

        {isHost && (
          <div className="mt-5 flex items-center justify-between border border-ink px-4 py-3">
            <div>
              <div className="micro">Fill with bots</div>
              <div className="micro mt-1 text-ink-soft">
                Guarantees a full arena even with two players
              </div>
            </div>
            <button
              role="switch"
              aria-checked={room.fillBots}
              aria-label="Fill with bots"
              onClick={props.onToggleBots}
              className={`relative h-9 w-[74px] border border-ink transition-colors ${
                room.fillBots ? "bg-cyan" : "bg-paper"
              }`}
            >
              <span
                className={`absolute top-[3px] h-[29px] w-[32px] bg-ink transition-all ${
                  room.fillBots ? "left-[38px]" : "left-[3px]"
                }`}
              />
            </button>
          </div>
        )}
      </section>

      {/* chat */}
      <section className="flex min-h-[320px] flex-col border border-ink">
        <div className="flex items-center justify-between border-b border-ink px-4 py-2.5">
          <span className="micro">Lobby chat</span>
          <span className="micro text-ink-soft">Max 140 characters</span>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto scrollbar-thin p-4">
          {room.chat.length === 0 && (
            <p className="micro leading-[1.9] text-ink-soft">
              No messages yet. Say hi, share the code, then press ready.
            </p>
          )}
          {room.chat.map((m) => (
            <div key={m.id}>
              <div className="micro text-ink-soft">
                {m.playerId === myId ? "You" : m.name}
              </div>
              <div className="mt-1 text-[0.95rem] leading-[1.45]">{m.body}</div>
            </div>
          ))}
        </div>
        <div className="flex gap-2 border-t border-ink p-3">
          <input
            className="min-w-0 flex-1 border border-ink bg-transparent px-3 py-2.5 text-sm outline-none focus:border-cyan"
            value={chatInput}
            maxLength={140}
            placeholder="Type a message…"
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendChat()}
            aria-label="Chat message"
          />
          <button className="btn" onClick={sendChat}>
            Send
          </button>
        </div>
      </section>
    </main>
  );
}
