"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CFG, applyInput, createWorld, getPlayer, ranking, stepWorld } from "@/game/engine";
import type { Input, World } from "@/game/types";
import { Renderer } from "@/game/render";
import { InputController } from "@/game/input";
import { audio } from "@/game/audio";
import {
  inviteLink,
  joinRoom,
  lobbyAction,
  postScore,
  submitMatchResult,
  syncRoom,
  type ProgressionGain,
} from "@/lib/net-client";
import { RARITY_COLOR, RARITY_LABEL, WEAPONS } from "@/game/weapons";
import {
  DEFAULT_SETTINGS,
  loadSettings,
  playerId,
  recordMatch,
  resolveQuality,
  saveSettings,
  vibrate,
  prefersReducedMotion,
  type Settings,
} from "@/lib/settings";

type Mode = "solo" | "multi";
type Conn = "connecting" | "online" | "reconnecting" | "offline";

type HudState = {
  hp: number;
  shield: number;
  ammo: number;
  magSize: number;
  weapon: keyof typeof WEAPONS;
  rarity: keyof typeof RARITY_COLOR;
  reload: number;
  reloadTotal: number;
  score: number;
  kills: number;
  alive: number;
  total: number;
  phase: number;
  zoneTimer: number;
  countdown: number;
  status: World["status"];
  ping: number;
  fps: number;
  conn: Conn;
  myPlacement: number;
  spectator: boolean;
  dropActive: boolean;
  dashCd: number;
};

const INITIAL_HUD: HudState = {
  hp: CFG.hp,
  shield: 0,
  ammo: WEAPONS.hydro.magSize,
  magSize: WEAPONS.hydro.magSize,
  weapon: "hydro",
  rarity: "common",
  reload: 0,
  reloadTotal: 1,
  score: 0,
  kills: 0,
  alive: 0,
  total: 0,
  phase: 0,
  zoneTimer: 0,
  countdown: 3,
  status: "countdown",
  ping: 0,
  fps: 60,
  conn: "connecting",
  myPlacement: 0,
  spectator: false,
  dropActive: false,
  dashCd: 0,
};

type FeedEntry = { id: number; text: string; mine: boolean; at: number };

const BOT_NAMES = ["TIDE", "BRINE", "MIST", "RIVULET", "PUDDLE", "SURGE", "DEW"];

export default function GameClient({ code, mode }: { code: string; mode: Mode }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const worldRef = useRef<World | null>(null);
  const renderPos = useRef<
    Record<string, { x: number; y: number; vx: number; vy: number }>
  >({});
  const lastEventId = useRef(0);
  const resultsRef = useRef<World | null>(null);
  const lastFrame = useRef(0);
  const rafRef = useRef(0);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const inputRef = useRef<InputController | null>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const settingsRef = useRef<Settings>(DEFAULT_SETTINGS);
  const myIdRef = useRef("");
  const lastCountdown = useRef(-1);
  const lastHudUpdate = useRef(0);
  const lastShotSound = useRef(0);
  const recordedRef = useRef(false);
  const pingRef = useRef(0);
  const dashPending = useRef(false);
  const latestInput = useRef<Input | null>(null);
  const fpsRef = useRef(60);
  const sizeRef = useRef({ w: 1280, h: 720, dpr: 1 });
  const pausedRef = useRef(false);

  const [hud, setHud] = useState<HudState>(INITIAL_HUD);
  const [paused, setPaused] = useState(false);
  const [tutorial, setTutorial] = useState(false);
  const [fatal, setFatal] = useState<string | null>(null);
  const [results, setResults] = useState<World | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [feed, setFeed] = useState<FeedEntry[]>([]);
  const [gain, setGain] = useState<ProgressionGain | null>(null);

  // resolved after mount so server and client render identical markup
  const [isTouch, setIsTouch] = useState(false);

  const myId = myIdRef.current;

  /* -------------------------------------------------- setup ---------- */

  useEffect(() => {
    myIdRef.current = playerId();
    const settings = loadSettings();
    settingsRef.current = settings;
    setIsTouch(
      ("ontouchstart" in window &&
        window.matchMedia("(pointer: coarse)").matches) ||
        navigator.maxTouchPoints > 0,
    );
    audio.sfxEnabled = settings.sfx;
    audio.musicEnabled = settings.music;
    audio.setVolume(settings.volume);
    audio.resume();
    audio.startMusic();

    try {
      if (!window.localStorage.getItem("lastdrop.seen")) {
        setTutorial(true);
        pausedRef.current = true;
        setPaused(true);
      }
    } catch {
      /* storage unavailable */
    }

    const reduced = prefersReducedMotion();
    rendererRef.current = new Renderer(resolveQuality(settings.quality), reduced);

    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const input = new InputController(wrap);
    inputRef.current = input;

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const q = resolveQuality(settingsRef.current.quality);
      const dpr = Math.min(window.devicePixelRatio || 1, q === "low" ? 1.4 : 2);
      sizeRef.current = {
        w: Math.max(320, rect.width),
        h: Math.max(320, rect.height),
        dpr,
      };
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
    };
    resize();
    window.addEventListener("resize", resize);
    window.addEventListener("orientationchange", resize);
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const onVis = () => {
      lastFrame.current = performance.now();
      if (!document.hidden) {
        audio.resume();
        if (settingsRef.current.music) audio.startMusic();
      }
    };
    document.addEventListener("visibilitychange", onVis);

    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Escape") {
        e.preventDefault();
        setPaused((p) => {
          pausedRef.current = !p;
          return !p;
        });
      }
    };
    window.addEventListener("keydown", onKey);

    return () => {
      window.removeEventListener("resize", resize);
      window.removeEventListener("orientationchange", resize);
      window.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("keydown", onKey);
      ro.disconnect();
      input.destroy();
      cancelAnimationFrame(rafRef.current);
      if (pollRef.current) clearTimeout(pollRef.current);
      rendererRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* -------------------------------------------------- world source --- */

  const buildSoloWorld = useCallback(() => {
    const name = (settingsRef.current.name || "YOU").toUpperCase().slice(0, 12);
    const roster = [
      { id: myIdRef.current, name, isBot: false },
      ...BOT_NAMES.map((n, i) => ({
        id: `bot-${i}-${Math.random().toString(36).slice(2, 7)}`,
        name: n,
        isBot: true,
      })),
    ];
    worldRef.current = createWorld(roster);
    lastEventId.current = 0;
  }, []);

  useEffect(() => {
    if (mode === "solo") {
      buildSoloWorld();
      return;
    }
    let cancelled = false;
    setHud((h) => ({ ...h, conn: "connecting" }));
    joinRoom({
      code,
      name: settingsRef.current.name || "PLAYER",
      playerId: myIdRef.current,
    }).then(async (res) => {
      if (cancelled) return;
      if (!res.ok) {
        setFatal(res.error);
        return;
      }
      if (res.lobby.status === "lobby") {
        window.location.href = `/?room=${code}&autojoin=1`;
      }
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [code, mode]);

  /* -------------------------------------------------- networking ------ */

  const currentInput = useCallback((): Input => {
    const input = inputRef.current;
    const world = worldRef.current;
    const { w, h } = sizeRef.current;
    const frame = input
      ? input.sample(w, h)
      : {
          mx: 0,
          my: 0,
          aimX: w / 2,
          aimY: h / 2,
          fire: false,
          dash: false,
          seq: 0,
          explicitAim: false,
          usingTouch: false,
        };

    const me = world ? getPlayer(world, myIdRef.current) : undefined;
    const focus = me
      ? renderPos.current[me.id] ?? { x: me.x, y: me.y }
      : { x: CFG.worldW / 2, y: CFG.worldH / 2 };

    let aim = rendererRef.current
      ? rendererRef.current.screenToWorld(frame.aimX, frame.aimY, w, h, focus)
      : { x: focus.x + 200, y: focus.y };

    if (!frame.explicitAim && world) {
      let best: { x: number; y: number } | null = null;
      let bestD = Infinity;
      for (const p of world.players) {
        if (!p.alive || p.id === myIdRef.current) continue;
        const d = Math.hypot(p.x - focus.x, p.y - focus.y);
        if (d < bestD) {
          bestD = d;
          best = { x: p.x, y: p.y };
        }
      }
      if (best && bestD < 1000) aim = best;
    }

    return {
      mx: frame.mx,
      my: frame.my,
      aimX: aim.x,
      aimY: aim.y,
      fire: frame.fire,
      dash: frame.dash,
      seq: frame.seq,
    };
  }, []);

  const poll = useCallback(async () => {
    if (mode !== "multi") return;
    const input: Partial<Input> = latestInput.current ?? {
      mx: 0,
      my: 0,
      aimX: 0,
      aimY: 0,
      fire: false,
      dash: false,
      seq: 0,
    };
    if (input.dash) dashPending.current = false;
    const t0 = performance.now();
    const res = await syncRoom(code, myIdRef.current, input);
    pingRef.current = Math.round(performance.now() - t0);

    if (!res.ok) {
      setHud((h) => ({ ...h, conn: "reconnecting" }));
      pollRef.current = setTimeout(() => void poll(), 1200);
      return;
    }

    setHud((h) => (h.conn === "online" ? h : { ...h, conn: "online" }));
    if (res.world) {
      const prev = worldRef.current;
      worldRef.current = res.world;
      if (!prev) lastEventId.current = 0;
    }
    pollRef.current = setTimeout(() => void poll(), 85);
  }, [code, mode]);

  useEffect(() => {
    if (mode !== "multi" || fatal) return;
    let stopped = false;
    const kick = () => {
      if (!stopped) void poll();
    };
    const timer = setTimeout(kick, 220);
    return () => {
      stopped = true;
      clearTimeout(timer);
      if (pollRef.current) clearTimeout(pollRef.current);
    };
  }, [mode, fatal, poll]);

  /* -------------------------------------------------- effects --------- */

  const consumeEvents = useCallback(
    (world: World) => {
      const renderer = rendererRef.current;
      if (!renderer) return;
      const events = world.events.filter((e) => e.id > lastEventId.current);
      for (const e of events) {
        lastEventId.current = Math.max(lastEventId.current, e.id);
        renderer.handleEvent(e, world);

        const isMine = e.p === myIdRef.current;
        switch (e.kind) {
          case "start":
            audio.play("start");
            break;
          case "zone":
            audio.play("zone");
            break;
          case "airdrop":
          case "airdrop_land":
            audio.play("airdrop");
            setFeed((f) =>
              [
                {
                  id: e.id,
                  text: e.kind === "airdrop" ? "Supply drop inbound" : "Supply drop landed",
                  mine: false,
                  at: performance.now(),
                },
                ...f,
              ].slice(0, 5),
            );
            break;
          case "pickup":
            if (isMine) {
              if (e.q === "weapon" || e.q === "airdrop") audio.play("weapon_up");
              else if (e.q === "shield") audio.play("shield_up");
              else audio.play("pickup");
            }
            break;
          case "reload":
            if (isMine) audio.play("reload");
            break;
          case "explosion":
            audio.play("explosion");
            if (isMine) vibrate(50, settingsRef.current.vibration);
            break;
          case "hit":
            if (isMine) {
              audio.play("damage");
              vibrate(28, settingsRef.current.vibration);
            } else if (e.q === myIdRef.current) {
              const now = performance.now();
              if (now - lastShotSound.current > 55) audio.play("hitmarker");
            } else if (Math.random() < 0.25) audio.play("hit");
            break;
          case "kill": {
            const victim = world.players.find((p) => p.id === e.p);
            const killer = e.q ? world.players.find((p) => p.id === e.q) : undefined;
            const mine = e.q === myIdRef.current;
            setFeed((f) =>
              [
                {
                  id: e.id,
                  text: killer
                    ? `${killer.name} eliminated ${victim?.name ?? "?"}`
                    : `${victim?.name ?? "?"} evaporated`,
                  mine,
                  at: performance.now(),
                },
                ...f,
              ].slice(0, 5),
            );
            if (mine) {
              audio.play("kill");
              vibrate([20, 30, 20], settingsRef.current.vibration);
            }
            break;
          }
          case "death":
            if (isMine) {
              audio.play("elimination");
              vibrate([40, 40, 90], settingsRef.current.vibration);
            } else {
              audio.play("elimination");
            }
            break;
          case "shoot":
            if (isMine) {
              const now = performance.now();
              if (now - lastShotSound.current > 55) {
                lastShotSound.current = now;
                const def = e.q ? WEAPONS[e.q as keyof typeof WEAPONS] : undefined;
                audio.play(def?.sfx ?? "shoot");
              }
            } else if (Math.random() < 0.3) {
              const def = e.q ? WEAPONS[e.q as keyof typeof WEAPONS] : undefined;
              if (def?.type === "sniper" || def?.type === "special") audio.play(def.sfx);
            }
            break;
          case "dash":
            if (isMine) audio.play("dash");
            break;
        }
      }
    },
    [],
  );

  // expire kill feed entries
  useEffect(() => {
    if (!feed.length) return;
    const t = setInterval(() => {
      const now = performance.now();
      setFeed((f) => f.filter((e) => now - e.at < 6000));
    }, 1000);
    return () => clearInterval(t);
  }, [feed.length]);

  /* -------------------------------------------------- main loop ------- */

  useEffect(() => {
    const loop = (now: number) => {
      rafRef.current = requestAnimationFrame(loop);
      const renderer = rendererRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (!renderer || !canvas || !ctx) return;

      const rawDt = (now - (lastFrame.current || now)) / 1000;
      lastFrame.current = now;
      const dt = Math.min(0.05, Math.max(0, rawDt));
      fpsRef.current = fpsRef.current * 0.9 + (1 / Math.max(dt, 0.001)) * 0.1;

      const world = worldRef.current;
      const frame = currentInput();
      if (mode === "multi") {
        if (frame.dash) dashPending.current = true;
        latestInput.current = { ...frame, dash: dashPending.current };
      }

      if (world && mode === "solo" && !pausedRef.current && world.status !== "ended") {
        applyInput(world, myIdRef.current, frame);
        world.acc += dt;
        const fixed = 1 / 30;
        let guard = 0;
        while (world.acc >= fixed && guard < 6) {
          stepWorld(world, fixed);
          world.acc -= fixed;
          guard++;
        }
      }

      if (world) {
        consumeEvents(world);

        // smooth render positions toward authoritative state
        for (const p of world.players) {
          const rp = renderPos.current[p.id];
          if (!rp) {
            renderPos.current[p.id] = { x: p.x, y: p.y, vx: p.vx, vy: p.vy };
            continue;
          }
          const blend = p.id === myIdRef.current ? Math.min(1, dt * 14) : Math.min(1, dt * 9);
          rp.x += (p.x - rp.x) * blend;
          rp.y += (p.y - rp.y) * blend;
          rp.vx = p.vx;
          rp.vy = p.vy;
        }
      }

      const { w, h, dpr } = sizeRef.current;
      ctx.save();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      if (world) {
        const me = getPlayer(world, myIdRef.current);
        let focus = me
          ? renderPos.current[me.id] ?? { x: me.x, y: me.y }
          : { x: world.zone.x, y: world.zone.y };
        if (me && !me.alive) {
          const leader = ranking(world).find((p) => p.alive);
          if (leader) {
            focus = renderPos.current[leader.id] ?? { x: leader.x, y: leader.y };
          }
        }
        renderer.draw(ctx, world, w, h, focus, dt, myIdRef.current);
      } else {
        ctx.fillStyle = "#06171d";
        ctx.fillRect(0, 0, w, h);
      }

      drawTouchOverlay(ctx, inputRef.current, now);
      ctx.restore();

      // throttled HUD state
      if (now - lastHudUpdate.current > 110) {
        lastHudUpdate.current = now;
        if (world) {
          const me = getPlayer(world, myIdRef.current);
          if (me && world.status === "countdown") {
            const c = Math.ceil(world.countdown);
            if (c !== lastCountdown.current) {
              lastCountdown.current = c;
              audio.play("countdown");
            }
          }
          setHud((h) => ({
            ...h,
            hp: me ? me.hp : 0,
            shield: me ? me.shield : 0,
            ammo: me ? me.ammo : 0,
            magSize: me ? WEAPONS[me.weapon].magSize : WEAPONS.hydro.magSize,
            weapon: me ? me.weapon : "hydro",
            rarity: me ? me.rarity : "common",
            reload: me ? me.reload : 0,
            reloadTotal: me ? WEAPONS[me.weapon].reloadTime : 1,
            score: me ? Math.round(me.score) : 0,
            kills: me ? me.kills : 0,
            alive: world.players.filter((p) => p.alive).length,
            total: world.players.length,
            phase: world.zone.phase,
            zoneTimer: Math.max(0, world.zone.timer),
            countdown: world.countdown,
            status: world.status,
            ping: pingRef.current,
            fps: Math.round(fpsRef.current),
            myPlacement: me?.placement ?? 0,
            spectator: Boolean(me && !me.alive && world.status === "playing"),
            dropActive: Boolean(world.drop && !world.drop.taken),
            dashCd: me ? me.dashCd : 0,
          }));
        }

        if (world && world.status !== "ended" && resultsRef.current) {
          resultsRef.current = null;
          recordedRef.current = false;
          lastEventId.current = 0;
          renderPos.current = {};
          setResults(null);
        }

        if (world && world.status === "ended" && !recordedRef.current) {
          resultsRef.current = world;
          setResults(world);
          if (!recordedRef.current) {
            recordedRef.current = true;
            const me = getPlayer(world, myIdRef.current);
            const won = world.winnerId === myIdRef.current;
            const score = Math.round(me?.score ?? 0);
            recordMatch({
              won,
              kills: me?.kills ?? 0,
              score,
            });
            audio.play(won ? "victory" : "defeat");
            vibrate(won ? [30, 60, 30, 60, 120] : 220, settingsRef.current.vibration);
            if (mode === "solo") {
              void postScore({
                name: settingsRef.current.name || "PLAYER",
                score,
                kills: me?.kills ?? 0,
                placement: me?.placement ?? 1,
                mode: "solo",
              });
            }
            // progression: submit the validated match summary
            if (me) {
              setGain(null);
              void submitMatchResult({
                playerId: myIdRef.current,
                name: settingsRef.current.name || "PLAYER",
                placement: me.placement || 1,
                totalPlayers: world.players.length,
                kills: me.kills,
                damage: Math.round(me.stats.damageDealt),
                survivalSec: Math.round(me.stats.timeAlive || world.endedAt),
                won,
                shotsFired: me.stats.shotsFired,
                shotsHit: me.stats.shotsHit,
                weapon: me.weapon,
                mode,
              }).then((res) => {
                if (res.ok) {
                  setGain(res);
                  if (res.leveledUp) audio.play("levelup");
                }
              });
            }
          }
        }
      }
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  /* -------------------------------------------------- actions --------- */

  const clearResults = useCallback(() => {
    resultsRef.current = null;
    setResults(null);
    setGain(null);
    setFeed([]);
    recordedRef.current = false;
    lastEventId.current = 0;
    renderPos.current = {};
  }, []);

  const playAgain = useCallback(async () => {
    if (mode === "solo") {
      clearResults();
      buildSoloWorld();
      return;
    }
    const res = await lobbyAction(code, myIdRef.current, { action: "rematch" });
    if (res.ok && res.lobby && res.lobby.status !== "ended") {
      clearResults();
      setNotice(null);
    } else {
      setNotice(
        res.ok
          ? "Waiting for the host to start the rematch."
          : `${res.error} — ask the host to press rematch.`,
      );
    }
  }, [buildSoloWorld, clearResults, code, mode]);

  const leaveMatch = useCallback(() => {
    if (mode === "multi") {
      void lobbyAction(code, myIdRef.current, { action: "leave" });
    }
    window.location.href = "/";
  }, [code, mode]);

  const winner = results
    ? results.players.find((p) => p.id === results.winnerId)
    : undefined;
  const meResult = results
    ? results.players.find((p) => p.id === myId)
    : undefined;
  const won = Boolean(results && results.winnerId === myId);

  if (fatal) {
    return (
      <div className="game-root grid place-items-center px-6 text-paper">
        <div className="max-w-md text-center">
          <div className="display text-[clamp(2.4rem,9vw,4.5rem)]">Room unavailable</div>
          <p className="mt-4 text-[1.05rem] leading-[1.6] text-paper/80">{fatal}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a className="btn" href="/">
              Back to menu
            </a>
            <a className="btn btn-ghost !text-paper !border-paper" href="/play?mode=solo">
              Play solo instead
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div ref={wrapRef} className="game-root">
      <canvas ref={canvasRef} className="game-canvas" />

      {/* ---------- top-left instrument panel ---------- */}
      <div className="pointer-events-none absolute left-[max(0.75rem,var(--safe-left))] top-[max(0.75rem,var(--safe-top))] w-[min(240px,52vw)]">
        <div className="hud-panel px-3 py-2.5">
          <div className="flex items-center justify-between">
            <span className="micro truncate">{settingsRef.current.name || "YOU"}</span>
            <span className="micro num text-cyan">#{hud.myPlacement || "-"}</span>
          </div>
          <div className="mt-2">
            <div className="flex items-center justify-between">
              <span className="micro text-paper/60">Health</span>
              <span className="micro num">{Math.round(hud.hp)}</span>
            </div>
            <div className="mt-1 h-2.5 w-full bg-paper/15">
              <div
                className="h-full transition-[width] duration-150"
                style={{
                  width: `${Math.max(0, Math.min(100, hud.hp))}%`,
                  background:
                    hud.hp > 45 ? "#00c2d1" : hud.hp > 22 ? "#ffc53d" : "#ff4e20",
                }}
              />
            </div>
          </div>
          <div className="mt-1.5">
            <div className="flex items-center justify-between">
              <span className="micro text-paper/60">Shield</span>
              <span className="micro num">{Math.round(hud.shield)}</span>
            </div>
            <div className="mt-1 h-1.5 w-full bg-paper/15">
              <div
                className="h-full transition-[width] duration-150"
                style={{
                  width: `${Math.max(0, Math.min(100, (hud.shield / CFG.shieldMax) * 100))}%`,
                  background: "#6fa8ff",
                }}
              />
            </div>
          </div>
          {/* weapon card */}
          <div
            className="mt-2.5 border-l-2 pl-2"
            style={{ borderColor: RARITY_COLOR[hud.rarity] }}
          >
            <div className="flex items-center justify-between">
              <span className="micro truncate" style={{ color: RARITY_COLOR[hud.rarity] }}>
                {WEAPONS[hud.weapon].name}
              </span>
              <span className="micro num text-paper/80">
                {hud.reload > 0 ? "—" : hud.ammo}/{hud.magSize}
              </span>
            </div>
            <div className="micro mt-0.5 text-paper/45">
              {RARITY_LABEL[hud.rarity]} · {WEAPONS[hud.weapon].tag}
            </div>
            {hud.reload > 0 ? (
              <div className="mt-1 h-1.5 w-full bg-paper/15">
                <div
                  className="h-full bg-[#ffc53d]"
                  style={{
                    width: `${Math.max(0, Math.min(100, (1 - hud.reload / Math.max(0.2, hud.reloadTotal)) * 100))}%`,
                  }}
                />
              </div>
            ) : (
              <div className="mt-1 flex gap-[2px]">
                {Array.from({ length: Math.min(hud.magSize, 17) }).map((_, i) => (
                  <span
                    key={i}
                    className="h-1.5 flex-1"
                    style={{
                      background:
                        i < Math.ceil((hud.ammo / hud.magSize) * Math.min(hud.magSize, 17))
                          ? "rgba(242,237,228,0.8)"
                          : "rgba(242,237,228,0.15)",
                    }}
                  />
                ))}
              </div>
            )}
          </div>
          <div className="mt-2.5 grid grid-cols-2 gap-2">
            <div>
              <div className="micro text-paper/55">Score</div>
              <div className="num text-lg font-bold leading-none">{hud.score}</div>
            </div>
            <div>
              <div className="micro text-paper/55">Elims</div>
              <div className="num text-lg font-bold leading-none">{hud.kills}</div>
            </div>
          </div>
          <div className="mt-2">
            <div className="flex items-center justify-between">
              <span className="micro text-paper/60">Dash</span>
              <span className="micro num">
                {hud.dashCd <= 0 ? "READY" : `${hud.dashCd.toFixed(1)}s`}
              </span>
            </div>
            <div className="mt-1 h-1 w-full bg-paper/15">
              <div
                className="h-full transition-[width] duration-100"
                style={{
                  width: `${Math.max(0, Math.min(100, (1 - hud.dashCd / CFG.dashCooldown) * 100))}%`,
                  background: hud.dashCd <= 0 ? "#3dd68c" : "rgba(242,237,228,0.5)",
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ---------- kill feed ---------- */}
      {feed.length > 0 && !results && (
        <div className="pointer-events-none absolute right-[max(0.75rem,var(--safe-right))] top-[calc(max(0.75rem,var(--safe-top))+11.5rem)] flex w-[min(240px,54vw)] flex-col items-end gap-1">
          {feed.map((e) => (
            <div
              key={e.id}
              className={`micro wipe-in max-w-full truncate px-2 py-1 ${
                e.mine
                  ? "bg-cyan/20 text-cyan"
                  : "bg-deep/70 text-paper/75"
              }`}
            >
              {e.text}
            </div>
          ))}
        </div>
      )}

      {/* ---------- supply drop banner ---------- */}
      {hud.dropActive && hud.status === "playing" && !results && (
        <div className="pointer-events-none absolute inset-x-0 top-[max(0.75rem,var(--safe-top))] flex justify-center">
          <div className="micro border border-[#ffc53d]/50 bg-deep/70 px-3 py-1 text-[#ffc53d]">
            Supply drop on the field
          </div>
        </div>
      )}

      {/* ---------- top-right status ---------- */}
      <div className="pointer-events-none absolute right-[max(0.75rem,var(--safe-right))] top-[max(0.75rem,var(--safe-top))]">
        <div className="hud-panel px-3 py-2.5 text-right">
          <div className="flex items-center justify-end gap-2">
            <span
              className={`led ${
                hud.conn === "online"
                  ? "text-cyan"
                  : hud.conn === "reconnecting"
                    ? "text-orange led-blink"
                    : "text-paper/50 led-blink"
              }`}
            />
            <span className="micro">
              {hud.conn === "online"
                ? "Online"
                : hud.conn === "reconnecting"
                  ? "Reconnecting"
                  : "Connecting"}
            </span>
            {!results && (
              <button
                className="pointer-events-auto -my-2 flex h-11 w-11 items-center justify-center border border-cyan/40 text-paper"
                aria-label={paused ? "Resume" : "Pause"}
                onClick={() => {
                  pausedRef.current = !paused;
                  setPaused(!paused);
                  setNotice(null);
                }}
              >
                <span className="flex gap-[5px]">
                  <span className="block h-4 w-[3px] bg-paper" />
                  <span className="block h-4 w-[3px] bg-paper" />
                </span>
              </button>
            )}
          </div>
          <div className="mt-2 num text-2xl font-bold leading-none">
            {hud.alive}
            <span className="text-paper/45 text-base">/{hud.total}</span>
          </div>
          <div className="micro mt-1 text-paper/55">Drops left</div>
          <div className="mt-2.5 rule border-paper/15 pt-2">
            <div className="micro text-paper/55">Zone phase</div>
            <div className="num text-lg font-bold leading-none">
              {hud.phase + 1} · {Math.ceil(hud.zoneTimer)}s
            </div>
          </div>
          {settingsRef.current.showFps && (
            <div className="micro num mt-2 text-paper/50">
              {hud.fps} fps · {hud.ping} ms
            </div>
          )}
          {!settingsRef.current.showFps && (
            <div className="micro num mt-2 text-paper/50">{hud.ping} ms</div>
          )}
        </div>
      </div>

      {/* ---------- countdown ---------- */}
      {hud.status === "countdown" && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <div
            key={Math.ceil(hud.countdown)}
            className="stamp-in display text-[clamp(5rem,26vw,16rem)] text-paper drop-shadow-[0_10px_40px_rgba(0,0,0,0.6)]"
          >
            {Math.ceil(hud.countdown) > 0 ? Math.ceil(hud.countdown) : "GO"}
          </div>
        </div>
      )}

      {/* ---------- spectator / eliminated ---------- */}
      {hud.spectator && !results && (
        <div className="absolute inset-x-0 bottom-[calc(1rem+var(--safe-bottom))] flex flex-col items-center gap-3 px-4">
          <div className="hud-panel px-4 py-2 text-center">
            <div className="micro text-orange">Eliminated · spectating</div>
            <div className="mt-1 text-sm text-paper/80">
              Watching the drops that are still in the pool.
            </div>
          </div>
          <button
            className="btn btn-danger"
            onClick={() => {
              const w = worldRef.current;
              if (w) {
                resultsRef.current = w;
                setResults(w);
                recordedRef.current = true;
              }
            }}
          >
            End match
          </button>
        </div>
      )}

      {/* ---------- first-run briefing ---------- */}
      {tutorial && (
        <div
          className="absolute inset-0 z-50 grid place-items-center bg-deep/85 px-5"
          role="dialog"
          aria-label="How to play"
        >
          <div className="stamp-in w-full max-w-lg border-2 border-cyan bg-deep p-6 text-paper">
            <div className="micro text-cyan">First drop briefing</div>
            <h2 className="display mt-3 text-[clamp(2.2rem,9vw,3.6rem)]">
              Move · Aim · Survive
            </h2>
            <div className="mt-5 space-y-3">
              {[
                ["Move", isTouch ? "Left half of the screen — virtual stick" : "WASD or arrow keys"],
                ["Aim + Fire", isTouch ? "Drag on the right half" : "Mouse + click, or Space"],
                ["Dash", isTouch ? "Dash button" : "Shift, right click or J"],
                ["Loot", "Grab weapons, shield cells and medkits. Rarer glow = stronger gear."],
                ["Survive", "Stay inside the cyan pool. Watch for the golden supply drop."],
              ].map(([k, v]) => (
                <div key={k} className="rule border-paper/15 pt-3 first:border-0 first:pt-0">
                  <div className="micro text-cyan">{k}</div>
                  <div className="mt-1 text-[0.98rem] leading-[1.5] text-paper/85">{v}</div>
                </div>
              ))}
            </div>
            <button
              className="btn mt-6 w-full"
              onClick={() => {
                try {
                  window.localStorage.setItem("lastdrop.seen", "1");
                } catch {
                  /* storage unavailable */
                }
                setTutorial(false);
                pausedRef.current = false;
                setPaused(false);
              }}
            >
              Got it — drop in
            </button>
          </div>
        </div>
      )}

      {/* ---------- pause sheet ---------- */}
      {paused && !tutorial && (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center bg-deep/80 px-5"
          role="dialog"
          aria-label="Paused"
        >
          <div className="wipe-in w-full max-w-md border-2 border-cyan bg-deep p-6 text-paper">
            <div className="display text-[clamp(2rem,8vw,3rem)]">Paused</div>
            <div className="mt-5 space-y-3">
              <button
                className="btn w-full"
                onClick={() => {
                  pausedRef.current = false;
                  setPaused(false);
                }}
              >
                Resume
              </button>
              <button
                className="btn btn-ghost w-full !border-paper/40 !text-paper"
                onClick={() => {
                  const s = settingsRef.current;
                  const order = ["auto", "low", "medium", "high"] as const;
                  const next =
                    order[(order.indexOf(s.quality) + 1) % order.length];
                  settingsRef.current = { ...s, quality: next };
                  saveSettings(settingsRef.current);
                  rendererRef.current?.setQuality(resolveQuality(next));
                  setNotice(`Quality: ${next.toUpperCase()}`);
                }}
              >
                Quality: {settingsRef.current.quality.toUpperCase()}
              </button>
              <button
                className="btn btn-ghost w-full !border-paper/40 !text-paper"
                onClick={() => {
                  const next = !settingsRef.current.music;
                  settingsRef.current = { ...settingsRef.current, music: next };
                  audio.setMusicEnabled(next);
                }}
              >
                Music: {settingsRef.current.music ? "On" : "Off"}
              </button>
              <button className="btn btn-danger w-full" onClick={leaveMatch}>
                Leave match
              </button>
            </div>
            <div className="micro mt-5 leading-[1.9] text-paper/55">
              ESC toggles this panel · {isTouch ? "Drag right side to aim & fire" : "Mouse aim · Click fire · Shift dash"}
            </div>
            {notice && <div className="micro mt-3 text-cyan">{notice}</div>}
          </div>
        </div>
      )}

      {/* ---------- touch controls ---------- */}
      {isTouch && !paused && !results && (
        <>
          <button
            className="touch-btn absolute bottom-[calc(5.5rem+var(--safe-bottom))] right-[max(1.25rem,var(--safe-right))] h-[92px] w-[92px]"
            style={{ opacity: hud.dashCd > 0 ? 0.45 : 1 }}
            onPointerDown={(e) => {
              e.preventDefault();
              inputRef.current?.triggerDash();
            }}
            aria-label="Dash"
          >
            {hud.dashCd > 0 ? Math.ceil(hud.dashCd) : "Dash"}
          </button>
          <div className="pointer-events-none absolute bottom-[calc(1.15rem+var(--safe-bottom))] right-[max(1.25rem,var(--safe-right))] micro text-paper/45">
            Drag anywhere right to aim &amp; fire
          </div>
        </>
      )}

      {/* ---------- results ---------- */}
      {results && (
        <div className="absolute inset-0 z-40 overflow-y-auto scrollbar-thin bg-deep/88 px-4 py-[calc(1.5rem+var(--safe-top))]">
          <div className="rise-in mx-auto w-full max-w-2xl border-2 border-cyan bg-deep text-paper">
            <div className="relative overflow-hidden border-b border-cyan/40">
              <img
                src="images/results-plate.jpg"
                alt=""
                width={1536}
                height={1024}
                className="absolute inset-0 h-full w-full object-cover opacity-30 mix-blend-screen"
              />
              <div className="relative px-6 py-8">
                <div className="micro text-cyan">
                  {won ? "Last drop standing" : "Match complete"}
                </div>
                <h2 className="display mt-3 text-[clamp(2.6rem,11vw,5.2rem)]">
                  {won ? "Victory" : meResult?.placement ? `#${meResult.placement}` : "Defeat"}
                </h2>
                <div className="mt-4 flex flex-wrap gap-x-8 gap-y-2">
                  <ResultStat label="Score" value={Math.round(meResult?.score ?? 0)} />
                  <ResultStat label="Eliminations" value={meResult?.kills ?? 0} />
                  <ResultStat label="Placement" value={`#${meResult?.placement ?? "-"}`} />
                  <ResultStat label="Winner" value={winner?.name ?? "—"} />
                </div>
                <div className="mt-3 flex flex-wrap gap-x-8 gap-y-2">
                  <ResultStat
                    label="Damage"
                    value={Math.round(meResult?.stats?.damageDealt ?? 0)}
                  />
                  <ResultStat
                    label="Accuracy"
                    value={`${
                      meResult && meResult.stats && meResult.stats.shotsFired > 0
                        ? Math.round(
                            (meResult.stats.shotsHit / meResult.stats.shotsFired) * 100,
                          )
                        : 0
                    }%`}
                  />
                  <ResultStat
                    label="Weapon"
                    value={meResult ? WEAPONS[meResult.weapon].name : "—"}
                  />
                </div>
              </div>
            </div>

            {/* ---------- XP & level progress ---------- */}
            {gain && (
              <div className="border-b border-cyan/30 px-6 py-4">
                <div className="flex items-center justify-between">
                  <span className="micro text-cyan">
                    +{gain.xpGained} XP
                    {gain.leveledUp && <span className="ml-2 text-[#ffc53d]">Level up!</span>}
                  </span>
                  <span className="micro text-paper/70">
                    Level {gain.profile.level} · {gain.profile.title}
                  </span>
                </div>
                <div className="mt-2 h-2 w-full bg-paper/15">
                  <div
                    className="h-full bg-cyan transition-[width] duration-700"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round((gain.profile.levelInto / gain.profile.levelNeed) * 100),
                      )}%`,
                    }}
                  />
                </div>
                <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1">
                  {gain.breakdown.map((b) => (
                    <span key={b.label} className="micro text-paper/55">
                      {b.label} <span className="num text-paper/85">+{b.xp}</span>
                    </span>
                  ))}
                </div>
              </div>
            )}

            <ol className="divide-y divide-paper/10">
              {ranking(results).map((p, i) => (
                <li
                  key={p.id}
                  className={`flex items-center gap-3 px-5 py-2.5 ${
                    p.id === myId ? "bg-cyan/12" : ""
                  }`}
                >
                  <span className="micro num w-7 text-paper/55">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span
                    className="h-3 w-3 flex-none"
                    style={{ background: p.color }}
                    aria-hidden
                  />
                  <span className="flex-1 truncate text-sm font-bold">
                    {p.name}
                    {p.id === myId && <span className="micro ml-2 text-cyan">you</span>}
                  </span>
                  <span className="micro num text-paper/55">{p.kills} KO</span>
                  <span className="num text-base font-bold">
                    {Math.round(p.score).toLocaleString()}
                  </span>
                </li>
              ))}
            </ol>

            {notice && (
              <div className="micro border-t border-cyan/30 px-5 py-3 text-cyan">
                {notice}
              </div>
            )}

            <div className="flex flex-wrap gap-2 border-t border-cyan/30 p-5">
              <button className="btn" onClick={() => void playAgain()}>
                {mode === "solo" ? "Play again" : "Rematch"}
              </button>
              {mode === "multi" && (
                <button
                  className="btn btn-ghost !border-paper/40 !text-paper"
                  onClick={() => {
                    void navigator.clipboard
                      ?.writeText(inviteLink(code))
                      .then(() => setCopied(true))
                      .catch(() => setCopied(true));
                    window.setTimeout(() => setCopied(false), 2000);
                  }}
                >
                  {copied ? "Link copied" : "Copy invite link"}
                </button>
              )}
              <button className="btn btn-danger" onClick={leaveMatch}>
                Main menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ResultStat({
  label,
  value,
}: {
  label: string;
  value: string | number;
}) {
  return (
    <div>
      <div className="micro text-paper/55">{label}</div>
      <div className="num mt-1 text-[clamp(1.3rem,4vw,1.9rem)] font-bold leading-none">
        {value}
      </div>
    </div>
  );
}

/** Virtual stick + aim trail, drawn straight onto the game canvas. */
function drawTouchOverlay(
  ctx: CanvasRenderingContext2D,
  input: InputController | null,
  now: number,
) {
  if (!input || !input.stickActive) return;
  const stick = input.stickOrigin;
  if (!stick) return;
  const pulse = 0.9 + Math.sin(now / 260) * 0.05;

  ctx.save();
  ctx.globalAlpha = 0.22;
  ctx.beginPath();
  ctx.arc(stick.x, stick.y, 62 * pulse, 0, Math.PI * 2);
  ctx.fillStyle = "#00c2d1";
  ctx.fill();
  ctx.globalAlpha = 0.5;
  ctx.lineWidth = 2;
  ctx.strokeStyle = "#f2ede4";
  ctx.stroke();

  const dx = stick.x2 - stick.x;
  const dy = stick.y2 - stick.y;
  const d = Math.hypot(dx, dy);
  const max = 52;
  const k = d > max ? max / d : 1;
  ctx.beginPath();
  ctx.arc(stick.x + dx * k, stick.y + dy * k, 30, 0, Math.PI * 2);
  ctx.globalAlpha = 0.62;
  ctx.fillStyle = "#f2ede4";
  ctx.fill();
  ctx.restore();
}
