# AAA Edition — Changelog

Everything that changed from `last-drop-ultimate-fusion-edition` (v3) to **Last Drop Ultimate — AAA Edition** (v4).

## New features

### Weapon system (`src/game/weapons.ts`)
- Data-driven `WeaponDef` architecture: damage, pellets, fire rate, spread, projectile speed/lifetime, magazine size, reload time, knockback, blast radius, SFX key
- 6 weapons: Hydro Pistol (starter), Surge Rifle, Tidebreaker shotgun, Mist SMG, Longdrop sniper, Stormcaller (explosive, airdrop-only)
- 4-tier rarity (Common/Rare/Epic/Legendary) with damage & reload multipliers
- Magazine + reload loop replaces the old passive ammo regen; ammo crates = instant tactical reload
- Smart auto-equip rules (upgrade on higher rarity; sidegrade only when empty)

### Loot & world
- 5 pickup kinds: water, medkit, shield cell, ammo crate, weapon (with rarity glow pads)
- 4 procedurally placed **hot zones** holding 55% of all loot
- **Supply drops** at 40s and 140s: falling crate, landing beacon, legendary weapon + full shield reward, feed announcements
- Late-game loot quality shift (higher rarity odds after zone phase 3)

### Combat feel
- Shield layer (soaks damage before HP) with aura rendering and HUD/overhead bars
- Floating damage numbers, center-screen hit markers, kill feed with highlight for own kills
- Per-weapon muzzle flash, barrel rendering, recoil screen shake (sniper/shotgun)
- Explosions with shockwave rings and area damage falloff (half self-damage)
- 13 new synthesized sounds: per-weapon shots, reload, hit marker, kill confirm, shield, weapon pickup, explosion, airdrop fanfare, level-up

### AI overhaul
- Bot personas: aggressive / defensive / tactical with distinct vision, preferred range, fire discipline, flee threshold and loot bias
- Perception & memory: bots target attackers after taking damage, prefer weak/close targets
- Behaviors: loot runs (weapon → shield → heal priorities), fleeing toward heals, supply-drop contesting, tactical zone-edge rotation
- Personality-based aim error that tightens as the match progresses

### Progression & meta (PostgreSQL)
- `profiles` table + `/api/progression`: server-validated XP (kills, survival, damage, placement, win), career stats, accuracy, favorite weapon
- Level curve with titles; level-up detection + fanfare
- Result screen: XP breakdown, animated level progress, damage/accuracy/weapon stats
- Main menu: career card (level, XP bar, accuracy, time played, favorite weapon)
- Season architecture: `seasons`, `challenges`, `player_challenges` tables, seeded Season 01 with 4 live challenges whose progress derives from the validated profile
- Cosmetics architecture: `cosmetics`, `player_cosmetics` tables seeded with level-gated unlocks (no monetization)

### HUD / UX
- Weapon card with rarity color, magazine pips and reload progress bar
- Shield bar, dash cooldown meter (desktop panel + touch button countdown)
- Minimap with zone circle, enemies and supply drop marker
- Supply-drop banner, kill feed, expanded first-run briefing

## Improvements
- Input validation hardened: aim coordinates clamped server-side
- Zone damage no longer spams hit events/damage numbers
- Renderer culls off-screen pickups and players
- Service worker cache bumped to `lastdrop-aaa-v4`, missing icon references removed, poster art pre-cached
- Added the missing menu/result screen artwork (`public/images/`)

## Testing
- `npm run test:sim` extended: full 8-bot match runs to completion (winner, placements, supply drop, eliminations verified), weapon definition sanity checks, XP/level-curve regression checks

## Bug fixes
- `sw.js` shell cache previously failed entirely due to missing icon files
- Accuracy can no longer exceed 100% in persisted stats (server clamps hits ≤ shots)
- Victory flag is rejected server-side unless placement is #1
