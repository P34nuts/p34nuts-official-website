# Last Drop Ultimate — AAA Edition

A fast browser/mobile battle-royale arena where **hydration is survival**. Loot weapons, manage shield and health, outplay human-like bots or friends in online rooms, and stay inside the shrinking evaporation zone. The last drop standing wins.

This AAA Edition evolves `last-drop-ultimate-fusion-edition` into a production-grade experience: a full weapon/loot economy, persona-driven AI, supply drops, persistent XP/level progression backed by PostgreSQL, and a premium HUD with kill feed, hit markers, damage numbers and a minimap.

## Features

### Combat & loot
- **5 weapon archetypes + 1 special**: Hydro Pistol, Surge Rifle (AR), Tidebreaker (shotgun, 6 pellets), Mist SMG, Longdrop (sniper) and the airdrop-only explosive **Stormcaller**
- **Rarity system** — Common / Rare / Epic / Legendary with damage and reload multipliers and color-coded loot glow
- **Magazines & reloads** with per-player reload spinner; ammo crates grant an instant tactical reload
- **Shield cells** (soak damage before health), water orbs and medkits
- **Hot zones** — four loot-rich districts; weapon loot concentrates there
- **Supply drops** — golden crates fall mid-match carrying a legendary weapon + full shield, announced in the feed, visible on the minimap

### Combat feel
- Hit markers, floating damage numbers, kill feed, per-weapon muzzle flash & recoil shake
- Explosion shockwaves, per-weapon synthesized sound design (AR / shotgun / SMG / sniper / special / reload / kill confirm / airdrop / level-up)
- Haptic feedback on mobile for hits, kills and explosions

### AI
- Three bot personas — **aggressive**, **defensive**, **tactical** — with distinct vision range, engagement distance, fire discipline and flee thresholds
- Bots loot weapons/shields/heals, remember attackers, contest supply drops, lead their shots with personality-based aim error that tightens late-game, and rotate with the zone

### Progression (PostgreSQL)
- Server-validated XP per match (kills, survival, damage, placement, victory)
- Level curve with titles (Droplet → Tsunami), level-up fanfare and animated XP bar on the result screen
- Career profile: matches, wins, K/D, damage, accuracy, time played, favorite weapon
- **Season system** with live challenges (progress derived from the validated career profile)
- **Cosmetics tables** prepared (skins/banners/colors, level-gated, no monetization)

### Multiplayer
- Online rooms (up to 8) with ready-up, chat, bot fill, reconnect grace and rematch
- Server-authoritative fixed-step simulation; all inputs validated and clamped server-side
- All new systems (weapons, loot, drops, AI) run identically in solo and online matches

## Run locally

```bash
npm install
# set DATABASE_URL in .env for multiplayer + progression
npx drizzle-kit push
npm run dev            # http://localhost:3000
```

Production: `npm run build && npm run start`

Checks: `npm run lint` · `npm run typecheck` · `npm run test:sim`

Solo mode works without a database. Rooms, scores and XP progression require `DATABASE_URL`.

## Controls

| Action | Desktop | Touch |
| ------ | ------- | ----- |
| Move | WASD / arrows | left-half virtual stick |
| Aim + fire | mouse + click / Space | drag on right half |
| Dash | Shift / right click / J | dash button (shows cooldown) |
| Pause | Esc | pause button |

Weapons auto-equip when you walk over better loot. Reloads are automatic when the magazine empties.

## Architecture

```text
src/
  game/
    engine.ts        authoritative fixed-step simulation, loot, drops, AI
    weapons.ts       data-driven weapon + rarity definitions
    types.ts         shared world/player/event state types
    progression.ts   XP + level math (shared client/server)
    render.ts        canvas renderer: effects, minimap, damage numbers
    input.ts         keyboard/mouse/touch/gamepad controller
    audio.ts         synthesized SFX kit + ambient music
  server/rooms.ts    room lifecycle + server simulation
  app/api/           rooms, sync, scores, leaderboard, progression, season
  db/schema.ts       rooms, scores, profiles, seasons, challenges, cosmetics
  components/        MenuScreen (career + challenges), GameClient (HUD)
```

See `TECHNICAL_ARCHITECTURE.md` for the deep dive and `AAA_CHANGELOG.md` for everything that changed.
