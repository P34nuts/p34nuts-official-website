# Technical Architecture — Last Drop Ultimate, AAA Edition

## Overview

Next.js (App Router) fullstack application. The game is a deterministic fixed-step 2D simulation that runs **identically** in two places:

- **Solo:** entirely in the browser (client is the authority)
- **Online:** inside API route handlers against a PostgreSQL-persisted world (server is the authority; clients send validated input packets and render snapshots)

```
Browser ──render loop──> Renderer (canvas)
   │  input packets (85ms poll)         ▲ world snapshot
   ▼                                    │
/api/rooms/[code]/sync ──> server/rooms.ts ──> game/engine.ts (fixed 30Hz steps)
                                    │
                                    ▼
                         PostgreSQL (world jsonb, lobby, chat, scores, profiles)
```

## State model

All game state lives in plain serializable structures (`src/game/types.ts`):

| Structure | Responsibility |
| --------- | -------------- |
| `World` | match status, tick/time, players, bullets, pickups, zone, hot zones, supply drop, event ring buffer |
| `Player` | transform, HP/shield, equipped weapon + rarity, magazine/reload, dash, score, `MatchStats`, `AIState` |
| `Input` | normalized move dir, world-space aim, fire/dash flags, sequence number |
| `WorldEvent` | ring buffer (max 110) of gameplay events with primary/secondary ids and numeric payload — drives all client feedback (particles, sounds, kill feed, damage numbers) deterministically across clients |
| `LobbyState` | room membership, readiness, chat (DB-backed) |

There is intentionally **no hidden client state**: everything the renderer needs is in `World` or derived locally (interpolation buffers, particles).

## Engine (`src/game/engine.ts`)

- Fixed timestep `1/30s`; the client accumulates real time and steps with a guard (max 6 steps/frame); the server simulates elapsed wall-clock time capped at 0.75s per sync
- Phases: `countdown → playing → ended`, zone phases via `ZONE_RADII`/`ZONE_HOLDS`
- Damage pipeline: `damagePlayer` applies shield-first absorption, knockback, attacker stat tracking, hit events (with damage payload for floating numbers) and kill events (victim + killer ids for the feed)
- Explosive projectiles call `explode` with radial falloff and half self-damage
- Loot: weighted kind roll (water 40%, shield 18%, ammo 14%, medkit 10%, weapon 18%), 55% placed in hot zones, consumed loot respawns elsewhere, rarity odds shift upward after zone phase 3
- Supply drops scheduled at fixed match times, fall for 5s, then are contestable

## Weapon system (`src/game/weapons.ts`)

Pure data + pure functions. Adding a weapon = adding one `WeaponDef` entry; engine, renderer, audio and HUD all key off it (pellets, spread, blast, sfx, barrel style). Rarity applies multiplicative modifiers (`RARITY_MULT`) so balance tuning stays in one table.

## AI

`botInput()` produces an `Input` exactly like a human client, so bots are legal by construction (no aimbots through private state). Decision priority:

1. outside zone → return to zone (dash if far)
2. critically hurt → flee toward heals / away from attacker
3. missing gear → loot run (weapon > shield > heal)
4. landed supply drop nearby → contest (non-defensive personas)
5. combat: strafe orbit at persona-preferred range, lead targets, fire only inside weapon-effective range
6. fallback patrol (tactical personas orbit the zone edge)

Perception is distance-based with an alert multiplier after taking damage; aim error is per-bot and decays with zone phase for late-game pressure.

## Networking & security

- Transport: HTTP polling (85ms) against `/api/rooms/[code]/sync` + SSE stream for lobby updates — works through restrictive proxies, no sticky sessions needed
- The server **never trusts the client**: `applyInput` clamps movement vectors and aim coordinates; names/chat are sanitized; room actions check membership/host
- Progression endpoint clamps every stat to per-match bounds (kills ≤ 30, damage ≤ 4000, hits ≤ shots, win requires placement #1), so XP cannot be meaningfully forged
- Reconnect: 25s grace, 75s gone; placements persist in the world snapshot

## Persistence (Drizzle / PostgreSQL)

| Table | Purpose |
| ----- | ------- |
| `rooms`, `room_players`, `chat_messages` | multiplayer lifecycle, world snapshot as `jsonb` |
| `scores` | per-match leaderboard entries |
| `profiles` | career progression: xp, level, aggregate stats, weapon usage jsonb |
| `seasons`, `challenges`, `player_challenges` | season framework; challenge progress is *derived* from profiles (read-only, always consistent) |
| `cosmetics`, `player_cosmetics` | unlockable cosmetics framework (level-gated, no payments) |

## Rendering & performance

- Single canvas, zoom-adaptive camera with clamped bounds and shake
- Particle budget by quality tier (40/90/220/420) with reduced-motion support
- Off-screen culling for pickups/players; gradients/grain/vignette cached per canvas size
- Damage numbers are particles (`kind: "text"`) — no DOM churn during combat
- HUD React state is throttled to ~9 updates/s; the render loop itself never allocates React state

## Extensibility map

| Want to add… | Touch |
| ------------ | ----- |
| a weapon | `weapons.ts` (one entry) + optional SFX tone |
| a pickup type | `PickupKind`, `rollPickupKind`, `collectPickup`, one render case |
| a bot persona | `PERSONAS` + `personaTuning` |
| a world event | `WorldEventKind`, `pushEvent` call site, renderer/audio case |
| a challenge | one row in `challenges` (metric mapped in `/api/season`) |
| a cosmetic | one row in `cosmetics` |
| biomes/buildings | extend `HotZone` into typed districts; renderer already draws per-zone overlays; collision hooks live in the player integration block |
| spectator mode | the client already renders any `World` snapshot with a free camera focus — feed it a different focus target |
