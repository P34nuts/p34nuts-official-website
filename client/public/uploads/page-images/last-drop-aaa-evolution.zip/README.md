# Last Drop — Ultimate Fusion Edition

Last Drop is a fast browser/mobile battle royale in which hydration is survival. Move through a large arena, collect water, outplay bots or friends, and stay inside the shrinking evaporation zone.

This Version 3 is a deliberate fusion of the two supplied projects:

- **Project 2 as the technical foundation:** larger 2600×2600 world, fixed-step engine, dedicated renderer/input/audio modules, zone phases, client prediction and responsive play screen.
- **Project 1 systems integrated at the product layer:** room-based multiplayer, lobby readiness, chat, bot fill, rematch flow, score persistence, leaderboard/profile endpoints, PWA/offline shell and mobile-first controls.

## Features

- Solo practice against tactical AI, fully playable without a server once loaded
- Online rooms for up to eight players with ready-up, bots, chat, reconnect grace and rematch
- Server-authoritative room simulation with fixed-step updates and validated input packets
- Large arena, fast combat, dash, projectiles, pickups and a multi-phase shrinking zone
- Desktop keyboard/mouse, gamepad and touch input with portrait/landscape-safe layout
- Responsive canvas renderer with quality tiers, particles, camera smoothing, HUD and result screen
- Persistent scores through Drizzle/PostgreSQL, leaderboard and profile summaries
- Installable PWA assets and offline shell

## Run locally

```bash
npm install
cp .env.example .env.local   # set DATABASE_URL for multiplayer persistence
npx drizzle-kit push
npm run dev                   # http://localhost:3000
```

For production:

```bash
npm run build
npm run start
```

Useful checks:

```bash
npm run lint
npm run typecheck
npm run test:sim
```

Solo mode is designed to remain useful without a database. Room creation, chat and score persistence require `DATABASE_URL`.

## Architecture

```text
src/
  app/                    Next.js routes, layout and API endpoints
    api/rooms/             room create/join/actions/sync + SSE stream
    api/scores/            score submission and ranking
    api/leaderboard/       social leaderboard view
    api/profile/           player score summary
  components/              MenuScreen, GameClient and reusable icons
  game/
    engine.ts              authoritative fixed-step world simulation and AI
    types.ts               shared DOM/server-neutral world and lobby types
    render.ts              canvas renderer, effects, camera and quality tiers
    input.ts               keyboard, mouse, touch and gamepad input
    audio.ts               WebAudio feedback layer
  lib/
    net-client.ts          room/score API client
    settings.ts            local settings, profile id and match history
  server/rooms.ts          persistent rooms, chat, bot fill, reconnect and scores
  db/                      Drizzle schema and database connection
```

The simulation is kept in one shared engine. The browser runs it for solo/prediction; the room service runs the same rules authoritatively for online matches. Clients send movement/aim/fire/dash intent only — never positions, damage or winners.

## API

- `POST /api/rooms` — create or join a room
- `GET/POST /api/rooms/:code` — lobby state and ready/start/chat/rematch/leave actions
- `POST /api/rooms/:code/sync` — validated input and authoritative snapshot
- `GET /api/rooms/:code/stream` — short-lived SSE snapshot stream for compatible clients
- `GET/POST /api/scores` — ranking and score submission
- `GET /api/leaderboard` — public top scores
- `GET /api/profile?id=...` — player score summary
- `GET /api/health` — health probe

## Controls

| Platform | Move | Aim / fire | Dash | Menu |
| --- | --- | --- | --- | --- |
| Desktop | WASD / arrows | mouse + left click / Space | Shift / J / right click | Escape |
| Mobile | left virtual stick | right stick / auto aim | Dash button | Pause |
| Gamepad | left stick | right stick + trigger | face/shoulder button | — |

## Tests and limitations

The simulation can be exercised without a browser using `npm run test:sim`. Multiplayer needs a PostgreSQL-compatible `DATABASE_URL`; room state is persisted in the database and the simulation is advanced on sync requests. A single server instance is the supported deployment shape. Multi-instance deployment needs shared database coordination and sticky/session-aware routing.

This package contains the complete source project and assets from the fusion workspace. It is not a mockup or a screenshot-only demo.
