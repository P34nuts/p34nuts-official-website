import { and, desc, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { chatMessages, roomPlayers, rooms, scores } from "@/db/schema";
import { createWorld, getPlayer, ranking, stepWorld, applyInput } from "@/game/engine";
import type { Input, LobbyState, World } from "@/game/types";

const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const GRACE_MS = 25_000;
const GONE_MS = 75_000;
const FIXED_STEP = 1 / 30;
const MAX_SIM_SLICE = 0.75;

export function sanitizeName(raw: unknown): string {
  const s = String(raw ?? "")
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 16);
  return s.length > 0 ? s : "PLAYER";
}

export function sanitizeChat(raw: unknown): string {
  const s = String(raw ?? "")
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 140);
  return s;
}

function makeCode(): string {
  let out = "";
  for (let i = 0; i < 5; i++) {
    out += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  }
  return out;
}

function playerId(raw: unknown): string {
  return String(raw ?? "")
    .replace(/[^a-zA-Z0-9_-]/g, "")
    .slice(0, 40);
}

export type RoomError = { ok: false; error: string };
export type RoomOk<T> = { ok: true } & T;

async function uniqueCode(): Promise<string> {
  for (let i = 0; i < 12; i++) {
    const code = makeCode();
    const existing = await db
      .select({ id: rooms.id })
      .from(rooms)
      .where(eq(rooms.code, code))
      .limit(1);
    if (existing.length === 0) return code;
  }
  throw new Error("could not allocate room code");
}

export async function buildLobby(roomId: string): Promise<LobbyState | null> {
  const room = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
  if (!room.length) return null;
  const r = room[0];
  const players = await db
    .select()
    .from(roomPlayers)
    .where(eq(roomPlayers.roomId, roomId))
    .orderBy(roomPlayers.joinedAt);
  const chat = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.roomId, roomId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(24);

  return {
    code: r.code,
    hostId: r.hostId,
    status: (r.status as LobbyState["status"]) ?? "lobby",
    fillBots: r.fillBots,
    maxPlayers: r.maxPlayers,
    updatedAt: r.updatedAt.getTime(),
    players: players.map((p) => ({
      playerId: p.playerId,
      name: p.name,
      isHost: p.isHost,
      isReady: p.isReady,
      isBot: p.isBot,
      connection: (p.connection as "online" | "grace" | "gone") ?? "online",
    })),
    chat: chat
      .map((c) => ({
        id: c.id,
        playerId: c.playerId,
        name: c.name,
        body: c.body,
        at: c.createdAt.getTime(),
      }))
      .reverse(),
  };
}

function emptyLobby(code: string): LobbyState {
  return {
    code,
    hostId: "",
    status: "lobby",
    fillBots: true,
    maxPlayers: 8,
    updatedAt: Date.now(),
    players: [],
    chat: [],
  };
}

async function markSeen(roomId: string, pid: string) {
  await db
    .update(roomPlayers)
    .set({ lastSeenAt: new Date(), connection: "online" })
    .where(and(eq(roomPlayers.roomId, roomId), eq(roomPlayers.playerId, pid)));
}

/** Flags stale players and migrates the host when necessary. */
async function sweepRoom(roomId: string) {
  const now = Date.now();
  const stale = await db
    .select()
    .from(roomPlayers)
    .where(and(eq(roomPlayers.roomId, roomId), eq(roomPlayers.isBot, false)));

  for (const p of stale) {
    const age = now - p.lastSeenAt.getTime();
    const next =
      age > GONE_MS ? "gone" : age > GRACE_MS ? "grace" : "online";
    if (next !== p.connection) {
      await db
        .update(roomPlayers)
        .set({ connection: next })
        .where(eq(roomPlayers.id, p.id));
    }
  }

  const room = await db.select().from(rooms).where(eq(rooms.id, roomId)).limit(1);
  if (!room.length) return;
  const hostStillThere = stale.some(
    (p) => p.playerId === room[0].hostId && p.connection !== "gone",
  );
  if (!hostStillThere) {
    const nextHost = stale.find((p) => p.connection !== "gone");
    if (nextHost) {
      await db
        .update(rooms)
        .set({ hostId: nextHost.playerId, updatedAt: new Date() })
        .where(eq(rooms.id, roomId));
      await db
        .update(roomPlayers)
        .set({ isHost: true })
        .where(eq(roomPlayers.id, nextHost.id));
    }
  }
}

export async function createRoom(opts: {
  name: string;
  playerId: string;
  fillBots?: boolean;
  maxPlayers?: number;
}): Promise<RoomOk<{ code: string; lobby: LobbyState }> | RoomError> {
  const pid = playerId(opts.playerId);
  if (!pid) return { ok: false, error: "Invalid player id" };
  const name = sanitizeName(opts.name);
  const code = await uniqueCode();

  const inserted = await db
    .insert(rooms)
    .values({
      code,
      hostId: pid,
      status: "lobby",
      fillBots: opts.fillBots ?? true,
      maxPlayers: Math.min(8, Math.max(2, opts.maxPlayers ?? 8)),
    })
    .returning();

  const room = inserted[0];
  await db.insert(roomPlayers).values({
    roomId: room.id,
    playerId: pid,
    name,
    isHost: true,
    isReady: true,
  });

  const lobby = await buildLobby(room.id);
  return { ok: true, code, lobby: lobby! };
}

export async function joinRoom(opts: {
  code: string;
  name: string;
  playerId: string;
}): Promise<RoomOk<{ lobby: LobbyState }> | RoomError> {
  const pid = playerId(opts.playerId);
  if (!pid) return { ok: false, error: "Invalid player id" };
  const code = String(opts.code ?? "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 8);

  const found = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!found.length) return { ok: false, error: "Room not found" };
  const room = found[0];

  const existing = await db
    .select()
    .from(roomPlayers)
    .where(and(eq(roomPlayers.roomId, room.id), eq(roomPlayers.playerId, pid)))
    .limit(1);

  const name = sanitizeName(opts.name);

  if (existing.length) {
    await db
      .update(roomPlayers)
      .set({ connection: "online", lastSeenAt: new Date(), name })
      .where(eq(roomPlayers.id, existing[0].id));
    const lobby = await buildLobby(room.id);
    return { ok: true, lobby: lobby! };
  }

  const count = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(roomPlayers)
    .where(and(eq(roomPlayers.roomId, room.id), eq(roomPlayers.isBot, false)));
  const humans = count[0]?.c ?? 0;
  const nonGone = await db
    .select()
    .from(roomPlayers)
    .where(eq(roomPlayers.roomId, room.id));
  const active = nonGone.filter((p) => p.connection !== "gone" || p.isBot).length;
  if (humans >= room.maxPlayers || active >= room.maxPlayers) {
    return { ok: false, error: "Room is full" };
  }

  await db.insert(roomPlayers).values({
    roomId: room.id,
    playerId: pid,
    name,
    isHost: false,
    isReady: false,
  });

  const lobby = await buildLobby(room.id);
  return { ok: true, lobby: lobby! };
}

export async function leaveRoom(code: string, pid: string) {
  const found = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!found.length) return { ok: true as const };
  const room = found[0];
  await db
    .delete(roomPlayers)
    .where(and(eq(roomPlayers.roomId, room.id), eq(roomPlayers.playerId, pid)));
  await sweepRoom(room.id);
  const remaining = await db
    .select()
    .from(roomPlayers)
    .where(eq(roomPlayers.roomId, room.id));
  if (!remaining.length) {
    await db.delete(rooms).where(eq(rooms.id, room.id));
  }
  return { ok: true as const };
}

export type LobbyAction =
  | { action: "ready"; ready: boolean }
  | { action: "start" }
  | { action: "rematch" }
  | { action: "settings"; fillBots: boolean }
  | { action: "chat"; body: string }
  | { action: "leave" };

export async function handleLobbyAction(
  code: string,
  pid: string,
  payload: LobbyAction,
): Promise<RoomOk<{ lobby: LobbyState }> | RoomError> {
  const found = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!found.length) return { ok: false, error: "Room not found" };
  const room = found[0];
  const me = await db
    .select()
    .from(roomPlayers)
    .where(and(eq(roomPlayers.roomId, room.id), eq(roomPlayers.playerId, pid)))
    .limit(1);
  if (!me.length) return { ok: false, error: "You are not in this room" };

  await markSeen(room.id, pid);

  if (payload.action === "leave") {
    await leaveRoom(code, pid);
    const lobby = await buildLobby(room.id);
    return { ok: true, lobby: lobby ?? emptyLobby(room.code) };
  }

  if (payload.action === "ready") {
    await db
      .update(roomPlayers)
      .set({ isReady: Boolean(payload.ready) })
      .where(eq(roomPlayers.id, me[0].id));
  }

  if (payload.action === "settings") {
    if (!me[0].isHost) return { ok: false, error: "Only the host can change settings" };
    await db
      .update(rooms)
      .set({ fillBots: Boolean(payload.fillBots), updatedAt: new Date() })
      .where(eq(rooms.id, room.id));
  }

  if (payload.action === "chat") {
    const body = sanitizeChat(payload.body);
    if (!body) return { ok: false, error: "Empty message" };
    const recent = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(chatMessages)
      .where(
        and(
          eq(chatMessages.roomId, room.id),
          eq(chatMessages.playerId, pid),
          gt(chatMessages.createdAt, new Date(Date.now() - 6000)),
        ),
      );
    if ((recent[0]?.c ?? 0) >= 5) return { ok: false, error: "Slow down" };
    await db
      .insert(chatMessages)
      .values({ roomId: room.id, playerId: pid, name: me[0].name, body });
  }

  if (payload.action === "start" || payload.action === "rematch") {
    if (!me[0].isHost) return { ok: false, error: "Only the host can start" };
    const players = await db
      .select()
      .from(roomPlayers)
      .where(eq(roomPlayers.roomId, room.id));
    const humans = players.filter((p) => p.connection !== "gone" && !p.isBot);
    if (humans.length === 0) return { ok: false, error: "No players" };
    if (payload.action === "start" && humans.some((p) => !p.isReady)) {
      return { ok: false, error: "Not everyone is ready" };
    }

    await db.delete(roomPlayers).where(and(eq(roomPlayers.roomId, room.id), eq(roomPlayers.isBot, true)));

    const roster: { id: string; name: string; isBot: boolean }[] = humans.map(
      (p) => ({ id: p.playerId, name: p.name, isBot: false }),
    );
    const botNames = [
      "TIDE",
      "BRINE",
      "MIST",
      "RIVULET",
      "PUDDLE",
      "SURGE",
      "DEW",
      "LAGOON",
    ];
    if (room.fillBots) {
      const wanted = Math.max(4, Math.min(8, roster.length + 3));
      for (let i = roster.length; i < wanted; i++) {
        const botId = `bot-${i}-${Math.random().toString(36).slice(2, 8)}`;
        const botName = botNames[i % botNames.length];
        roster.push({ id: botId, name: botName, isBot: true });
        await db.insert(roomPlayers).values({
          roomId: room.id,
          playerId: botId,
          name: botName,
          isBot: true,
          isReady: true,
          connection: "online",
        });
      }
    }

    const world = createWorld(roster);
    await db
      .update(rooms)
      .set({
        world,
        status: "countdown",
        updatedAt: new Date(),
        lastSyncAt: new Date(),
      })
      .where(eq(rooms.id, room.id));
    await db
      .update(roomPlayers)
      .set({ isReady: true })
      .where(eq(roomPlayers.roomId, room.id));
  }

  const lobby = await buildLobby(room.id);
  return { ok: true, lobby: lobby ?? emptyLobby(room.code) };
}

export async function syncRoom(
  code: string,
  pid: string,
  input: Partial<Input>,
): Promise<
  RoomOk<{ world: World | null; lobby: LobbyState | null; serverTime: number }> | RoomError
> {
  const started = Date.now();
  const found = await db.select().from(rooms).where(eq(rooms.code, code)).limit(1);
  if (!found.length) return { ok: false, error: "Room not found" };
  const room = found[0];

  const result = await db.transaction(async (tx) => {
    const locked = await tx
      .select()
      .from(rooms)
      .where(eq(rooms.id, room.id))
      .for("update")
      .limit(1);
    const r = locked[0];
    if (!r) return { error: "Room not found" };

    await tx
      .update(roomPlayers)
      .set({ lastSeenAt: new Date(), connection: "online" })
      .where(and(eq(roomPlayers.roomId, r.id), eq(roomPlayers.playerId, pid)));

    const world = r.world;
    if (world && (world.status === "playing" || world.status === "countdown")) {
      const now = Date.now();
      const elapsed = Math.min(
        MAX_SIM_SLICE,
        Math.max(0, (now - r.lastSyncAt.getTime()) / 1000),
      );
      const prevStatus: string = world.status;
      if (input && Object.keys(input).length) applyInput(world, pid, input);
      world.acc = (world.acc ?? 0) + elapsed;
      let guard = 0;
      while (world.acc >= FIXED_STEP && guard < 60) {
        stepWorld(world, FIXED_STEP);
        world.acc -= FIXED_STEP;
        guard++;
      }
      if (world.acc > FIXED_STEP) world.acc = 0;

      const statusNow: string = world.status;
      const justEnded = prevStatus !== "ended" && statusNow === "ended";
      await tx
        .update(rooms)
        .set({
          world,
          status: world.status,
          updatedAt: new Date(),
          lastSyncAt: new Date(now),
        })
        .where(eq(rooms.id, r.id));

      if (justEnded) {
        const rows = ranking(world)
          .filter((p) => !p.isBot)
          .slice(0, 8)
          .map((p) => ({
            roomId: r.id,
            playerId: p.id,
            name: p.name,
            score: Math.round(p.score),
            kills: p.kills,
            placement: p.placement || 1,
            mode: "duo",
          }));
        if (rows.length) {
          await tx.insert(scores).values(
            rows.map((row) => ({
              name: row.name.slice(0, 16),
              score: Math.min(60000, Math.max(0, row.score)),
              kills: Math.min(60, Math.max(0, row.kills)),
              placement: Math.min(16, Math.max(1, row.placement)),
              mode: "multi",
            })),
          );
        }
      }
    } else {
      await tx
        .update(rooms)
        .set({ lastSyncAt: new Date(), updatedAt: new Date() })
        .where(eq(rooms.id, r.id));
    }

    return { world: (r.world as World | null) ?? null };
  });

  if ("error" in result) return { ok: false, error: result.error ?? "Room error" };
  const worldOut: World | null = result.world ?? null;

  await sweepRoom(room.id);
  const lobby = await buildLobby(room.id);
  return {
    ok: true,
    world: worldOut,
    lobby,
    serverTime: Date.now() - started,
  };
}

export async function getLeaderboard(limit = 10) {
  return db.select().from(scores).orderBy(desc(scores.score)).limit(limit);
}
