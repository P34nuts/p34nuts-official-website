import {
  boolean,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import type { ChatMessage, World } from "@/game/types";

export const rooms = pgTable("rooms", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: varchar("code", { length: 8 }).notNull().unique(),
  hostId: varchar("host_id", { length: 64 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("lobby"),
  world: jsonb("world").$type<World | null>(),
  maxPlayers: integer("max_players").notNull().default(8),
  fillBots: boolean("fill_bots").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  lastSyncAt: timestamp("last_sync_at", { withTimezone: true }).notNull().defaultNow(),
});

export const roomPlayers = pgTable(
  "room_players",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    roomId: uuid("room_id")
      .notNull()
      .references(() => rooms.id, { onDelete: "cascade" }),
    playerId: varchar("player_id", { length: 64 }).notNull(),
    name: varchar("name", { length: 20 }).notNull(),
    isHost: boolean("is_host").notNull().default(false),
    isReady: boolean("is_ready").notNull().default(false),
    isBot: boolean("is_bot").notNull().default(false),
    connection: varchar("connection", { length: 12 }).notNull().default("online"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    joinedAt: timestamp("joined_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("room_player_unique").on(t.roomId, t.playerId)],
);

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  roomId: uuid("room_id")
    .notNull()
    .references(() => rooms.id, { onDelete: "cascade" }),
  playerId: varchar("player_id", { length: 64 }).notNull(),
  name: varchar("name", { length: 20 }).notNull(),
  body: varchar("body", { length: 160 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const scores = pgTable("scores", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 20 }).notNull(),
  score: integer("score").notNull(),
  kills: integer("kills").notNull().default(0),
  placement: integer("placement").notNull().default(1),
  mode: varchar("mode", { length: 12 }).notNull().default("solo"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type ChatRow = typeof chatMessages.$inferSelect;
export type ScoreRow = typeof scores.$inferSelect;
export type RoomRow = typeof rooms.$inferSelect;
export type RoomPlayerRow = typeof roomPlayers.$inferSelect;

export type StoredChat = ChatMessage;
