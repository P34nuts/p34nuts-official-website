type IconProps = { className?: string; size?: number };

const base = (size: number) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
});

export const IconChevron = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);

export const IconPlay = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <path d="M7 4l13 8-13 8V4z" />
  </svg>
);

export const IconUsers = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <path d="M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="3.2" />
    <path d="M22 20v-2a4 4 0 0 0-3-3.8M16.5 4.2a3.2 3.2 0 0 1 0 5.6" />
  </svg>
);

export const IconGear = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <circle cx="12" cy="12" r="3.2" />
    <path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 9 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 9a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z" />
  </svg>
);

export const IconHelp = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <circle cx="12" cy="12" r="9" />
    <path d="M9.2 9.2a3 3 0 0 1 5.8 1c0 2-3 2.4-3 4" />
    <path d="M12 17.5h.01" />
  </svg>
);

export const IconClose = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);

export const IconCopy = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <rect x="9" y="9" width="12" height="12" rx="1.5" />
    <path d="M5 15V4.5A1.5 1.5 0 0 1 6.5 3H15" />
  </svg>
);

export const IconShare = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <circle cx="18" cy="5" r="2.6" />
    <circle cx="6" cy="12" r="2.6" />
    <circle cx="18" cy="19" r="2.6" />
    <path d="M8.3 10.8l7.4-4.3M8.3 13.2l7.4 4.3" />
  </svg>
);

export const IconTrophy = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <path d="M8 4h8v5a4 4 0 0 1-8 0V4z" />
    <path d="M8 5H5v2a3 3 0 0 0 3 3M16 5h3v2a3 3 0 0 1-3 3" />
    <path d="M12 13v4M9 21h6M10 17h4l1 4H9l1-4z" />
  </svg>
);

export const IconDrop = ({ className, size = 18 }: IconProps) => (
  <svg {...base(size)} className={className}>
    <path d="M12 3.2c3.4 4 5.6 6.7 5.6 9.6a5.6 5.6 0 1 1-11.2 0c0-2.9 2.2-5.6 5.6-9.6z" />
    <path d="M9.4 13.6a2.7 2.7 0 0 0 2.2 3" />
  </svg>
);
