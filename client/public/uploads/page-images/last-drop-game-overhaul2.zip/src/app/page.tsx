import MenuScreen from "@/components/MenuScreen";

export default function HomePage() {
  return <MenuScreen />;
}
