import { createRoom, joinRoom, sanitizeName } from "@/server/rooms";

export const dynamic = "force-dynamic";

const hits = new Map<string, { n: number; t: number }>();
function limited(key: string, max = 12, windowMs = 10_000) {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || now - h.t > windowMs) {
    hits.set(key, { n: 1, t: now });
    return false;
  }
  h.n += 1;
  return h.n > max;
}

export async function POST(req: Request) {
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Bad request" }, { status: 400 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "local";
  if (limited(ip)) {
    return Response.json({ ok: false, error: "Too many requests" }, { status: 429 });
  }

  const action = String(body.action ?? "create");
  const name = sanitizeName(body.name);
  const playerId = String(body.playerId ?? "");

  if (!playerId || playerId.length < 4) {
    return Response.json({ ok: false, error: "Missing player id" }, { status: 400 });
  }

  if (action === "create") {
    const res = await createRoom({
      name,
      playerId,
      fillBots: body.fillBots !== false,
      maxPlayers: Number(body.maxPlayers ?? 8),
    });
    return Response.json(res, { status: res.ok ? 200 : 400 });
  }

  if (action === "join") {
    const res = await joinRoom({ code: String(body.code ?? ""), name, playerId });
    return Response.json(res, { status: res.ok ? 200 : 400 });
  }

  return Response.json({ ok: false, error: "Unknown action" }, { status: 400 });
}
