import { syncRoom } from "@/server/rooms";
import type { Input } from "@/game/types";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ code: string }> };

const hits = new Map<string, { n: number; t: number }>();
function limited(key: string, max = 40, windowMs = 5000) {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || now - h.t > windowMs) {
    hits.set(key, { n: 1, t: now });
    return false;
  }
  h.n += 1;
  return h.n > max;
}

export async function POST(req: Request, { params }: Params) {
  const { code } = await params;
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Bad request" }, { status: 400 });
  }

  const pid = String(body.playerId ?? "");
  if (!pid) {
    return Response.json({ ok: false, error: "Missing player id" }, { status: 400 });
  }
  if (limited(pid)) {
    return Response.json({ ok: false, error: "Rate limited" }, { status: 429 });
  }

  const input = (body.input ?? {}) as Partial<Input>;
  const res = await syncRoom(code.toUpperCase(), pid, {
    mx: Number(input.mx ?? 0),
    my: Number(input.my ?? 0),
    aimX: Number(input.aimX ?? 0),
    aimY: Number(input.aimY ?? 0),
    fire: Boolean(input.fire),
    dash: Boolean(input.dash),
    seq: Number(input.seq ?? 0),
  });

  return Response.json(res, { status: res.ok ? 200 : 400 });
}
