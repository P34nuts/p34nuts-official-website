import { buildLobby, handleLobbyAction, type LobbyAction } from "@/server/rooms";
import { db } from "@/db";
import { rooms } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ code: string }> };

export async function GET(_req: Request, { params }: Params) {
  const { code } = await params;
  const found = await db
    .select()
    .from(rooms)
    .where(eq(rooms.code, code.toUpperCase()))
    .limit(1);
  if (!found.length) {
    return Response.json({ ok: false, error: "Room not found" }, { status: 404 });
  }
  const lobby = await buildLobby(found[0].id);
  return Response.json({ ok: true, lobby });
}

export async function POST(req: Request, { params }: Params) {
  const { code } = await params;
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Bad request" }, { status: 400 });
  }
  const pid = String(body.playerId ?? "");
  if (!pid) {
    return Response.json({ ok: false, error: "Missing player id" }, { status: 400 });
  }

  const res = await handleLobbyAction(
    code.toUpperCase(),
    pid,
    body as unknown as LobbyAction,
  );
  return Response.json(res, { status: res.ok ? 200 : 400 });
}
