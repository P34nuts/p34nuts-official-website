import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { scores } from "@/db/schema";
import { sanitizeName } from "@/server/rooms";

export const dynamic = "force-dynamic";

const hits = new Map<string, { n: number; t: number }>();
function limited(key: string, max = 6, windowMs = 60_000) {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || now - h.t > windowMs) {
    hits.set(key, { n: 1, t: now });
    return false;
  }
  h.n += 1;
  return h.n > max;
}

export async function GET() {
  const rows = await db
    .select()
    .from(scores)
    .orderBy(desc(scores.score))
    .limit(12);
  return Response.json({
    ok: true,
    entries: rows.map((r) => ({
      name: r.name,
      score: r.score,
      kills: r.kills,
      placement: r.placement,
      mode: r.mode,
      at: r.createdAt.getTime(),
    })),
  });
}

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for") ?? "local";
  if (limited(ip)) {
    return Response.json({ ok: false, error: "Too many requests" }, { status: 429 });
  }
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Bad request" }, { status: 400 });
  }

  const name = sanitizeName(body.name);
  const score = Math.round(Number(body.score ?? 0));
  const kills = Math.round(Number(body.kills ?? 0));
  const placement = Math.round(Number(body.placement ?? 1));
  const mode = body.mode === "multi" ? "multi" : "solo";

  if (!Number.isFinite(score) || score < 0 || score > 60000) {
    return Response.json({ ok: false, error: "Invalid score" }, { status: 400 });
  }
  if (!Number.isFinite(kills) || kills < 0 || kills > 60) {
    return Response.json({ ok: false, error: "Invalid kills" }, { status: 400 });
  }

  await db.insert(scores).values({
    name,
    score,
    kills: Math.min(60, Math.max(0, kills)),
    placement: Math.min(16, Math.max(1, placement)),
    mode,
  });

  const rows = await db.select().from(scores).orderBy(desc(scores.score)).limit(12);
  return Response.json({
    ok: true,
    entries: rows.map((r) => ({
      name: r.name,
      score: r.score,
      kills: r.kills,
      placement: r.placement,
      mode: r.mode,
      at: r.createdAt.getTime(),
    })),
  });
}
