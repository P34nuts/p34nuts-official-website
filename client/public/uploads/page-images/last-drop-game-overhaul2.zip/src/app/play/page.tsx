import { Suspense } from "react";
import GameClient from "@/components/GameClient";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>;

function read(params: { [key: string]: string | string[] | undefined }, key: string) {
  const v = params[key];
  return typeof v === "string" ? v : "";
}

export default async function PlayPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;
  const room = read(params, "room").toUpperCase();
  const modeParam = read(params, "mode");
  const mode: "solo" | "multi" = room ? "multi" : modeParam === "multi" ? "multi" : "solo";

  return (
    <Suspense
      fallback={
        <div className="game-root grid place-items-center text-paper">
          <div className="display text-[clamp(2.4rem,10vw,5rem)]">Last Drop</div>
        </div>
      }
    >
      <GameClient code={room} mode={mode} />
    </Suspense>
  );
}
