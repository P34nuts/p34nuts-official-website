/**
 * Tiny synthesized audio kit — no external assets, no autoplay problems.
 * The context is created lazily on the first user gesture.
 */

export type SfxName =
  | "click"
  | "back"
  | "ready"
  | "countdown"
  | "start"
  | "shoot"
  | "hit"
  | "damage"
  | "pickup"
  | "dash"
  | "elimination"
  | "victory"
  | "defeat"
  | "zone"
  | "error"
  | "join";

type Tone = {
  freq: number;
  to?: number;
  dur: number;
  type?: OscillatorType;
  gain?: number;
  delay?: number;
  filter?: number;
};

const KIT: Record<SfxName, Tone[]> = {
  click: [{ freq: 620, dur: 0.055, type: "square", gain: 0.11 }],
  back: [{ freq: 300, to: 190, dur: 0.11, type: "square", gain: 0.1 }],
  ready: [
    { freq: 520, dur: 0.08, type: "triangle", gain: 0.14 },
    { freq: 780, dur: 0.1, type: "triangle", gain: 0.12, delay: 0.08 },
  ],
  join: [
    { freq: 420, dur: 0.09, type: "sine", gain: 0.13 },
    { freq: 630, dur: 0.12, type: "sine", gain: 0.11, delay: 0.09 },
    { freq: 840, dur: 0.16, type: "sine", gain: 0.09, delay: 0.18 },
  ],
  countdown: [{ freq: 400, dur: 0.16, type: "square", gain: 0.13, filter: 1400 }],
  start: [
    { freq: 220, to: 660, dur: 0.42, type: "sawtooth", gain: 0.16, filter: 2200 },
    { freq: 110, dur: 0.5, type: "sine", gain: 0.16 },
  ],
  shoot: [
    { freq: 760, to: 320, dur: 0.075, type: "triangle", gain: 0.075, filter: 2600 },
  ],
  hit: [{ freq: 240, to: 90, dur: 0.11, type: "square", gain: 0.12, filter: 900 }],
  damage: [
    { freq: 170, to: 70, dur: 0.2, type: "sawtooth", gain: 0.16, filter: 700 },
  ],
  pickup: [
    { freq: 700, dur: 0.07, type: "sine", gain: 0.12 },
    { freq: 1050, dur: 0.11, type: "sine", gain: 0.1, delay: 0.06 },
  ],
  dash: [{ freq: 320, to: 900, dur: 0.16, type: "sawtooth", gain: 0.09, filter: 1800 }],
  elimination: [
    { freq: 180, to: 60, dur: 0.5, type: "sawtooth", gain: 0.17, filter: 800 },
    { freq: 90, dur: 0.55, type: "sine", gain: 0.16, delay: 0.04 },
  ],
  victory: [
    { freq: 392, dur: 0.16, type: "triangle", gain: 0.15 },
    { freq: 523, dur: 0.16, type: "triangle", gain: 0.15, delay: 0.14 },
    { freq: 659, dur: 0.16, type: "triangle", gain: 0.15, delay: 0.28 },
    { freq: 784, dur: 0.5, type: "triangle", gain: 0.16, delay: 0.42 },
  ],
  defeat: [
    { freq: 330, dur: 0.22, type: "triangle", gain: 0.14 },
    { freq: 262, dur: 0.24, type: "triangle", gain: 0.14, delay: 0.18 },
    { freq: 196, dur: 0.6, type: "triangle", gain: 0.15, delay: 0.38 },
  ],
  zone: [{ freq: 120, to: 60, dur: 0.9, type: "sine", gain: 0.12 }],
  error: [
    { freq: 200, dur: 0.1, type: "square", gain: 0.11 },
    { freq: 150, dur: 0.16, type: "square", gain: 0.11, delay: 0.1 },
  ],
};

export class GameAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private musicNodes: OscillatorNode[] = [];
  private musicTimer: ReturnType<typeof setInterval> | null = null;
  sfxEnabled = true;
  musicEnabled = true;
  volume = 0.8;

  init() {
    if (this.ctx) return;
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AC) return;
    try {
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0;
      this.musicGain.connect(this.master);
    } catch {
      this.ctx = null;
    }
  }

  resume() {
    this.init();
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master) this.master.gain.value = v;
  }

  play(name: SfxName) {
    if (!this.sfxEnabled) return;
    this.init();
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    if (ctx.state === "suspended") void ctx.resume();
    const tones = KIT[name];
    const now = ctx.currentTime;
    for (const t of tones) {
      const start = now + (t.delay ?? 0);
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = t.type ?? "sine";
      osc.frequency.setValueAtTime(t.freq, start);
      if (t.to) osc.frequency.exponentialRampToValueAtTime(Math.max(20, t.to), start + t.dur);
      const peak = t.gain ?? 0.12;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(peak, start + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + t.dur);
      let node: AudioNode = osc;
      if (t.filter) {
        const f = ctx.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.value = t.filter;
        osc.connect(f);
        node = f;
      }
      node.connect(gain);
      gain.connect(this.master);
      osc.start(start);
      osc.stop(start + t.dur + 0.05);
    }
  }

  startMusic() {
    this.init();
    const ctx = this.ctx;
    if (!ctx || !this.musicGain || this.musicNodes.length) return;
    const musicGain: GainNode = this.musicGain;
    const notes = [110, 164.81, 220];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      osc.type = i === 2 ? "triangle" : "sawtooth";
      osc.frequency.value = freq;
      osc.detune.value = (i - 1) * 7;
      filter.type = "lowpass";
      filter.frequency.value = 460;
      gain.gain.value = i === 2 ? 0.05 : 0.035;
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(musicGain);
      osc.start();
      this.musicNodes.push(osc);

      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.value = 0.05 + i * 0.031;
      lfoGain.gain.value = 120;
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start();
      this.musicNodes.push(lfo);
    });

    if (this.musicEnabled) {
      this.musicGain.gain.setTargetAtTime(0.55, ctx.currentTime, 1.2);
    }

    if (!this.musicTimer) {
      this.musicTimer = setInterval(() => {
        if (!this.ctx || !this.musicGain) return;
        const t = this.ctx.currentTime;
        const target = this.musicEnabled ? 0.55 : 0.0001;
        this.musicGain.gain.setTargetAtTime(target, t, 0.6);
      }, 500);
    }
  }

  stopMusic() {
    this.musicNodes.forEach((n) => {
      try {
        n.stop();
      } catch {
        /* already stopped */
      }
    });
    this.musicNodes = [];
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.2);
    }
  }

  setMusicEnabled(on: boolean) {
    this.musicEnabled = on;
    if (on) this.startMusic();
    else if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.3);
    }
  }
}

export const audio = new GameAudio();
