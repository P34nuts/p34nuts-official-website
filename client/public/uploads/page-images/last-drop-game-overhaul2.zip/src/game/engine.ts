import {
  EMPTY_INPUT,
  type AIState,
  type Bullet,
  type Input,
  type Pickup,
  type Player,
  type World,
  type WorldEventKind,
} from "./types";

export const CFG = {
  worldW: 2600,
  worldH: 2600,
  playerRadius: 25,
  speed: 335,
  hp: 100,
  bulletSpeed: 1020,
  bulletDamage: 11,
  bulletRadius: 9,
  bulletLife: 1.15,
  fireCooldown: 0.19,
  ammoMax: 100,
  ammoCost: 8.5,
  ammoRegen: 30,
  dashSpeed: 940,
  dashTime: 0.17,
  dashCooldown: 1.8,
  pickupRadius: 21,
  pickupHeal: 22,
  pickupScore: 45,
  pickupCount: 44,
  pickupRespawn: 2.4,
  matchTimeLimit: 300,
  zoneStartR: 1180,
  zoneDamageBase: 5.5,
};

export const ZONE_RADII = [920, 690, 500, 350, 225, 125, 45];
export const ZONE_HOLDS = [15, 13, 12, 11, 10, 9, 9];
export const ZONE_SHRINK_TIME = 12;

export const PLAYER_COLORS = [
  "#00C2D1",
  "#FF4E20",
  "#FFC53D",
  "#3DD68C",
  "#FF6FA5",
  "#6FA8FF",
  "#C79BFF",
  "#9BE15D",
];

const TAU = Math.PI * 2;

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function norm(x: number, y: number) {
  const d = Math.hypot(x, y);
  return d > 0.0001 ? { x: x / d, y: y / d } : { x: 0, y: 0 };
}

function pushEvent(
  w: World,
  kind: WorldEventKind,
  x: number,
  y: number,
  a = 0,
  p = "",
  s = 1,
) {
  w.events.push({ id: w.eventSeq++, kind, x, y, a, p, s });
  if (w.events.length > 90) w.events.splice(0, w.events.length - 90);
}

function makeAI(): AIState {
  return { targetId: null, strafe: Math.random() > 0.5 ? 1 : -1, retargetIn: 0, jitter: Math.random() * 10 };
}

export function makePlayer(
  id: string,
  name: string,
  isBot: boolean,
  index: number,
  total: number,
): Player {
  const ring = total <= 1 ? 0 : 760;
  const ang = (index / Math.max(1, total)) * TAU + 0.4;
  return {
    id,
    name,
    color: PLAYER_COLORS[index % PLAYER_COLORS.length],
    isBot,
    x: CFG.worldW / 2 + Math.cos(ang) * ring + rand(-70, 70),
    y: CFG.worldH / 2 + Math.sin(ang) * ring + rand(-70, 70),
    vx: 0,
    vy: 0,
    angle: ang,
    hp: CFG.hp,
    alive: true,
    ammo: CFG.ammoMax,
    fireCd: 0,
    dashCd: 0,
    dashTime: 0,
    kills: 0,
    score: 0,
    placement: 0,
    hitFlash: 0,
    protect: 2.2,
    connected: !isBot,
    input: { ...EMPTY_INPUT },
    ai: makeAI(),
  };
}

function spawnPickup(w: World) {
  const margin = 160;
  w.pickups.push({
    id: w.nextId++,
    x: rand(margin, CFG.worldW - margin),
    y: rand(margin, CFG.worldH - margin),
    r: CFG.pickupRadius,
    bob: Math.random() * TAU,
  });
}

export function createWorld(
  roster: { id: string; name: string; isBot: boolean }[],
  opts: { timeLimit?: number } = {},
): World {
  const w: World = {
    tick: 0,
    time: 0,
    acc: 0,
    status: "countdown",
    countdown: 3.2,
    players: [],
    bullets: [],
    pickups: [],
    events: [],
    eventSeq: 1,
    nextId: 1,
    zone: {
      x: CFG.worldW / 2,
      y: CFG.worldH / 2,
      r: CFG.zoneStartR,
      targetR: CFG.zoneStartR,
      phase: 0,
      timer: ZONE_HOLDS[0],
      shrinking: false,
    },
    winnerId: null,
    endedAt: 0,
    timeLimit: opts.timeLimit ?? CFG.matchTimeLimit,
  };
  roster.forEach((r, i) =>
    w.players.push(makePlayer(r.id, r.name, r.isBot, i, roster.length)),
  );
  for (let i = 0; i < CFG.pickupCount; i++) spawnPickup(w);
  return w;
}

export function getPlayer(w: World, id: string) {
  return w.players.find((p) => p.id === id);
}

/** Apply one input packet to a player (server + prediction). */
export function applyInput(w: World, id: string, input: Partial<Input>) {
  const p = getPlayer(w, id);
  if (!p) return;
  const mx = clamp(Number(input.mx ?? 0), -1, 1);
  const my = clamp(Number(input.my ?? 0), -1, 1);
  const mag = Math.hypot(mx, my);
  p.input = {
    mx: mag > 1 ? mx / mag : mx,
    my: mag > 1 ? my / mag : my,
    aimX: Number(input.aimX ?? p.x),
    aimY: Number(input.aimY ?? p.y),
    fire: Boolean(input.fire),
    dash: Boolean(input.dash),
    seq: Number(input.seq ?? 0),
  };
}

function clamp(v: number, lo: number, hi: number) {
  return v < lo ? lo : v > hi ? hi : v;
}

function damagePlayer(w: World, p: Player, amount: number, sourceId: string | null, angle: number, knock = 0) {
  if (!p.alive || p.protect > 0) return;
  p.hp -= amount;
  p.hitFlash = 0.22;
  if (knock > 0) {
    p.vx += Math.cos(angle) * knock;
    p.vy += Math.sin(angle) * knock;
  }
  pushEvent(w, "hit", p.x, p.y, angle, p.id, Math.min(1, amount / 22));
  if (p.hp <= 0) {
    p.hp = 0;
    p.alive = false;
    const aliveCount = w.players.filter((x) => x.alive).length;
    p.placement = aliveCount + 1;
    pushEvent(w, "death", p.x, p.y, angle, p.id, 1);
    if (sourceId && sourceId !== p.id) {
      const killer = getPlayer(w, sourceId);
      if (killer) {
        killer.kills += 1;
        killer.score += 260;
      }
    }
  }
}

function endMatch(w: World) {
  if (w.status === "ended") return;
  w.status = "ended";
  w.endedAt = w.time;
  const alive = w.players.filter((p) => p.alive);
  [...alive]
    .sort((a, b) => b.score - a.score)
    .forEach((p, i) => (p.placement = i + 1));
  const sorted = [...w.players].sort((a, b) => {
    if (a.placement !== b.placement) return a.placement - b.placement;
    return b.score - a.score;
  });
  w.winnerId = sorted[0]?.id ?? null;
  pushEvent(w, "zone", w.zone.x, w.zone.y, 0, "", 1);
}

/** Advance the authoritative simulation by a fixed timestep. */
export function stepWorld(w: World, dt: number) {
  w.tick++;

  if (w.status === "countdown") {
    w.countdown -= dt;
    if (w.countdown <= 0) {
      w.countdown = 0;
      w.status = "playing";
      w.time = 0;
      pushEvent(w, "start", w.zone.x, w.zone.y, 0, "", 1);
    }
    return;
  }
  if (w.status !== "playing") return;

  w.time += dt;

  // --- players ---------------------------------------------------------
  for (const p of w.players) {
    if (!p.alive) continue;
    p.hitFlash = Math.max(0, p.hitFlash - dt);
    p.protect = Math.max(0, p.protect - dt);
    p.fireCd = Math.max(0, p.fireCd - dt);
    p.dashCd = Math.max(0, p.dashCd - dt);
    p.dashTime = Math.max(0, p.dashTime - dt);
    p.ammo = Math.min(CFG.ammoMax, p.ammo + CFG.ammoRegen * dt);

    const input = p.isBot ? botInput(w, p, dt) : p.input;

    const mag = Math.hypot(input.mx, input.my);
    const dirX = mag > 0.01 ? input.mx / mag : 0;
    const dirY = mag > 0.01 ? input.my / mag : 0;

    if (input.dash && p.dashCd <= 0 && mag > 0.01) {
      p.dashCd = CFG.dashCooldown;
      p.dashTime = CFG.dashTime;
      p.vx = dirX * CFG.dashSpeed;
      p.vy = dirY * CFG.dashSpeed;
      pushEvent(w, "dash", p.x, p.y, Math.atan2(dirY, dirX), p.id, 1);
    }

    const speed = CFG.speed * (p.dashTime > 0 ? 1.75 : 1);
    const targetVx = dirX * speed;
    const targetVy = dirY * speed;
    const blend = Math.min(1, dt * (p.dashTime > 0 ? 3 : 13));
    if (p.dashTime <= 0) {
      p.vx += (targetVx - p.vx) * blend;
      p.vy += (targetVy - p.vy) * blend;
    }

    p.x += p.vx * dt;
    p.y += p.vy * dt;

    const r = CFG.playerRadius;
    if (p.x < r) {
      p.x = r;
      p.vx = Math.abs(p.vx) * 0.35;
    }
    if (p.x > CFG.worldW - r) {
      p.x = CFG.worldW - r;
      p.vx = -Math.abs(p.vx) * 0.35;
    }
    if (p.y < r) {
      p.y = r;
      p.vy = Math.abs(p.vy) * 0.35;
    }
    if (p.y > CFG.worldH - r) {
      p.y = CFG.worldH - r;
      p.vy = -Math.abs(p.vy) * 0.35;
    }

    const aimAng = Math.atan2(input.aimY - p.y, input.aimX - p.x);
    if (Number.isFinite(aimAng)) p.angle = aimAng;

    if (input.fire && p.fireCd <= 0 && p.ammo >= CFG.ammoCost) {
      p.fireCd = CFG.fireCooldown;
      p.ammo -= CFG.ammoCost;
      const a = p.angle + rand(-0.035, 0.035);
      w.bullets.push({
        id: w.nextId++,
        ownerId: p.id,
        x: p.x + Math.cos(a) * (r + 12),
        y: p.y + Math.sin(a) * (r + 12),
        vx: Math.cos(a) * CFG.bulletSpeed + p.vx * 0.25,
        vy: Math.sin(a) * CFG.bulletSpeed + p.vy * 0.25,
        life: CFG.bulletLife,
        r: CFG.bulletRadius,
        damage: CFG.bulletDamage,
        color: p.color,
      });
      pushEvent(w, "shoot", p.x, p.y, a, p.id, 1);
    }
  }

  // --- bullets ---------------------------------------------------------
  for (const b of w.bullets) {
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    if (
      b.life <= 0 ||
      b.x < -60 ||
      b.y < -60 ||
      b.x > CFG.worldW + 60 ||
      b.y > CFG.worldH + 60
    ) {
      b.life = -1;
      continue;
    }
    for (const p of w.players) {
      if (!p.alive || p.id === b.ownerId) continue;
      const dx = p.x - b.x;
      const dy = p.y - b.y;
      const rr = CFG.playerRadius + b.r;
      if (dx * dx + dy * dy <= rr * rr) {
        b.life = -1;
        damagePlayer(
          w,
          p,
          b.damage,
          b.ownerId,
          Math.atan2(b.vy, b.vx),
          118,
        );
        break;
      }
    }
  }
  if (w.bullets.some((b) => b.life <= 0)) {
    w.bullets = w.bullets.filter((b) => b.life > 0);
  }

  // --- pickups ---------------------------------------------------------
  for (const pk of w.pickups) {
    pk.bob += dt * 2.1;
    for (const p of w.players) {
      if (!p.alive) continue;
      const dx = p.x - pk.x;
      const dy = p.y - pk.y;
      const rr = CFG.playerRadius + pk.r;
      if (dx * dx + dy * dy <= rr * rr) {
        p.hp = Math.min(CFG.hp, p.hp + CFG.pickupHeal);
        p.score += CFG.pickupScore;
        p.ammo = Math.min(CFG.ammoMax, p.ammo + 30);
        pushEvent(w, "pickup", pk.x, pk.y, 0, p.id, 1);
        pk.id = -1;
        break;
      }
    }
  }
  if (w.pickups.some((p) => p.id === -1)) {
    w.pickups = w.pickups.filter((p) => p.id !== -1);
    w.nextId++;
    spawnPickup(w);
  }

  // --- zone ------------------------------------------------------------
  const z = w.zone;
  z.timer -= dt;
  if (!z.shrinking && z.timer <= 0 && z.phase < ZONE_RADII.length) {
    z.shrinking = true;
    z.timer = ZONE_SHRINK_TIME;
    z.targetR = ZONE_RADII[z.phase];
    pushEvent(w, "zone", z.x, z.y, 0, "", 1);
    const alive = w.players.filter((p) => p.alive);
    if (alive.length > 0) {
      const cx = alive.reduce((s, p) => s + p.x, 0) / alive.length;
      const cy = alive.reduce((s, p) => s + p.y, 0) / alive.length;
      z.x += (cx - z.x) * 0.22;
      z.y += (cy - z.y) * 0.22;
    }
  } else if (z.shrinking) {
    const k = Math.min(1, dt / ZONE_SHRINK_TIME);
    z.r += (z.targetR - z.r) * k * 2.2;
    if (Math.abs(z.r - z.targetR) < 2) {
      z.r = z.targetR;
      z.shrinking = false;
      z.phase++;
      z.timer = ZONE_HOLDS[Math.min(z.phase, ZONE_HOLDS.length - 1)];
    }
  }

  const zoneDmg = CFG.zoneDamageBase + z.phase * 1.9;
  for (const p of w.players) {
    if (!p.alive) continue;
    const d = Math.hypot(p.x - z.x, p.y - z.y);
    if (d > z.r - CFG.playerRadius * 0.4) {
      damagePlayer(w, p, zoneDmg * dt, null, Math.atan2(z.y - p.y, z.x - p.x), 0);
      if (Math.random() < dt * 6) {
        pushEvent(w, "hit", p.x, p.y, Math.random() * TAU, p.id, 0.25);
      }
    }
  }

  // --- survival score --------------------------------------------------
  for (const p of w.players) {
    if (p.alive) p.score += dt * 9;
  }

  // --- end conditions --------------------------------------------------
  const aliveCount = w.players.filter((p) => p.alive).length;
  if (aliveCount <= 1 || w.time >= w.timeLimit) endMatch(w);
}

/* ------------------------------------------------------------------ */
/* Bot AI                                                              */
/* ------------------------------------------------------------------ */

function botInput(w: World, p: Player, dt: number): Input {
  const ai = p.ai;
  ai.retargetIn -= dt;
  ai.jitter += dt;

  if (ai.retargetIn <= 0 || !ai.targetId || !getPlayer(w, ai.targetId)?.alive) {
    ai.retargetIn = 0.7 + Math.random() * 0.8;
    let best: Player | null = null;
    let bestD = Infinity;
    for (const o of w.players) {
      if (!o.alive || o.id === p.id) continue;
      const d = Math.hypot(o.x - p.x, o.y - p.y);
      if (d < bestD) {
        bestD = d;
        best = o;
      }
    }
    ai.targetId = best?.id ?? null;
    if (Math.random() < 0.35) ai.strafe *= -1;
  }

  const target = ai.targetId ? getPlayer(w, ai.targetId) : undefined;
  let mx = 0;
  let my = 0;
  let aimX = p.x + Math.cos(p.angle) * 300;
  let aimY = p.y + Math.sin(p.angle) * 300;
  let fire = false;
  let dash = false;

  const z = w.zone;
  const distToZoneCenter = Math.hypot(p.x - z.x, p.y - z.y);
  const outside = distToZoneCenter > z.r - 120;

  // gather pickups when hurt
  if (p.hp < 58 && !outside) {
    let nearest: Pickup | null = null;
    let nd = Infinity;
    for (const pk of w.pickups) {
      const d = Math.hypot(pk.x - p.x, pk.y - p.y);
      if (d < nd) {
        nd = d;
        nearest = pk;
      }
    }
    if (nearest && nd < 900) {
      const dir = norm(nearest.x - p.x, nearest.y - p.y);
      mx = dir.x;
      my = dir.y;
      if (target) {
        aimX = target.x;
        aimY = target.y;
        const d = Math.hypot(target.x - p.x, target.y - p.y);
        fire = d < 720 && p.ammo > 20;
      }
      return { mx, my, aimX, aimY, fire, dash: false, seq: 0 };
    }
  }

  if (outside) {
    const dir = norm(z.x - p.x, z.y - p.y);
    mx = dir.x;
    my = dir.y;
    dash = p.dashCd <= 0 && distToZoneCenter > z.r + 120;
    if (target) {
      aimX = target.x;
      aimY = target.y;
      fire = Math.hypot(target.x - p.x, target.y - p.y) < 760;
    }
    return { mx, my, aimX, aimY, fire, dash, seq: 0 };
  }

  if (target && target.alive) {
    const dx = target.x - p.x;
    const dy = target.y - p.y;
    const d = Math.hypot(dx, dy) || 1;
    const dirX = dx / d;
    const dirY = dy / d;
    const preferred = 360;

    // lead the target a little
    const lead = Math.min(0.32, d / CFG.bulletSpeed);
    aimX = target.x + target.vx * lead;
    aimY = target.y + target.vy * lead;

    const closing = d > preferred ? 1 : d < preferred - 90 ? -1 : 0;
    const wobble = Math.sin(ai.jitter * 1.6) * 0.35;
    mx = dirX * closing + -dirY * ai.strafe * (0.75 + wobble);
    my = dirY * closing + dirX * ai.strafe * (0.75 + wobble);

    fire = d < 820 && p.ammo > 14;
    if (d < 190 && p.dashCd <= 0 && Math.random() < 0.02) dash = true;
  } else {
    const ang = ai.jitter * 0.4 + p.angle;
    mx = Math.cos(ang) * 0.5;
    my = Math.sin(ang) * 0.5;
    aimX = p.x + Math.cos(ang) * 400;
    aimY = p.y + Math.sin(ang) * 400;
  }

  // keep inside the shrinking ring
  const margin = z.r - 180;
  if (distToZoneCenter > margin) {
    const dir = norm(z.x - p.x, z.y - p.y);
    mx = mx * 0.35 + dir.x * 0.9;
    my = my * 0.35 + dir.y * 0.9;
  }

  return { mx, my, aimX, aimY, fire, dash, seq: 0 };
}

export function ranking(w: World) {
  return [...w.players].sort((a, b) => {
    if (a.placement && b.placement && a.placement !== b.placement)
      return a.placement - b.placement;
    if (a.alive !== b.alive) return a.alive ? -1 : 1;
    return b.score - a.score;
  });
}
