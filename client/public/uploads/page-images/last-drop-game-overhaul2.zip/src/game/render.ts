import { CFG } from "./engine";
import type { Player, World, WorldEvent } from "./types";

export type Quality = "low" | "medium" | "high";

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind: "spark" | "drop" | "ring" | "smoke";
};

const INK = "#101E28";
const PAPER = "#F2EDE4";
const CYAN = "#00C2D1";
const ORANGE = "#FF4E20";

export class Renderer {
  particles: Particle[] = [];
  shake = 0;
  private grain: HTMLCanvasElement | null = null;
  private grainPattern: CanvasPattern | null = null;
  private vignette: { key: string; grad: CanvasGradient } | null = null;
  private flash = 0;

  constructor(private quality: Quality = "high", private reducedMotion = false) {}

  setQuality(q: Quality) {
    this.quality = q;
    this.grain = null;
    this.grainPattern = null;
    this.vignette = null;
  }
  setReducedMotion(v: boolean) {
    this.reducedMotion = v;
  }

  private maxParticles() {
    if (this.reducedMotion) return 40;
    return this.quality === "low" ? 90 : this.quality === "medium" ? 220 : 420;
  }

  private emit(p: Particle) {
    if (this.particles.length >= this.maxParticles()) this.particles.shift();
    this.particles.push(p);
  }

  burst(
    x: number,
    y: number,
    color: string,
    count: number,
    speed: number,
    kind: Particle["kind"] = "spark",
  ) {
    const n = this.reducedMotion ? Math.ceil(count * 0.35) : count;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.35 + Math.random() * 0.9);
      this.emit({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0,
        maxLife: 0.3 + Math.random() * 0.5,
        size: 2 + Math.random() * 5,
        color,
        kind,
      });
    }
  }

  ring(x: number, y: number, color: string, size = 30) {
    this.emit({
      x,
      y,
      vx: 0,
      vy: 0,
      life: 0,
      maxLife: 0.42,
      size,
      color,
      kind: "ring",
    });
  }

  addShake(amount: number) {
    if (this.reducedMotion) return;
    this.shake = Math.min(26, this.shake + amount);
  }

  flashScreen(amount = 0.35) {
    this.flash = Math.max(this.flash, this.reducedMotion ? 0.12 : amount);
  }

  /** Consume world events (already filtered by the caller) into particles. */
  handleEvent(e: WorldEvent, world: World) {
    const target = world.players.find((p) => p.id === e.p);
    switch (e.kind) {
      case "hit":
        this.burst(e.x, e.y, target?.color ?? ORANGE, 10, 260, "spark");
        this.addShake(3.2 * e.s);
        break;
      case "death":
        this.burst(e.x, e.y, target?.color ?? CYAN, 34, 420, "drop");
        this.ring(e.x, e.y, ORANGE, 60);
        this.addShake(11);
        this.flashScreen(0.22);
        break;
      case "pickup":
        this.burst(e.x, e.y, CYAN, 12, 210, "drop");
        this.ring(e.x, e.y, CYAN, 34);
        break;
      case "shoot":
        this.burst(e.x, e.y, target?.color ?? CYAN, 3, 130, "smoke");
        break;
      case "dash":
        this.burst(e.x, e.y, target?.color ?? CYAN, 12, 200, "smoke");
        break;
      case "zone":
        this.ring(e.x, e.y, ORANGE, 320);
        break;
      case "start":
        this.flashScreen(0.3);
        break;
    }
  }

  private updateParticles(dt: number) {
    for (const p of this.particles) {
      p.life += dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 1 - Math.min(0.9, dt * 2.2);
      p.vy *= 1 - Math.min(0.9, dt * 2.2);
      if (p.kind !== "ring") p.vy += 120 * dt;
    }
    if (this.particles.length) {
      this.particles = this.particles.filter((p) => p.life < p.maxLife);
    }
    this.shake *= 1 - Math.min(1, dt * 6);
    this.flash *= 1 - Math.min(1, dt * 3.4);
  }

  private makeGrain() {
    const c = document.createElement("canvas");
    c.width = 180;
    c.height = 180;
    const g = c.getContext("2d");
    if (!g) return c;
    const img = g.createImageData(180, 180);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = 120 + Math.random() * 135;
      img.data[i] = v;
      img.data[i + 1] = v;
      img.data[i + 2] = v;
      img.data[i + 3] = Math.random() * 26;
    }
    g.putImageData(img, 0, 0);
    return c;
  }

  draw(
    ctx: CanvasRenderingContext2D,
    world: World,
    width: number,
    height: number,
    focus: { x: number; y: number },
    dt: number,
    localId: string,
  ) {
    this.updateParticles(dt);

    const zoom = Math.max(
      0.42,
      Math.min(1.05, Math.min(width, height) / 760),
    );

    let camX = focus.x;
    let camY = focus.y;
    if (this.shake > 0.2) {
      camX += (Math.random() - 0.5) * this.shake;
      camY += (Math.random() - 0.5) * this.shake;
    }

    // keep the camera inside the world where possible
    const halfW = width / 2 / zoom;
    const halfH = height / 2 / zoom;
    camX = Math.max(halfW * 0.35, Math.min(CFG.worldW - halfW * 0.35, camX));
    camY = Math.max(halfH * 0.35, Math.min(CFG.worldH - halfH * 0.35, camY));

    const toScreen = (x: number, y: number) => ({
      x: (x - camX) * zoom + width / 2,
      y: (y - camY) * zoom + height / 2,
    });

    ctx.save();
    ctx.fillStyle = "#06171D";
    ctx.fillRect(0, 0, width, height);

    // --- arena floor -------------------------------------------------
    const tl = toScreen(0, 0);
    const br = toScreen(CFG.worldW, CFG.worldH);
    ctx.fillStyle = "#0C2A33";
    ctx.fillRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);

    const grid = 200;
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(46,125,140,0.22)";
    ctx.beginPath();
    for (let x = 0; x <= CFG.worldW; x += grid) {
      const s = toScreen(x, 0);
      ctx.moveTo(s.x, tl.y);
      ctx.lineTo(s.x, br.y);
    }
    for (let y = 0; y <= CFG.worldH; y += grid) {
      const s = toScreen(0, y);
      ctx.moveTo(tl.x, s.y);
      ctx.lineTo(br.x, s.y);
    }
    ctx.stroke();

    // world border
    ctx.lineWidth = 3;
    ctx.strokeStyle = "rgba(0,194,209,0.5)";
    ctx.strokeRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y);

    // --- bleach outside the pool -------------------------------------
    const zc = toScreen(world.zone.x, world.zone.y);
    const zr = world.zone.r * zoom;
    ctx.beginPath();
    ctx.rect(0, 0, width, height);
    ctx.arc(zc.x, zc.y, zr, 0, Math.PI * 2, true);
    ctx.fillStyle = "rgba(242,237,228,0.9)";
    ctx.fill();

    // burn ring on the drying edge
    ctx.save();
    ctx.beginPath();
    ctx.arc(zc.x, zc.y, zr, 0, Math.PI * 2);
    ctx.lineWidth = 26;
    ctx.strokeStyle = "rgba(255,78,32,0.16)";
    ctx.stroke();
    ctx.lineWidth = 7;
    ctx.strokeStyle = ORANGE;
    ctx.setLineDash([26, 18]);
    ctx.lineDashOffset = -world.time * 26;
    ctx.stroke();
    ctx.restore();

    // water meniscus
    ctx.beginPath();
    ctx.arc(zc.x, zc.y, zr, 0, Math.PI * 2);
    ctx.lineWidth = 5;
    ctx.strokeStyle = CYAN;
    ctx.shadowColor = "rgba(0,194,209,0.9)";
    ctx.shadowBlur = 26;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // --- pickups -----------------------------------------------------
    for (const pk of world.pickups) {
      const s = toScreen(pk.x, pk.y);
      const bob = Math.sin(pk.bob) * 3 * zoom;
      const r = pk.r * zoom;
      ctx.beginPath();
      ctx.moveTo(s.x, s.y - r * 1.25 + bob);
      ctx.bezierCurveTo(
        s.x + r * 1.05,
        s.y - r * 0.1 + bob,
        s.x + r * 0.85,
        s.y + r + bob,
        s.x,
        s.y + r + bob,
      );
      ctx.bezierCurveTo(
        s.x - r * 0.85,
        s.y + r + bob,
        s.x - r * 1.05,
        s.y - r * 0.1 + bob,
        s.x,
        s.y - r * 1.25 + bob,
      );
      ctx.fillStyle = "rgba(0,194,209,0.85)";
      ctx.shadowColor = "rgba(0,194,209,0.8)";
      ctx.shadowBlur = 18;
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.lineWidth = 1.6;
      ctx.strokeStyle = "rgba(242,237,228,0.85)";
      ctx.stroke();
    }

    // --- bullets -----------------------------------------------------
    for (const b of world.bullets) {
      const s = toScreen(b.x, b.y);
      const ang = Math.atan2(b.vy, b.vx);
      const len = 17 * zoom;
      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(ang);
      const grad = ctx.createLinearGradient(-len, 0, len * 0.6, 0);
      grad.addColorStop(0, "rgba(255,255,255,0)");
      grad.addColorStop(1, b.color);
      ctx.fillStyle = grad;
      ctx.fillRect(-len, -b.r * zoom * 0.55, len * 1.7, b.r * zoom * 1.1);
      ctx.fillStyle = "#FFFFFF";
      ctx.beginPath();
      ctx.arc(len * 0.55, 0, b.r * zoom * 0.45, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // --- players -----------------------------------------------------
    for (const p of world.players) {
      if (!p.alive) continue;
      const s = toScreen(p.x, p.y);
      const r = CFG.playerRadius * zoom;
      const isLocal = p.id === localId;

      // shadow
      ctx.beginPath();
      ctx.ellipse(s.x, s.y + r * 0.75, r * 0.95, r * 0.42, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(4,18,24,0.32)";
      ctx.fill();

      // droplet body, tail points along movement
      const speed = Math.hypot(p.vx, p.vy);
      const dirAng =
        speed > 30 ? Math.atan2(p.vy, p.vx) : p.angle;
      const tail = Math.min(1.5, 0.25 + speed / 420);

      ctx.save();
      ctx.translate(s.x, s.y);
      ctx.rotate(dirAng);
      ctx.beginPath();
      ctx.moveTo(-r * (1.1 + tail), 0);
      ctx.bezierCurveTo(
        -r * 0.65,
        -r * 0.95,
        r * 1.02,
        -r * 0.82,
        r * 1.02,
        0,
      );
      ctx.bezierCurveTo(
        r * 1.02,
        r * 0.82,
        -r * 0.65,
        r * 0.95,
        -r * (1.1 + tail),
        0,
      );
      ctx.fillStyle = p.hitFlash > 0 ? "#FFFFFF" : p.color;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = INK;
      ctx.stroke();
      // highlight
      ctx.beginPath();
      ctx.arc(r * 0.12, -r * 0.3, r * 0.3, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.fill();
      ctx.restore();

      // aim barrel
      ctx.beginPath();
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(
        s.x + Math.cos(p.angle) * r * 1.65,
        s.y + Math.sin(p.angle) * r * 1.65,
      );
      ctx.lineWidth = 4;
      ctx.strokeStyle = isLocal ? "#FFFFFF" : "rgba(242,237,228,0.7)";
      ctx.stroke();

      // spawn protection
      if (p.protect > 0) {
        ctx.beginPath();
        ctx.arc(s.x, s.y, r * 1.75, 0, Math.PI * 2);
        ctx.lineWidth = 2;
        ctx.strokeStyle = `rgba(255,255,255,${0.25 + 0.35 * Math.abs(Math.sin(world.time * 6))})`;
        ctx.stroke();
      }

      // name + hp
      const labelY = s.y - r * 2.35;
      ctx.font = `700 ${Math.round(13 * Math.max(0.85, zoom))}px "Space Grotesk", system-ui, sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 3;
      ctx.strokeStyle = "rgba(6,23,29,0.85)";
      ctx.strokeText(p.name, s.x, labelY);
      ctx.fillStyle = isLocal ? "#FFFFFF" : PAPER;
      ctx.fillText(p.name, s.x, labelY);

      const barW = 62 * Math.max(0.9, zoom);
      const barH = 5;
      const bx = s.x - barW / 2;
      const by = labelY + 8;
      ctx.fillStyle = "rgba(6,23,29,0.7)";
      ctx.fillRect(bx, by, barW, barH);
      ctx.fillStyle = p.hp > 45 ? CYAN : p.hp > 22 ? "#FFC53D" : ORANGE;
      ctx.fillRect(bx, by, barW * (p.hp / CFG.hp), barH);
    }

    // --- particles ---------------------------------------------------
    for (const p of this.particles) {
      const s = toScreen(p.x, p.y);
      const t = p.life / p.maxLife;
      const alpha = 1 - t;
      if (p.kind === "ring") {
        ctx.beginPath();
        ctx.arc(s.x, s.y, p.size * zoom * (0.3 + t * 1.6), 0, Math.PI * 2);
        ctx.lineWidth = 3 * (1 - t) + 0.5;
        ctx.strokeStyle = p.color;
        ctx.globalAlpha = alpha * 0.8;
        ctx.stroke();
        ctx.globalAlpha = 1;
      } else {
        const size = p.size * zoom * (1 - t * 0.55);
        ctx.beginPath();
        ctx.arc(s.x, s.y, size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha * (p.kind === "smoke" ? 0.4 : 0.9);
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }

    // --- vignette / grain -------------------------------------------
    const vKey = `${Math.round(width)}x${Math.round(height)}`;
    if (!this.vignette || this.vignette.key !== vKey) {
      const vg = ctx.createRadialGradient(
        width / 2,
        height / 2,
        Math.min(width, height) * 0.32,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.78,
      );
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(3,12,16,0.62)");
      this.vignette = { key: vKey, grad: vg };
    }
    ctx.fillStyle = this.vignette.grad;
    ctx.fillRect(0, 0, width, height);

    if (this.quality !== "low") {
      if (!this.grain) this.grain = this.makeGrain();
      if (!this.grainPattern) this.grainPattern = ctx.createPattern(this.grain, "repeat");
      if (this.grainPattern) {
        ctx.globalAlpha = 0.055;
        ctx.fillStyle = this.grainPattern;
        ctx.fillRect(0, 0, width, height);
        ctx.globalAlpha = 1;
      }
    }

    if (this.flash > 0.01) {
      ctx.fillStyle = `rgba(242,237,228,${this.flash * 0.5})`;
      ctx.fillRect(0, 0, width, height);
    }

    ctx.restore();
  }

  /** screen -> world helper matching the camera used in draw() */
  screenToWorld(
    sx: number,
    sy: number,
    width: number,
    height: number,
    focus: { x: number; y: number },
  ) {
    const zoom = Math.max(0.42, Math.min(1.05, Math.min(width, height) / 760));
    const halfW = width / 2 / zoom;
    const halfH = height / 2 / zoom;
    const camX = Math.max(halfW * 0.35, Math.min(CFG.worldW - halfW * 0.35, focus.x));
    const camY = Math.max(halfH * 0.35, Math.min(CFG.worldH - halfH * 0.35, focus.y));
    return {
      x: (sx - width / 2) / zoom + camX,
      y: (sy - height / 2) / zoom + camY,
    };
  }
}

export function eventColor(e: WorldEvent, world: World): string {
  const p: Player | undefined = world.players.find((x) => x.id === e.p);
  return p?.color ?? CYAN;
}
