/**
 * Unified input: keyboard, mouse, touch (virtual stick + drag aim) and gamepad.
 * All DOM listeners are registered with explicit teardown so nothing leaks.
 */

export type InputFrame = {
  mx: number;
  my: number;
  aimX: number;
  aimY: number;
  fire: boolean;
  dash: boolean;
  seq: number;
  /** true when the aim comes from a real pointer rather than auto-aim */
  explicitAim: boolean;
  usingTouch: boolean;
};

type Stick = {
  id: number;
  ox: number;
  oy: number;
  x: number;
  y: number;
};

const KEY_MOVE: Record<string, [number, number]> = {
  KeyW: [0, -1],
  ArrowUp: [0, -1],
  KeyS: [0, 1],
  ArrowDown: [0, 1],
  KeyA: [-1, 0],
  ArrowLeft: [-1, 0],
  KeyD: [1, 0],
  ArrowRight: [1, 0],
};

export class InputController {
  private keys = new Set<string>();
  private stick: Stick | null = null;
  private aimTouchId = -1;
  private aimPoint = { x: 0, y: 0 };
  private mousePoint = { x: 0, y: 0 };
  private mouseDown = false;
  private mouseActive = false;
  private dashQueued = false;
  private seq = 0;
  private cleanups: (() => void)[] = [];
  usingTouch = false;
  usingGamepad = false;
  private gamepadMove = { x: 0, y: 0 };
  private gamepadAim = { x: 0, y: 0, active: false };
  private gamepadFire = false;
  private gamepadDash = false;

  constructor(private target: HTMLElement) {
    const add = <T extends Event>(
      el: EventTarget,
      type: string,
      fn: (e: T) => void,
      opts?: AddEventListenerOptions,
    ) => {
      const handler = fn as EventListener;
      el.addEventListener(type, handler, opts);
      this.cleanups.push(() => el.removeEventListener(type, handler, opts));
    };

    add<KeyboardEvent>(window, "keydown", (e) => {
      if (e.repeat) return;
      this.keys.add(e.code);
      if (e.code === "Space" || e.code.startsWith("Arrow")) e.preventDefault();
      if (e.code === "ShiftLeft" || e.code === "ShiftRight" || e.code === "KeyJ") {
        this.dashQueued = true;
      }
    });
    add<KeyboardEvent>(window, "keyup", (e) => this.keys.delete(e.code));
    add(window, "blur", () => {
      this.keys.clear();
      this.mouseDown = false;
      this.stick = null;
      this.aimTouchId = -1;
    });

    add<MouseEvent>(target, "mousemove", (e) => {
      const r = target.getBoundingClientRect();
      this.mousePoint = { x: e.clientX - r.left, y: e.clientY - r.top };
      this.mouseActive = true;
      this.usingGamepad = false;
    });
    add<MouseEvent>(target, "mousedown", (e) => {
      if (e.button === 0) {
        this.mouseDown = true;
        this.usingTouch = false;
      }
      if (e.button === 2) this.dashQueued = true;
    });
    add<MouseEvent>(window, "mouseup", (e) => {
      if (e.button === 0) this.mouseDown = false;
    });
    add<MouseEvent>(target, "contextmenu", (e) => e.preventDefault());

    add<TouchEvent>(
      target,
      "touchstart",
      (e) => {
        const el = e.target as HTMLElement | null;
        if (
          el &&
          typeof el.closest === "function" &&
          el.closest("button, input, textarea, [role='dialog']")
        ) {
          return;
        }
        this.usingTouch = true;
        this.usingGamepad = false;
        const r = target.getBoundingClientRect();
        for (const t of Array.from(e.changedTouches)) {
          const x = t.clientX - r.left;
          const y = t.clientY - r.top;
          const isLeft = x < r.width * 0.44;
          if (isLeft && this.stick === null) {
            this.stick = { id: t.identifier, ox: x, oy: y, x, y };
          } else if (this.aimTouchId === -1) {
            this.aimTouchId = t.identifier;
            this.aimPoint = { x, y };
          }
        }
        e.preventDefault();
      },
      { passive: false },
    );
    add<TouchEvent>(
      target,
      "touchmove",
      (e) => {
        const r = target.getBoundingClientRect();
        for (const t of Array.from(e.changedTouches)) {
          const x = t.clientX - r.left;
          const y = t.clientY - r.top;
          if (this.stick && t.identifier === this.stick.id) {
            this.stick.x = x;
            this.stick.y = y;
          } else if (t.identifier === this.aimTouchId) {
            this.aimPoint = { x, y };
          }
        }
        e.preventDefault();
      },
      { passive: false },
    );
    const endTouch = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (this.stick && t.identifier === this.stick.id) this.stick = null;
        if (t.identifier === this.aimTouchId) this.aimTouchId = -1;
      }
    };
    add<TouchEvent>(target, "touchend", endTouch);
    add<TouchEvent>(target, "touchcancel", endTouch);
    add(target, "touchstart", () => (this.usingTouch = true), { passive: true });
  }

  destroy() {
    this.cleanups.forEach((fn) => fn());
    this.cleanups = [];
  }

  triggerDash() {
    this.dashQueued = true;
  }

  private pollGamepad() {
    if (typeof navigator === "undefined" || !navigator.getGamepads) return;
    const pads = navigator.getGamepads();
    let pad: Gamepad | null = null;
    for (const p of pads) {
      if (p && p.connected) {
        pad = p;
        break;
      }
    }
    if (!pad) {
      this.gamepadFire = false;
      this.gamepadMove = { x: 0, y: 0 };
      this.gamepadAim.active = false;
      return;
    }
    const dz = (v: number) => (Math.abs(v) < 0.18 ? 0 : v);
    const lx = dz(pad.axes[0] ?? 0);
    const ly = dz(pad.axes[1] ?? 0);
    const rx = dz(pad.axes[2] ?? 0);
    const ry = dz(pad.axes[3] ?? 0);
    const mag = Math.hypot(lx, ly);
    if (mag > 0.12) {
      this.gamepadMove = { x: lx, y: ly };
      this.usingGamepad = true;
    } else {
      this.gamepadMove = { x: 0, y: 0 };
    }
    if (Math.hypot(rx, ry) > 0.25) {
      this.gamepadAim = { x: rx, y: ry, active: true };
      this.usingGamepad = true;
    } else {
      this.gamepadAim.active = false;
    }
    const pressed = (i: number) => Boolean(pad.buttons[i]?.pressed);
    this.gamepadFire = pressed(7) || pressed(5) || pressed(0);
    if (pressed(1) || pressed(2) || pressed(4)) this.dashQueued = true;
    if (pressed(9)) this.dashQueued = this.dashQueued;
  }

  sample(width: number, height: number): InputFrame {
    this.pollGamepad();

    let mx = 0;
    let my = 0;
    for (const code of this.keys) {
      const v = KEY_MOVE[code];
      if (v) {
        mx += v[0];
        my += v[1];
      }
    }

    if (this.stick) {
      const dx = this.stick.x - this.stick.ox;
      const dy = this.stick.y - this.stick.oy;
      const max = 62;
      const d = Math.hypot(dx, dy);
      if (d > 6) {
        mx += (dx / Math.max(d, max)) * 1.2;
        my += (dy / Math.max(d, max)) * 1.2;
      }
    }

    mx += this.gamepadMove.x;
    my += this.gamepadMove.y;

    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }

    // aim
    let aimX = this.mousePoint.x;
    let aimY = this.mousePoint.y;
    let explicitAim = this.mouseActive;
    if (this.aimTouchId !== -1) {
      aimX = this.aimPoint.x;
      aimY = this.aimPoint.y;
      explicitAim = true;
    } else if (this.usingGamepad && this.gamepadAim.active) {
      aimX = width / 2 + this.gamepadAim.x * 420;
      aimY = height / 2 + this.gamepadAim.y * 420;
      explicitAim = true;
    }

    const kbFire = this.keys.has("Space") || this.keys.has("KeyK");
    const fire =
      this.mouseDown || this.aimTouchId !== -1 || this.gamepadFire || kbFire;
    const dash = this.dashQueued;
    this.dashQueued = false;
    this.seq++;

    return {
      mx,
      my,
      aimX,
      aimY,
      fire,
      dash,
      seq: this.seq,
      explicitAim,
      usingTouch: this.usingTouch,
    };
  }

  get stickOrigin() {
    return this.stick
      ? { x: this.stick.ox, y: this.stick.oy, x2: this.stick.x, y2: this.stick.y }
      : null;
  }

  get stickActive() {
    return this.stick !== null;
  }
}
