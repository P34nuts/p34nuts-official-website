// Shared game types — used by both the client (browser) and the authoritative
// server simulation. Keep these free of DOM / Node specific types.

export type Vec = { x: number; y: number };

export type Input = {
  /** normalized movement direction, -1..1 */
  mx: number;
  my: number;
  /** world-space aim point */
  aimX: number;
  aimY: number;
  fire: boolean;
  dash: boolean;
  seq: number;
};

export const EMPTY_INPUT: Input = {
  mx: 0,
  my: 0,
  aimX: 0,
  aimY: 0,
  fire: false,
  dash: false,
  seq: 0,
};

export type AIState = {
  targetId: string | null;
  strafe: number;
  retargetIn: number;
  jitter: number;
};

export type Player = {
  id: string;
  name: string;
  color: string;
  isBot: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  hp: number;
  alive: boolean;
  ammo: number;
  fireCd: number;
  dashCd: number;
  dashTime: number;
  kills: number;
  score: number;
  /** 1 = winner, higher = eliminated earlier */
  placement: number;
  hitFlash: number;
  protect: number;
  connected: boolean;
  input: Input;
  ai: AIState;
};

export type Bullet = {
  id: number;
  ownerId: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  r: number;
  damage: number;
  color: string;
};

export type Pickup = {
  id: number;
  x: number;
  y: number;
  r: number;
  bob: number;
};

export type WorldEventKind =
  | "start"
  | "hit"
  | "death"
  | "pickup"
  | "shoot"
  | "dash"
  | "zone";

export type WorldEvent = {
  id: number;
  kind: WorldEventKind;
  x: number;
  y: number;
  /** angle / magnitude */
  a: number;
  /** player id */
  p: string;
  /** strength 0..1 */
  s: number;
};

export type Zone = {
  x: number;
  y: number;
  r: number;
  targetR: number;
  phase: number;
  timer: number;
  shrinking: boolean;
};

export type World = {
  tick: number;
  time: number;
  acc: number;
  status: "countdown" | "playing" | "ended";
  countdown: number;
  players: Player[];
  bullets: Bullet[];
  pickups: Pickup[];
  events: WorldEvent[];
  eventSeq: number;
  nextId: number;
  zone: Zone;
  winnerId: string | null;
  endedAt: number;
  timeLimit: number;
};

export type LobbyPlayer = {
  playerId: string;
  name: string;
  isHost: boolean;
  isReady: boolean;
  isBot: boolean;
  connection: "online" | "grace" | "gone";
};

export type ChatMessage = {
  id: string;
  playerId: string;
  name: string;
  body: string;
  at: number;
};

export type LobbyState = {
  code: string;
  hostId: string;
  status: "lobby" | "countdown" | "playing" | "ended";
  players: LobbyPlayer[];
  chat: ChatMessage[];
  fillBots: boolean;
  maxPlayers: number;
  updatedAt: number;
};

export type SyncResponse = {
  ok: boolean;
  error?: string;
  world: World | null;
  lobby: LobbyState | null;
  serverTime: number;
  ping: number;
};
