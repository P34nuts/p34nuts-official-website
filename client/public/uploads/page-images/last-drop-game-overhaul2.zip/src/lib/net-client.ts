import type { Input, LobbyState, World } from "@/game/types";

export type ApiResult<T> = ({ ok: true } & T) | { ok: false; error: string };

async function post<T>(url: string, body: unknown): Promise<ApiResult<T>> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = (await res.json()) as ApiResult<T>;
    if (!json.ok) {
      return { ok: false, error: json.error ?? `Request failed (${res.status})` };
    }
    return json;
  } catch {
    return { ok: false, error: "Network unavailable" };
  }
}

async function get<T>(url: string): Promise<ApiResult<T>> {
  try {
    const res = await fetch(url, { cache: "no-store" });
    const json = (await res.json()) as ApiResult<T>;
    if (!json.ok) {
      return { ok: false, error: json.error ?? `Request failed (${res.status})` };
    }
    return json;
  } catch {
    return { ok: false, error: "Network unavailable" };
  }
}

export function createRoom(opts: {
  name: string;
  playerId: string;
  fillBots?: boolean;
}) {
  return post<{ code: string; lobby: LobbyState }>("/api/rooms", {
    action: "create",
    ...opts,
  });
}

export function joinRoom(opts: {
  code: string;
  name: string;
  playerId: string;
}) {
  return post<{ lobby: LobbyState }>("/api/rooms", {
    action: "join",
    ...opts,
  });
}

export function lobbyAction(
  code: string,
  playerId: string,
  payload: Record<string, unknown>,
) {
  return post<{ lobby: LobbyState }>(`/api/rooms/${code}`, {
    playerId,
    ...payload,
  });
}

export function syncRoom(code: string, playerId: string, input: Partial<Input>) {
  return post<{ world: World | null; lobby: LobbyState | null }>(
    `/api/rooms/${code}/sync`,
    { playerId, input },
  );
}

export function getLobby(code: string) {
  return get<{ lobby: LobbyState }>(`/api/rooms/${code}`);
}

export function fetchScores() {
  return get<{
    entries: {
      name: string;
      score: number;
      kills: number;
      placement: number;
      mode: string;
    }[];
  }>("/api/scores");
}

export function postScore(payload: {
  name: string;
  score: number;
  kills: number;
  placement: number;
  mode: "solo" | "multi";
}) {
  return post<{
    entries: {
      name: string;
      score: number;
      kills: number;
      placement: number;
      mode: string;
    }[];
  }>("/api/scores", payload);
}

export function inviteLink(code: string): string {
  if (typeof window === "undefined") return `?room=${code}`;
  const url = new URL(window.location.href);
  url.pathname = url.pathname.replace(/\/play\/?$/, "/");
  url.search = "";
  url.hash = "";
  return `${url.origin}${url.pathname}?room=${code}`;
}
