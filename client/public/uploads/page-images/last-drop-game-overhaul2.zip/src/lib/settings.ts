export type Quality = "auto" | "low" | "medium" | "high";

export type Settings = {
  name: string;
  sfx: boolean;
  music: boolean;
  volume: number;
  quality: Quality;
  vibration: boolean;
  showFps: boolean;
};

export type Stats = {
  matches: number;
  wins: number;
  kills: number;
  bestScore: number;
  bestKills: number;
  totalScore: number;
  streak: number;
  bestStreak: number;
};

export const DEFAULT_SETTINGS: Settings = {
  name: "",
  sfx: true,
  music: true,
  volume: 0.8,
  quality: "auto",
  vibration: true,
  showFps: false,
};

export const EMPTY_STATS: Stats = {
  matches: 0,
  wins: 0,
  kills: 0,
  bestScore: 0,
  bestKills: 0,
  totalScore: 0,
  streak: 0,
  bestStreak: 0,
};

const SETTINGS_KEY = "lastdrop.settings.v1";
const STATS_KEY = "lastdrop.stats.v1";
const ID_KEY = "lastdrop.player.v1";

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return { ...fallback, ...(JSON.parse(raw) as object) } as T;
  } catch {
    return fallback;
  }
}

export function loadSettings(): Settings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  return safeParse<Settings>(
    window.localStorage.getItem(SETTINGS_KEY),
    DEFAULT_SETTINGS,
  );
}

export function saveSettings(s: Settings) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable */
  }
}

export function loadStats(): Stats {
  if (typeof window === "undefined") return EMPTY_STATS;
  return safeParse<Stats>(window.localStorage.getItem(STATS_KEY), EMPTY_STATS);
}

export function recordMatch(
  r: { won: boolean; kills: number; score: number },
): Stats {
  const s = loadStats();
  const streak = r.won ? s.streak + 1 : 0;
  const next: Stats = {
    matches: s.matches + 1,
    wins: s.wins + (r.won ? 1 : 0),
    kills: s.kills + Math.max(0, r.kills),
    bestScore: Math.max(s.bestScore, Math.round(r.score)),
    bestKills: Math.max(s.bestKills, Math.max(0, r.kills)),
    totalScore: s.totalScore + Math.max(0, Math.round(r.score)),
    streak,
    bestStreak: Math.max(s.bestStreak, streak),
  };
  try {
    window.localStorage.setItem(STATS_KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable */
  }
  return next;
}

export function playerId(): string {
  if (typeof window === "undefined") return "server";
  try {
    let id = window.localStorage.getItem(ID_KEY);
    if (!id || id.length < 6) {
      const rand =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
      id = `p-${rand}`.slice(0, 40);
      window.localStorage.setItem(ID_KEY, id);
    }
    return id;
  } catch {
    return `p-${Math.random().toString(36).slice(2, 12)}`;
  }
}

export function vibrate(pattern: number | number[], enabled: boolean) {
  if (!enabled || typeof navigator === "undefined") return;
  if (typeof navigator.vibrate === "function") {
    try {
      navigator.vibrate(pattern);
    } catch {
      /* ignore */
    }
  }
}

export function autoQuality(): "low" | "medium" | "high" {
  if (typeof window === "undefined") return "high";
  const cores = navigator.hardwareConcurrency ?? 4;
  const mem = (navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 4;
  const small = Math.min(window.innerWidth, window.innerHeight) < 480;
  if (cores <= 3 || mem <= 2) return "low";
  if (cores <= 5 || small) return "medium";
  return "high";
}

export function resolveQuality(q: Quality): "low" | "medium" | "high" {
  return q === "auto" ? autoQuality() : q;
}

export function prefersReducedMotion(): boolean {
  if (typeof window === "undefined" || !window.matchMedia) return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
