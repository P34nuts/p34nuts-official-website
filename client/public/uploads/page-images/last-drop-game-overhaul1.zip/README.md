# Last Drop — Battle Royale

A fast arcade battle royale for browser, mobile and (optionally) Android.
**Your hydration is your health.** It drains every second, so you have to keep
collecting water while fighting rivals inside a shrinking evaporation zone.
The last drop standing wins.

- 🎮 Solo / practice against AI — runs **fully offline in the browser**
- 🌐 Online multiplayer (up to 8 players) with room codes, lobby, chat and rematch
- 📱 Mobile-first: twin-stick touch controls, safe areas, portrait + landscape
- 🖥️ Desktop: WASD/arrows + mouse aim, gamepad support
- 🛡️ Server-authoritative simulation — clients send inputs only
- 📦 Installable PWA, Capacitor/APK-ready

---

## 1. Run it

```bash
npm install
cp .env .env.local          # DATABASE_URL=postgresql://...
npx drizzle-kit push        # create tables
npm run dev                 # http://localhost:3000
```

Production:

```bash
npm run build
npm run start
```

Useful URLs

| URL | Purpose |
| --- | --- |
| `/` | the game |
| `/?room=ABCDE` | join a room directly (invite links) |
| `/?debug=1` | FPS / ping / netstate debug overlay |
| `/api/health` | health probe |
| `/api/rooms` | live room + player counters |
| `/api/leaderboard` | top 20 profiles |

## 2. Architecture

```
src/game/core/        pure simulation (no DOM, no Node) – shared by client & server
  sim.ts              physics, storm, pickups, combat, scoring, bot AI, wire encoding
  types.ts            state + wire types
src/game/client/      browser only
  sources.ts          LocalSource (offline sim) · NetSource (interpolation + prediction)
  net.ts              SSE stream + input channel, reconnect, ping
  renderer.ts         canvas2d renderer, particles, shake, minimap, quality tiers
  input.ts            keyboard · mouse · touch sticks · gamepad -> one PlayerInput
  audio.ts            WebAudio synth (no audio assets shipped)
  storage.ts          localStorage settings / stats / guest id
src/server/rooms.ts   authoritative room registry, 20 Hz match loop, SSE fan-out,
                      reconnect grace, host migration, chat limits, DB persistence
src/app/api/**        HTTP API (rooms, actions, SSE stream, profile, leaderboard)
src/components/**     React UI (menu, lobby, HUD, results, touch controls)
scripts/              headless sim tests, network integration tests, Pages build
```

**Why the same simulation twice?** `src/game/core` is pure TypeScript, so the
server runs it authoritatively for online matches and the browser runs it for
solo play. One rule set, no duplicated gameplay logic, and solo works with no
backend at all.

**Networking.** Downstream uses **Server-Sent Events** (20 Hz snapshots, short
keys, rounded integers, ~2–4 KB/tick for 8 players); upstream uses small
JSON POSTs with the player's input at 20 Hz. The client interpolates remote
entities with a 110 ms buffer and predicts the local player with server
reconciliation. This runs on any plain Node host (and behind proxies that do
not allow WebSocket upgrades) while staying fully server-authoritative.

**Anti-cheat.** The client never sends positions, damage, scores or winners —
only `{mx, my, aim, fire, dash}`, which is clamped and validated server-side.
Match results are written to Postgres by the server. Solo scores are stored
separately with reduced XP and never count as online wins.

## 3. Controls

| | Move | Aim / Fire | Dash | Menu |
| --- | --- | --- | --- | --- |
| Desktop | WASD / arrows | mouse (hold LMB) | Space / Shift | Esc |
| Mobile | left stick | right stick (auto-fire option) | dash button | pause button |
| Gamepad | left stick | right stick + RT/A | LT/LB/B | — |

## 4. Tests

```bash
npx tsx scripts/sim-test.ts                       # simulation / balance / hardening
npm run build && npx next start -p 3100 &         # then:
BASE=http://localhost:3100 npx tsx scripts/net-test.ts   # full multiplayer E2E
npm run lint && npm run typecheck
```

`net-test.ts` exercises create → join → chat (XSS + rate limit) → bots → start →
SSE snapshots → input acks → disconnect → reconnect → match end → results →
leaderboard persistence → leave.

## 5. Deployment

### Option A — one Node host (recommended, simplest)
Deploy the whole Next.js app (frontend + multiplayer backend) to Render,
Railway, Fly.io, a VPS or Docker. Required env: `DATABASE_URL`. Run
`npx drizzle-kit push` once. Nothing else to configure.

### Option B — GitHub Pages frontend + separate backend
GitHub Pages cannot run a server, so the client is exported statically and the
backend is hosted elsewhere:

```bash
NEXT_PUBLIC_API_BASE=https://your-backend.example.com \
NEXT_PUBLIC_BASE_PATH=/last-drop \
node scripts/build-pages.mjs      # -> ./out
```

`.github/workflows/pages.yml` does this automatically on push to `main`.
Set the repository **variables** `LAST_DROP_API_BASE` (backend URL) and
`LAST_DROP_BASE_PATH` (`/<repo>` for project pages, empty for user pages).
Set `CORS_ALLOW_ORIGIN` on the backend to your Pages origin.

Without `LAST_DROP_API_BASE` the exported build still works — solo/practice
runs entirely in the browser and the multiplayer buttons report that the
server is unreachable instead of breaking.

### Option C — Android APK (Capacitor)

```bash
npm i -D @capacitor/cli && npm i @capacitor/core @capacitor/android
NEXT_PUBLIC_API_BASE=https://your-backend.example.com node scripts/build-pages.mjs
npx cap init "Last Drop" com.example.lastdrop --web-dir=out
npx cap add android && npx cap sync android
npx cap open android      # build the APK/AAB in Android Studio
```

The client is already WebView friendly: no desktop-only APIs are required,
touch controls, safe-area insets, hardware back button handling, offline solo
play and an installable PWA manifest are all in place.

## 6. Known limitations

- Room state lives in the memory of a single Node process. Running multiple
  replicas requires sticky sessions or an external store (Redis) — fine for one
  instance, which handles dozens of concurrent rooms comfortably.
- Transport is SSE + HTTP POST rather than WebSockets (Next.js route handlers
  cannot upgrade sockets). Typical same-region RTT is ~30–60 ms, which the
  prediction layer hides well, but a dedicated WS server would shave a little
  more latency.
- Spectating after elimination follows other players' cameras; there is no free
  camera.
