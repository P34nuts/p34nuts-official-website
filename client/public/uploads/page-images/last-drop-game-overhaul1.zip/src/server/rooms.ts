import { db } from "@/db";
import { matchResults, matches, profiles } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import {
  MAX_PLAYERS,
  RULES,
  createMatch,
  encodeSnapshot,
  matchResults as computeResults,
  obstaclePayload,
  stepMatch,
} from "@/game/core/sim";
import type { PlayerInput, SimState } from "@/game/core/types";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface RoomMember {
  id: string;
  name: string;
  token: string;
  ready: boolean;
  connected: boolean;
  isBot: boolean;
  colorIndex: number;
  lastSeen: number;
  input: PlayerInput | null;
  wins: number;
}

export interface ChatMessage {
  id: number;
  name: string;
  text: string;
  at: number;
  system: boolean;
}

export type ServerMessage =
  | { t: "lobby"; room: PublicRoom }
  | { t: "map"; obstacles: number[][]; seed: number }
  | { t: "snap"; s: ReturnType<typeof encodeSnapshot>; ts: number }
  | { t: "chat"; m: ChatMessage }
  | { t: "results"; rows: ReturnType<typeof computeResults>; winner: string | null }
  | { t: "bye"; reason: string }
  | { t: "pong"; ts: number };

interface Subscriber {
  playerId: string;
  send: (msg: ServerMessage) => void;
}

export interface Room {
  code: string;
  hostId: string;
  isPublic: boolean;
  createdAt: number;
  members: Map<string, RoomMember>;
  chat: ChatMessage[];
  chatSeq: number;
  lastChatAt: Map<string, number>;
  subs: Set<Subscriber>;
  state: SimState | null;
  matchStartedAt: number;
  persisted: boolean;
  lastActivity: number;
}

export interface PublicRoom {
  code: string;
  hostId: string;
  isPublic: boolean;
  phase: "lobby" | "countdown" | "playing" | "ended";
  players: Array<{
    id: string;
    name: string;
    ready: boolean;
    connected: boolean;
    isBot: boolean;
    colorIndex: number;
    wins: number;
  }>;
  chat: ChatMessage[];
  maxPlayers: number;
}

/* ------------------------------------------------------------------ */
/* Global registry (survives hot reload)                               */
/* ------------------------------------------------------------------ */

interface Registry {
  rooms: Map<string, Room>;
  timer: ReturnType<typeof setInterval> | null;
  lastTickAt: number;
}

const globalForRooms = globalThis as typeof globalThis & {
  __lastDropRooms?: Registry;
};

const registry: Registry =
  globalForRooms.__lastDropRooms ??
  (globalForRooms.__lastDropRooms = { rooms: new Map(), timer: null, lastTickAt: 0 });

const TICK_MS = Math.round(1000 / RULES.tickRate);
const DISCONNECT_GRACE_MS = 45_000;
const ROOM_IDLE_MS = 5 * 60_000;
const MAX_ROOMS = 300;

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function makeCode(): string {
  let code = "";
  for (let i = 0; i < 5; i++) {
    code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
  }
  return code;
}

function makeToken(): string {
  return Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
}

export function sanitizeName(raw: unknown, fallback = "Player"): string {
  const s = typeof raw === "string" ? raw : "";
  const cleaned = s
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, "")
    .replace(/[<>]/g, "")
    .trim()
    .slice(0, 16);
  return cleaned.length >= 2 ? cleaned : fallback;
}

export function sanitizeId(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const s = raw.trim();
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(s)) return null;
  return s;
}

export function normalizeCode(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const s = raw.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (s.length !== 5) return null;
  return s;
}

/* ------------------------------------------------------------------ */
/* Room lifecycle                                                      */
/* ------------------------------------------------------------------ */

function freeColor(room: Room): number {
  const used = new Set([...room.members.values()].map((m) => m.colorIndex));
  for (let i = 0; i < MAX_PLAYERS; i++) if (!used.has(i)) return i;
  return 0;
}

function broadcast(room: Room, msg: ServerMessage) {
  for (const sub of room.subs) {
    try {
      sub.send(msg);
    } catch {
      room.subs.delete(sub);
    }
  }
}

export function publicRoom(room: Room): PublicRoom {
  return {
    code: room.code,
    hostId: room.hostId,
    isPublic: room.isPublic,
    phase: room.state ? room.state.phase : "lobby",
    players: [...room.members.values()].map((m) => ({
      id: m.id,
      name: m.name,
      ready: m.ready,
      connected: m.connected,
      isBot: m.isBot,
      colorIndex: m.colorIndex,
      wins: m.wins,
    })),
    chat: room.chat.slice(-30),
    maxPlayers: MAX_PLAYERS,
  };
}

function pushLobby(room: Room) {
  broadcast(room, { t: "lobby", room: publicRoom(room) });
}

function systemChat(room: Room, text: string) {
  const m: ChatMessage = {
    id: ++room.chatSeq,
    name: "SYSTEM",
    text,
    at: Date.now(),
    system: true,
  };
  room.chat.push(m);
  if (room.chat.length > 60) room.chat.shift();
  broadcast(room, { t: "chat", m });
}

export function createRoom(
  playerId: string,
  name: string,
  isPublic = false,
): { room: Room; token: string } | { error: string } {
  if (registry.rooms.size >= MAX_ROOMS) sweep(true);
  if (registry.rooms.size >= MAX_ROOMS) return { error: "Server is at capacity, try again shortly." };

  let code = makeCode();
  let guard = 0;
  while (registry.rooms.has(code) && guard++ < 50) code = makeCode();

  const token = makeToken();
  const room: Room = {
    code,
    hostId: playerId,
    isPublic,
    createdAt: Date.now(),
    members: new Map(),
    chat: [],
    chatSeq: 0,
    lastChatAt: new Map(),
    subs: new Set(),
    state: null,
    matchStartedAt: 0,
    persisted: false,
    lastActivity: Date.now(),
  };
  room.members.set(playerId, {
    id: playerId,
    name,
    token,
    ready: true,
    connected: false,
    isBot: false,
    colorIndex: 0,
    lastSeen: Date.now(),
    input: null,
    wins: 0,
  });
  registry.rooms.set(code, room);
  ensureLoop();
  return { room, token };
}

export function getRoom(code: string): Room | null {
  return registry.rooms.get(code) ?? null;
}

export function joinRoom(
  code: string,
  playerId: string,
  name: string,
): { room: Room; token: string } | { error: string } {
  const room = registry.rooms.get(code);
  if (!room) return { error: "Room not found. Check the code." };

  const existing = room.members.get(playerId);
  if (existing) {
    // reconnect / re-auth with a fresh token
    existing.name = name;
    existing.connected = true;
    existing.lastSeen = Date.now();
    existing.token = makeToken();
    room.lastActivity = Date.now();
    pushLobby(room);
    return { room, token: existing.token };
  }

  const humanCount = [...room.members.values()].length;
  if (humanCount >= MAX_PLAYERS) return { error: "Room is full." };
  if (room.state && room.state.phase !== "ended") {
    return { error: "Match already in progress. Wait for the next round." };
  }

  const token = makeToken();
  room.members.set(playerId, {
    id: playerId,
    name,
    token,
    ready: false,
    connected: false,
    isBot: false,
    colorIndex: freeColor(room),
    lastSeen: Date.now(),
    input: null,
    wins: 0,
  });
  room.lastActivity = Date.now();
  systemChat(room, `${name} joined`);
  pushLobby(room);
  ensureLoop();
  return { room, token };
}

export function authMember(room: Room, playerId: string, token: string): RoomMember | null {
  const m = room.members.get(playerId);
  if (!m || m.token !== token) return null;
  m.lastSeen = Date.now();
  room.lastActivity = Date.now();
  return m;
}

export function leaveRoom(room: Room, member: RoomMember) {
  room.members.delete(member.id);
  if (room.state) {
    const p = room.state.players.find((x) => x.id === member.id);
    if (p && p.alive) {
      p.connected = false;
      p.hp = 0;
      p.alive = false;
      p.placement = room.state.players.filter((x) => x.alive).length + 1;
    }
  }
  systemChat(room, `${member.name} left`);
  migrateHost(room);
  if ([...room.members.values()].every((m) => m.isBot)) {
    destroyRoom(room, "empty");
    return;
  }
  pushLobby(room);
}

function migrateHost(room: Room) {
  if (room.members.has(room.hostId) && !room.members.get(room.hostId)!.isBot) return;
  const next = [...room.members.values()].find((m) => !m.isBot && m.connected) ??
    [...room.members.values()].find((m) => !m.isBot);
  if (next) {
    room.hostId = next.id;
    systemChat(room, `${next.name} is now the host`);
  }
}

export function destroyRoom(room: Room, reason: string) {
  broadcast(room, { t: "bye", reason });
  room.subs.clear();
  registry.rooms.delete(room.code);
}

export function addBot(room: Room): string | null {
  if (room.members.size >= MAX_PLAYERS) return "Room is full.";
  const names = ["Rivulet", "Monsoon", "Geyser", "Cascade", "Tidal", "Drizzle", "Torrent"];
  const used = new Set([...room.members.values()].map((m) => m.name));
  const name = names.find((n) => !used.has(n)) ?? `Bot${room.members.size}`;
  const id = `bot_${Math.random().toString(36).slice(2, 10)}`;
  room.members.set(id, {
    id,
    name,
    token: makeToken(),
    ready: true,
    connected: true,
    isBot: true,
    colorIndex: freeColor(room),
    lastSeen: Date.now(),
    input: null,
    wins: 0,
  });
  pushLobby(room);
  return null;
}

export function removeBot(room: Room): void {
  const bot = [...room.members.values()].reverse().find((m) => m.isBot);
  if (bot) {
    room.members.delete(bot.id);
    pushLobby(room);
  }
}

export function setReady(room: Room, member: RoomMember, ready: boolean) {
  member.ready = ready;
  pushLobby(room);
}

export function postChat(room: Room, member: RoomMember, raw: string): string | null {
  const now = Date.now();
  const last = room.lastChatAt.get(member.id) ?? 0;
  if (now - last < 650) return "Slow down.";
  const text = raw
    .replace(/[\u0000-\u001f\u007f-\u009f]/g, " ")
    .trim()
    .slice(0, 160);
  if (!text) return "Empty message.";
  room.lastChatAt.set(member.id, now);
  const m: ChatMessage = { id: ++room.chatSeq, name: member.name, text, at: now, system: false };
  room.chat.push(m);
  if (room.chat.length > 60) room.chat.shift();
  broadcast(room, { t: "chat", m });
  return null;
}

export function startMatch(room: Room): string | null {
  if (room.state && room.state.phase !== "ended") return "Match already running.";
  const members = [...room.members.values()];
  if (members.length < 1) return "Need at least one player.";
  // The host may force-start; ready is a social signal, not a hard gate.

  const seats = members.map((m) => ({
    id: m.id,
    name: m.name,
    isBot: m.isBot,
    colorIndex: m.colorIndex,
    connected: m.connected,
  }));
  room.state = createMatch(seats);
  room.matchStartedAt = Date.now();
  room.persisted = false;
  for (const m of room.members.values()) m.input = null;
  broadcast(room, { t: "map", obstacles: obstaclePayload(room.state), seed: room.state.seed });
  pushLobby(room);
  ensureLoop();
  return null;
}

export function backToLobby(room: Room) {
  room.state = null;
  for (const m of room.members.values()) {
    m.ready = m.id === room.hostId || m.isBot;
    m.input = null;
  }
  pushLobby(room);
}

export function applyInput(room: Room, member: RoomMember, input: PlayerInput) {
  member.input = input;
  member.connected = true;
}

export function subscribe(room: Room, member: RoomMember, send: (m: ServerMessage) => void) {
  const sub: Subscriber = { playerId: member.id, send };
  room.subs.add(sub);
  member.connected = true;
  member.lastSeen = Date.now();
  if (room.state) {
    const p = room.state.players.find((x) => x.id === member.id);
    if (p) p.connected = true;
    send({ t: "map", obstacles: obstaclePayload(room.state), seed: room.state.seed });
  }
  send({ t: "lobby", room: publicRoom(room) });
  pushLobby(room);
  return () => {
    room.subs.delete(sub);
    const m = room.members.get(member.id);
    if (m) {
      m.connected = false;
      m.lastSeen = Date.now();
      if (room.state) {
        const p = room.state.players.find((x) => x.id === m.id);
        if (p) p.connected = false;
      }
      pushLobby(room);
    }
  };
}

/* ------------------------------------------------------------------ */
/* Match loop                                                          */
/* ------------------------------------------------------------------ */

function ensureLoop() {
  if (registry.timer) return;
  registry.lastTickAt = Date.now();
  registry.timer = setInterval(tickAll, TICK_MS);
  // don't keep the process alive just for the loop
  (registry.timer as unknown as { unref?: () => void }).unref?.();
}

function tickAll() {
  const now = Date.now();
  const dt = Math.min(0.25, Math.max(0.001, (now - registry.lastTickAt) / 1000));
  registry.lastTickAt = now;

  for (const room of registry.rooms.values()) {
    try {
      tickRoom(room, dt, now);
    } catch (err) {
      console.error("[rooms] tick error", room.code, err);
    }
  }
  sweep(false);

  if (registry.rooms.size === 0 && registry.timer) {
    clearInterval(registry.timer);
    registry.timer = null;
  }
}

function tickRoom(room: Room, dt: number, now: number) {
  // disconnect grace handling
  for (const m of [...room.members.values()]) {
    if (m.isBot || m.connected) continue;
    if (now - m.lastSeen > DISCONNECT_GRACE_MS) {
      room.members.delete(m.id);
      if (room.state) {
        const p = room.state.players.find((x) => x.id === m.id);
        if (p && p.alive) {
          p.alive = false;
          p.hp = 0;
          p.placement = room.state.players.filter((x) => x.alive).length + 1;
        }
      }
      systemChat(room, `${m.name} disconnected`);
      migrateHost(room);
      pushLobby(room);
    }
  }

  const state = room.state;
  if (!state) return;

  if (state.phase === "ended") {
    if (!room.persisted) {
      room.persisted = true;
      const rows = computeResults(state);
      const winner = state.winnerId;
      for (const m of room.members.values()) {
        if (winner && m.id === winner) m.wins++;
      }
      broadcast(room, { t: "results", rows, winner });
      void persistMatch(room, rows);
      pushLobby(room);
    }
    state.phaseTime -= dt;
    return;
  }

  const inputs = new Map<string, PlayerInput>();
  for (const m of room.members.values()) {
    if (m.input) inputs.set(m.id, m.input);
  }
  // mark presence inside sim
  for (const p of state.players) {
    const m = room.members.get(p.id);
    p.connected = m ? m.connected : false;
  }

  stepMatch(state, dt, inputs);

  const snap = encodeSnapshot(state);
  state.events = [];
  broadcast(room, { t: "snap", s: snap, ts: now });
}

function sweep(force: boolean) {
  const now = Date.now();
  for (const room of [...registry.rooms.values()]) {
    const humans = [...room.members.values()].filter((m) => !m.isBot);
    const anyConnected = humans.some((m) => m.connected);
    const idle = now - room.lastActivity > ROOM_IDLE_MS;
    if (humans.length === 0 || (!anyConnected && idle) || (force && !anyConnected)) {
      destroyRoom(room, "closed");
    }
  }
}

/* ------------------------------------------------------------------ */
/* Persistence                                                         */
/* ------------------------------------------------------------------ */

async function persistMatch(room: Room, rows: ReturnType<typeof computeResults>) {
  try {
    const duration = Math.round((Date.now() - room.matchStartedAt) / 1000);
    const [match] = await db
      .insert(matches)
      .values({
        roomCode: room.code,
        mode: room.isPublic ? "quickmatch" : "online",
        playerCount: rows.length,
        durationSec: duration,
      })
      .returning({ id: matches.id });

    if (!match) return;

    await db.insert(matchResults).values(
      rows.map((r) => ({
        matchId: match.id,
        profileId: r.isBot ? null : r.playerId,
        name: r.name,
        isBot: r.isBot,
        placement: r.placement,
        score: r.score,
        kills: r.kills,
        damage: r.damage,
        survivedFor: r.survivedFor,
      })),
    );

    for (const r of rows) {
      if (r.isBot) continue;
      const won = r.placement === 1 ? 1 : 0;
      const xp = Math.round(r.score / 10) + won * 50;
      await db
        .insert(profiles)
        .values({
          id: r.playerId,
          name: r.name,
          xp,
          matches: 1,
          wins: won,
          kills: r.kills,
          damage: r.damage,
          bestScore: r.score,
          streak: won,
          bestStreak: won,
        })
        .onConflictDoUpdate({
          target: profiles.id,
          set: {
            name: r.name,
            xp: sql`${profiles.xp} + ${xp}`,
            matches: sql`${profiles.matches} + 1`,
            wins: sql`${profiles.wins} + ${won}`,
            kills: sql`${profiles.kills} + ${r.kills}`,
            damage: sql`${profiles.damage} + ${r.damage}`,
            bestScore: sql`greatest(${profiles.bestScore}, ${r.score})`,
            streak: won ? sql`${profiles.streak} + 1` : sql`0`,
            bestStreak: won
              ? sql`greatest(${profiles.bestStreak}, ${profiles.streak} + 1)`
              : sql`${profiles.bestStreak}`,
            updatedAt: new Date(),
          },
        });
    }
  } catch (err) {
    console.error("[rooms] persist failed", err);
  }
}

export async function recordSoloResult(input: {
  playerId: string;
  name: string;
  score: number;
  kills: number;
  damage: number;
  placement: number;
  survivedFor: number;
}) {
  const score = Math.max(0, Math.min(100_000, Math.round(input.score)));
  const kills = Math.max(0, Math.min(50, Math.round(input.kills)));
  const damage = Math.max(0, Math.min(50_000, Math.round(input.damage)));
  const won = input.placement === 1 ? 1 : 0;
  const xp = Math.round(score / 20) + won * 20; // solo is worth less XP than online
  await db
    .insert(profiles)
    .values({
      id: input.playerId,
      name: input.name,
      xp,
      matches: 1,
      wins: 0,
      kills,
      damage,
      bestScore: score,
      streak: 0,
      bestStreak: 0,
    })
    .onConflictDoUpdate({
      target: profiles.id,
      set: {
        name: input.name,
        xp: sql`${profiles.xp} + ${xp}`,
        matches: sql`${profiles.matches} + 1`,
        kills: sql`${profiles.kills} + ${kills}`,
        damage: sql`${profiles.damage} + ${damage}`,
        bestScore: sql`greatest(${profiles.bestScore}, ${score})`,
        updatedAt: new Date(),
      },
    });
}

export async function getProfile(playerId: string) {
  const rows = await db.select().from(profiles).where(eq(profiles.id, playerId)).limit(1);
  return rows[0] ?? null;
}

export function findQuickMatchRoom(): Room | null {
  for (const room of registry.rooms.values()) {
    if (!room.isPublic) continue;
    if (room.state && room.state.phase !== "ended") continue;
    if (room.members.size >= MAX_PLAYERS) continue;
    return room;
  }
  return null;
}

export function roomStats() {
  let players = 0;
  let playing = 0;
  for (const r of registry.rooms.values()) {
    players += [...r.members.values()].filter((m) => !m.isBot && m.connected).length;
    if (r.state && r.state.phase === "playing") playing++;
  }
  return { rooms: registry.rooms.size, players, playing };
}
