// Shared simulation types. Pure data only - no DOM, no Node APIs.
// Used by the authoritative server simulation AND the offline browser solo mode.

export type MatchPhase = "lobby" | "countdown" | "playing" | "ended";

export interface PlayerInput {
  /** monotonic input sequence from the client (used for ack / reconciliation) */
  seq: number;
  /** move axis -1..1 */
  mx: number;
  my: number;
  /** aim angle in radians */
  aim: number;
  /** fire held */
  fire: boolean;
  /** dash requested */
  dash: boolean;
}

export const EMPTY_INPUT: PlayerInput = {
  seq: 0,
  mx: 0,
  my: 0,
  aim: 0,
  fire: false,
  dash: false,
};

export interface SimPlayer {
  id: string;
  name: string;
  colorIndex: number;
  isBot: boolean;
  connected: boolean;

  x: number;
  y: number;
  vx: number;
  vy: number;
  aim: number;

  /** hydration = health. Drains constantly. */
  hp: number;
  alive: boolean;

  shootCd: number;
  dashCd: number;
  dashTime: number;
  hitFlash: number;
  spawnShield: number;

  score: number;
  kills: number;
  damage: number;
  pickups: number;
  survivedFor: number;
  placement: number;

  lastAckSeq: number;

  // bot-only scratch data
  botTimer: number;
  botStrafe: number;
  botAccuracy: number;
  botTargetId: string | null;
}

export interface SimBullet {
  id: number;
  owner: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  dmg: number;
}

export type PickupKind = 0 | 1; // 0 = water, 1 = surge (big)

export interface SimPickup {
  id: number;
  x: number;
  y: number;
  kind: PickupKind;
  active: boolean;
  respawn: number;
}

export interface SimObstacle {
  x: number;
  y: number;
  r: number;
}

export type SimEventType =
  | "shot"
  | "hit"
  | "kill"
  | "pickup"
  | "dash"
  | "storm"
  | "countdown"
  | "start"
  | "end";

export interface SimEvent {
  t: SimEventType;
  x: number;
  y: number;
  /** subject player id */
  id?: string;
  /** actor player id */
  by?: string;
  /** magnitude (damage / count) */
  v?: number;
}

export interface SimState {
  tick: number;
  phase: MatchPhase;
  /** seconds left in the current phase (countdown) or match */
  phaseTime: number;
  elapsed: number;
  seed: number;
  players: SimPlayer[];
  bullets: SimBullet[];
  pickups: SimPickup[];
  obstacles: SimObstacle[];
  storm: { x: number; y: number; r: number };
  events: SimEvent[];
  nextEntityId: number;
  winnerId: string | null;
  finished: boolean;
}

/** Compact wire snapshot (keys kept short, numbers rounded). */
export interface WirePlayer {
  i: string;
  n: string;
  c: number;
  x: number;
  y: number;
  a: number;
  h: number;
  l: 0 | 1; // alive
  b: 0 | 1; // bot
  o: 0 | 1; // connected
  s: number; // score
  k: number; // kills
  d: number; // dash active
  f: number; // hit flash
  p: number; // placement
  q: number; // last acked input seq
}

export interface WireSnapshot {
  k: number; // tick
  ph: MatchPhase;
  pt: number; // phase time
  el: number; // elapsed
  st: [number, number, number]; // storm x,y,r
  pl: WirePlayer[];
  bu: Array<[number, number, number, number]>; // id,x,y,colorIndex
  pu: Array<[number, number, number, number]>; // id,x,y,kind
  ev: SimEvent[];
  w: string | null;
}

export interface MatchResultRow {
  playerId: string;
  name: string;
  isBot: boolean;
  placement: number;
  score: number;
  kills: number;
  damage: number;
  survivedFor: number;
}
