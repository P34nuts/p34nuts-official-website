import {
  EMPTY_INPUT,
  type MatchResultRow,
  type PlayerInput,
  type SimBullet,
  type SimEvent,
  type SimPlayer,
  type SimState,
  type WirePlayer,
  type WireSnapshot,
} from "./types";

/* ------------------------------------------------------------------ */
/* Tunables                                                            */
/* ------------------------------------------------------------------ */

export const WORLD = {
  size: 1800,
  center: 900,
  radius: 880,
};

export const RULES = {
  tickRate: 20,
  countdown: 3.4,
  matchDuration: 180,
  postMatch: 10,

  playerRadius: 18,
  moveSpeed: 232,
  accel: 14,
  friction: 9,

  maxHp: 100,
  startHp: 100,
  baseDrain: 1.15,
  drainRamp: 0.016, // extra drain per second of match time
  spawnShield: 1.6,

  shootCost: 3,
  shootCooldown: 0.26,
  bulletSpeed: 660,
  bulletLife: 1.05,
  bulletRadius: 6,
  bulletDamage: 11,

  dashCost: 7,
  dashCooldown: 1.5,
  dashTime: 0.18,
  dashSpeed: 3.1,

  pickupRadius: 20,
  pickupWater: 22,
  pickupSurge: 42,
  pickupRespawn: 9,
  pickupCount: 14,

  stormGrace: 14,
  stormShrink: 6.1,
  stormMinRadius: 95,
  stormDamage: 17,

  killReward: 26,

  scorePerDamage: 1,
  scorePerKill: 120,
  scorePerPickup: 8,
  scorePerSecond: 2,
  scoreWin: 300,
};

export const PLAYER_COLORS = [
  "#38bdf8",
  "#f472b6",
  "#facc15",
  "#4ade80",
  "#c084fc",
  "#fb923c",
  "#2dd4bf",
  "#f87171",
];

export const MAX_PLAYERS = 8;

/* ------------------------------------------------------------------ */
/* Utils                                                               */
/* ------------------------------------------------------------------ */

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v);
const r2 = (v: number) => Math.round(v * 100) / 100;

/* ------------------------------------------------------------------ */
/* Construction                                                        */
/* ------------------------------------------------------------------ */

export interface SeatSpec {
  id: string;
  name: string;
  isBot: boolean;
  colorIndex: number;
  connected?: boolean;
}

export function createPlayer(spec: SeatSpec, x: number, y: number, aim: number): SimPlayer {
  return {
    id: spec.id,
    name: spec.name,
    colorIndex: spec.colorIndex,
    isBot: spec.isBot,
    connected: spec.connected ?? true,
    x,
    y,
    vx: 0,
    vy: 0,
    aim,
    hp: RULES.startHp,
    alive: true,
    shootCd: 0,
    dashCd: 0,
    dashTime: 0,
    hitFlash: 0,
    spawnShield: RULES.spawnShield,
    score: 0,
    kills: 0,
    damage: 0,
    pickups: 0,
    survivedFor: 0,
    placement: 0,
    lastAckSeq: 0,
    botTimer: 0,
    botStrafe: Math.random() < 0.5 ? 1 : -1,
    botAccuracy: 0.1,
    botTargetId: null,
  };
}

export function createMatch(seats: SeatSpec[], seed = Date.now() % 2147483647): SimState {
  const rand = mulberry32(seed);
  const obstacles: SimState["obstacles"] = [];
  let guard = 0;
  while (obstacles.length < 13 && guard++ < 400) {
    const ang = rand() * Math.PI * 2;
    const dist = 140 + rand() * (WORLD.radius - 260);
    const x = WORLD.center + Math.cos(ang) * dist;
    const y = WORLD.center + Math.sin(ang) * dist;
    const r = 38 + rand() * 46;
    if (obstacles.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + r + 120)) continue;
    obstacles.push({ x, y, r });
  }

  const pickups: SimState["pickups"] = [];
  for (let i = 0; i < RULES.pickupCount; i++) {
    const p = randomPointInArena(rand, obstacles, WORLD.radius - 90);
    pickups.push({
      id: i + 1,
      x: p.x,
      y: p.y,
      kind: i % 5 === 0 ? 1 : 0,
      active: true,
      respawn: 0,
    });
  }

  const count = Math.max(seats.length, 1);
  const players = seats.map((seat, i) => {
    const ang = (i / count) * Math.PI * 2 + rand() * 0.2;
    const dist = WORLD.radius * 0.66;
    const x = WORLD.center + Math.cos(ang) * dist;
    const y = WORLD.center + Math.sin(ang) * dist;
    const p = createPlayer(seat, x, y, Math.atan2(WORLD.center - y, WORLD.center - x));
    p.botAccuracy = 0.055 + rand() * 0.09;
    return p;
  });

  return {
    tick: 0,
    phase: "countdown",
    phaseTime: RULES.countdown,
    elapsed: 0,
    seed,
    players,
    bullets: [],
    pickups,
    obstacles,
    storm: { x: WORLD.center, y: WORLD.center, r: WORLD.radius },
    events: [],
    nextEntityId: 1000,
    winnerId: null,
    finished: false,
  };
}

function randomPointInArena(
  rand: () => number,
  obstacles: SimState["obstacles"],
  maxDist: number,
): { x: number; y: number } {
  for (let i = 0; i < 60; i++) {
    const ang = rand() * Math.PI * 2;
    const dist = rand() * maxDist;
    const x = WORLD.center + Math.cos(ang) * dist;
    const y = WORLD.center + Math.sin(ang) * dist;
    if (obstacles.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + 40)) continue;
    return { x, y };
  }
  return { x: WORLD.center, y: WORLD.center };
}

/* ------------------------------------------------------------------ */
/* Simulation step                                                     */
/* ------------------------------------------------------------------ */

export type InputMap = Map<string, PlayerInput>;

export function stepMatch(state: SimState, dt: number, inputs: InputMap): void {
  if (state.phase === "ended") {
    state.phaseTime = Math.max(0, state.phaseTime - dt);
    state.tick++;
    return;
  }

  if (state.phase === "countdown") {
    const before = Math.ceil(state.phaseTime);
    state.phaseTime -= dt;
    const after = Math.ceil(state.phaseTime);
    if (after !== before && after >= 0) {
      pushEvent(state, { t: "countdown", x: 0, y: 0, v: after });
    }
    if (state.phaseTime <= 0) {
      state.phase = "playing";
      state.phaseTime = RULES.matchDuration;
      pushEvent(state, { t: "start", x: 0, y: 0 });
    }
    state.tick++;
    return;
  }

  state.elapsed += dt;
  state.phaseTime = Math.max(0, state.phaseTime - dt);

  // storm
  if (state.elapsed > RULES.stormGrace) {
    state.storm.r = Math.max(
      RULES.stormMinRadius,
      WORLD.radius - (state.elapsed - RULES.stormGrace) * RULES.stormShrink,
    );
  }

  const rand = mulberry32((state.seed + state.tick * 2654435761) >>> 0);

  // players
  for (const p of state.players) {
    if (!p.alive) continue;
    p.survivedFor += dt;
    p.score += RULES.scorePerSecond * dt;
    p.shootCd = Math.max(0, p.shootCd - dt);
    p.dashCd = Math.max(0, p.dashCd - dt);
    p.dashTime = Math.max(0, p.dashTime - dt);
    p.hitFlash = Math.max(0, p.hitFlash - dt);
    p.spawnShield = Math.max(0, p.spawnShield - dt);

    const input = p.isBot ? botInput(state, p, dt, rand) : inputs.get(p.id) ?? EMPTY_INPUT;
    if (input.seq > p.lastAckSeq) p.lastAckSeq = input.seq;

    // movement
    let mx = input.mx;
    let my = input.my;
    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }
    const speed = RULES.moveSpeed * (p.dashTime > 0 ? RULES.dashSpeed : 1);
    const targetVx = mx * speed;
    const targetVy = my * speed;
    const blend = 1 - Math.exp(-(mag > 0.02 ? RULES.accel : RULES.friction) * dt);
    p.vx += (targetVx - p.vx) * blend;
    p.vy += (targetVy - p.vy) * blend;
    p.x += p.vx * dt;
    p.y += p.vy * dt;

    if (Number.isFinite(input.aim)) p.aim = input.aim;

    // dash
    if (input.dash && p.dashCd <= 0 && p.hp > RULES.dashCost) {
      p.dashCd = RULES.dashCooldown;
      p.dashTime = RULES.dashTime;
      p.hp -= RULES.dashCost;
      const dmag = Math.hypot(mx, my);
      const dx = dmag > 0.1 ? mx / dmag : Math.cos(p.aim);
      const dy = dmag > 0.1 ? my / dmag : Math.sin(p.aim);
      p.vx = dx * RULES.moveSpeed * RULES.dashSpeed;
      p.vy = dy * RULES.moveSpeed * RULES.dashSpeed;
      pushEvent(state, { t: "dash", x: p.x, y: p.y, id: p.id });
    }

    // shooting
    if (input.fire && p.shootCd <= 0 && p.hp > RULES.shootCost) {
      p.shootCd = RULES.shootCooldown;
      p.hp -= RULES.shootCost;
      const spread = (rand() - 0.5) * 0.045;
      const ang = p.aim + spread;
      state.bullets.push({
        id: state.nextEntityId++,
        owner: p.id,
        x: p.x + Math.cos(ang) * (RULES.playerRadius + 6),
        y: p.y + Math.sin(ang) * (RULES.playerRadius + 6),
        vx: Math.cos(ang) * RULES.bulletSpeed + p.vx * 0.25,
        vy: Math.sin(ang) * RULES.bulletSpeed + p.vy * 0.25,
        life: RULES.bulletLife,
        dmg: RULES.bulletDamage,
      });
      pushEvent(state, { t: "shot", x: p.x, y: p.y, id: p.id });
    }

    // collisions with obstacles
    for (const o of state.obstacles) {
      const dx = p.x - o.x;
      const dy = p.y - o.y;
      const d = Math.hypot(dx, dy);
      const min = o.r + RULES.playerRadius;
      if (d < min && d > 0.0001) {
        p.x = o.x + (dx / d) * min;
        p.y = o.y + (dy / d) * min;
        p.vx *= 0.6;
        p.vy *= 0.6;
      }
    }

    // arena bounds
    const bdx = p.x - WORLD.center;
    const bdy = p.y - WORLD.center;
    const bd = Math.hypot(bdx, bdy);
    const maxD = WORLD.radius - RULES.playerRadius;
    if (bd > maxD) {
      p.x = WORLD.center + (bdx / bd) * maxD;
      p.y = WORLD.center + (bdy / bd) * maxD;
      p.vx *= 0.4;
      p.vy *= 0.4;
    }

    // hydration drain + storm
    const drain = RULES.baseDrain + state.elapsed * RULES.drainRamp;
    p.hp -= drain * dt;
    const stormDist = Math.hypot(p.x - state.storm.x, p.y - state.storm.y);
    if (stormDist > state.storm.r) {
      p.hp -= RULES.stormDamage * dt;
      if (state.tick % 10 === 0) pushEvent(state, { t: "storm", x: p.x, y: p.y, id: p.id });
    }

    // pickups
    for (const pk of state.pickups) {
      if (!pk.active) continue;
      if (Math.hypot(pk.x - p.x, pk.y - p.y) < RULES.pickupRadius + RULES.playerRadius) {
        pk.active = false;
        pk.respawn = RULES.pickupRespawn;
        const gain = pk.kind === 1 ? RULES.pickupSurge : RULES.pickupWater;
        p.hp = Math.min(RULES.maxHp, p.hp + gain);
        p.pickups++;
        p.score += RULES.scorePerPickup * (pk.kind === 1 ? 2 : 1);
        pushEvent(state, { t: "pickup", x: pk.x, y: pk.y, id: p.id, v: pk.kind });
      }
    }

    p.hp = clamp(p.hp, -10, RULES.maxHp);
    if (p.hp <= 0) killPlayer(state, p, null);
  }

  // player separation (soft)
  for (let i = 0; i < state.players.length; i++) {
    const a = state.players[i];
    if (!a.alive) continue;
    for (let j = i + 1; j < state.players.length; j++) {
      const b = state.players[j];
      if (!b.alive) continue;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.hypot(dx, dy);
      const min = RULES.playerRadius * 2;
      if (d < min && d > 0.0001) {
        const push = (min - d) / 2;
        a.x -= (dx / d) * push;
        a.y -= (dy / d) * push;
        b.x += (dx / d) * push;
        b.y += (dy / d) * push;
      }
    }
  }

  // bullets
  for (let i = state.bullets.length - 1; i >= 0; i--) {
    const b = state.bullets[i];
    b.life -= dt;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    let dead = b.life <= 0;

    if (!dead && Math.hypot(b.x - WORLD.center, b.y - WORLD.center) > WORLD.radius) dead = true;
    if (!dead) {
      for (const o of state.obstacles) {
        if (Math.hypot(b.x - o.x, b.y - o.y) < o.r + RULES.bulletRadius) {
          dead = true;
          pushEvent(state, { t: "hit", x: b.x, y: b.y, v: 0 });
          break;
        }
      }
    }
    if (!dead) {
      for (const p of state.players) {
        if (!p.alive || p.id === b.owner || p.spawnShield > 0) continue;
        if (Math.hypot(b.x - p.x, b.y - p.y) < RULES.playerRadius + RULES.bulletRadius) {
          dead = true;
          p.hp -= b.dmg;
          p.hitFlash = 0.22;
          const shooter = state.players.find((s) => s.id === b.owner);
          if (shooter) {
            shooter.damage += b.dmg;
            shooter.score += b.dmg * RULES.scorePerDamage;
          }
          pushEvent(state, { t: "hit", x: b.x, y: b.y, id: p.id, by: b.owner, v: b.dmg });
          if (p.hp <= 0) killPlayer(state, p, shooter ?? null);
          break;
        }
      }
    }
    if (dead) {
      state.bullets[i] = state.bullets[state.bullets.length - 1];
      state.bullets.pop();
    }
  }

  // pickup respawns
  for (const pk of state.pickups) {
    if (pk.active) continue;
    pk.respawn -= dt;
    if (pk.respawn <= 0) {
      const p = randomPointInArena(rand, state.obstacles, Math.max(140, state.storm.r - 60));
      pk.x = p.x;
      pk.y = p.y;
      pk.active = true;
    }
  }

  // win condition
  const alive = state.players.filter((p) => p.alive);
  const humanSeats = state.players.length;
  if ((humanSeats > 1 && alive.length <= 1) || state.phaseTime <= 0 || alive.length === 0) {
    endMatch(state);
  }

  state.tick++;
}

function pushEvent(state: SimState, ev: SimEvent) {
  if (state.events.length < 64) state.events.push(ev);
}

function killPlayer(state: SimState, victim: SimPlayer, killer: SimPlayer | null) {
  if (!victim.alive) return;
  victim.alive = false;
  victim.hp = 0;
  const aliveAfter = state.players.filter((p) => p.alive).length;
  victim.placement = aliveAfter + 1;
  if (killer && killer.id !== victim.id) {
    killer.kills++;
    killer.score += RULES.scorePerKill;
    killer.hp = Math.min(RULES.maxHp, killer.hp + RULES.killReward);
  }
  pushEvent(state, {
    t: "kill",
    x: victim.x,
    y: victim.y,
    id: victim.id,
    by: killer?.id,
  });
}

export function endMatch(state: SimState) {
  if (state.phase === "ended") return;
  const alive = state.players.filter((p) => p.alive).sort((a, b) => b.hp - a.hp);
  alive.forEach((p, i) => {
    p.placement = i + 1;
    if (i === 0) {
      p.score += RULES.scoreWin;
      state.winnerId = p.id;
    }
  });
  if (!state.winnerId && state.players.length) {
    const best = [...state.players].sort((a, b) => a.placement - b.placement)[0];
    state.winnerId = best?.id ?? null;
  }
  state.phase = "ended";
  state.phaseTime = RULES.postMatch;
  state.finished = true;
  state.bullets.length = 0;
  pushEvent(state, { t: "end", x: 0, y: 0, id: state.winnerId ?? undefined });
}

export function matchResults(state: SimState): MatchResultRow[] {
  return [...state.players]
    .sort((a, b) => a.placement - b.placement || b.score - a.score)
    .map((p) => ({
      playerId: p.id,
      name: p.name,
      isBot: p.isBot,
      placement: p.placement || 1,
      score: Math.round(p.score),
      kills: p.kills,
      damage: Math.round(p.damage),
      survivedFor: Math.round(p.survivedFor),
    }));
}

/* ------------------------------------------------------------------ */
/* Bot AI                                                              */
/* ------------------------------------------------------------------ */

function botInput(state: SimState, bot: SimPlayer, dt: number, rand: () => number): PlayerInput {
  bot.botTimer -= dt;
  if (bot.botTimer <= 0) {
    bot.botTimer = 0.5 + rand() * 0.7;
    bot.botStrafe = rand() < 0.5 ? 1 : -1;
    const enemies = state.players.filter((p) => p.alive && p.id !== bot.id);
    let best: SimPlayer | null = null;
    let bestD = Infinity;
    for (const e of enemies) {
      const d = Math.hypot(e.x - bot.x, e.y - bot.y);
      if (d < bestD) {
        bestD = d;
        best = e;
      }
    }
    bot.botTargetId = best?.id ?? null;
  }

  let mx = 0;
  let my = 0;
  let fire = false;
  let dash = false;
  let aim = bot.aim;

  const toCenterX = state.storm.x - bot.x;
  const toCenterY = state.storm.y - bot.y;
  const distCenter = Math.hypot(toCenterX, toCenterY);
  const safe = state.storm.r - 70;

  if (distCenter > safe) {
    // run to safety - highest priority
    mx = toCenterX / (distCenter || 1);
    my = toCenterY / (distCenter || 1);
    if (distCenter > state.storm.r && bot.dashCd <= 0) dash = true;
  } else {
    // hunt water when thirsty
    const thirsty = bot.hp < 55;
    let targetX: number | null = null;
    let targetY: number | null = null;
    if (thirsty) {
      let bestD = Infinity;
      for (const pk of state.pickups) {
        if (!pk.active) continue;
        if (Math.hypot(pk.x - state.storm.x, pk.y - state.storm.y) > safe) continue;
        const d = Math.hypot(pk.x - bot.x, pk.y - bot.y);
        if (d < bestD) {
          bestD = d;
          targetX = pk.x;
          targetY = pk.y;
        }
      }
    }

    const target = bot.botTargetId
      ? state.players.find((p) => p.id === bot.botTargetId && p.alive)
      : undefined;

    if (targetX !== null && targetY !== null) {
      const dx = targetX - bot.x;
      const dy = targetY - bot.y;
      const d = Math.hypot(dx, dy) || 1;
      mx = dx / d;
      my = dy / d;
      if (target) aim = Math.atan2(target.y - bot.y, target.x - bot.x);
    } else if (target) {
      const dx = target.x - bot.x;
      const dy = target.y - bot.y;
      const d = Math.hypot(dx, dy) || 1;
      const ideal = 260;
      const approach = d > ideal ? 1 : d < ideal * 0.65 ? -1 : 0;
      mx = (dx / d) * approach + (-dy / d) * bot.botStrafe * 0.8;
      my = (dy / d) * approach + (dx / d) * bot.botStrafe * 0.8;
      // lead the shot
      const travel = d / RULES.bulletSpeed;
      const px = target.x + target.vx * travel;
      const py = target.y + target.vy * travel;
      aim = Math.atan2(py - bot.y, px - bot.x) + (rand() - 0.5) * bot.botAccuracy * 4;
      const blocked = state.obstacles.some((o) => segCircle(bot.x, bot.y, target.x, target.y, o));
      fire = d < 520 && !blocked && bot.hp > 25;
      if (d < 140 && bot.dashCd <= 0 && rand() < 0.03) dash = true;
    } else {
      mx = Math.cos(bot.aim) * 0.4;
      my = Math.sin(bot.aim) * 0.4;
    }
  }

  const m = Math.hypot(mx, my);
  if (m > 1) {
    mx /= m;
    my /= m;
  }
  return { seq: 0, mx, my, aim, fire, dash };
}

function segCircle(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  o: { x: number; y: number; r: number },
): boolean {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return Math.hypot(x1 - o.x, y1 - o.y) < o.r;
  let t = ((o.x - x1) * dx + (o.y - y1) * dy) / len2;
  t = clamp(t, 0, 1);
  const cx = x1 + dx * t;
  const cy = y1 + dy * t;
  return Math.hypot(cx - o.x, cy - o.y) < o.r + 8;
}

/* ------------------------------------------------------------------ */
/* Wire encoding                                                       */
/* ------------------------------------------------------------------ */

export function encodeSnapshot(state: SimState): WireSnapshot {
  const colorOf = new Map(state.players.map((p) => [p.id, p.colorIndex] as const));
  return {
    k: state.tick,
    ph: state.phase,
    pt: r2(state.phaseTime),
    el: r2(state.elapsed),
    st: [Math.round(state.storm.x), Math.round(state.storm.y), Math.round(state.storm.r)],
    pl: state.players.map<WirePlayer>((p) => ({
      i: p.id,
      n: p.name,
      c: p.colorIndex,
      x: Math.round(p.x),
      y: Math.round(p.y),
      a: r2(p.aim),
      h: Math.round(p.hp),
      l: p.alive ? 1 : 0,
      b: p.isBot ? 1 : 0,
      o: p.connected ? 1 : 0,
      s: Math.round(p.score),
      k: p.kills,
      d: p.dashTime > 0 ? 1 : 0,
      f: p.hitFlash > 0 ? 1 : 0,
      p: p.placement,
      q: p.lastAckSeq,
    })),
    bu: state.bullets.map((b) => [
      b.id,
      Math.round(b.x),
      Math.round(b.y),
      colorOf.get(b.owner) ?? 0,
    ]),
    pu: state.pickups
      .filter((p) => p.active)
      .map((p) => [p.id, Math.round(p.x), Math.round(p.y), p.kind]),
    ev: state.events,
    w: state.winnerId,
  };
}

export function obstaclePayload(state: SimState) {
  return state.obstacles.map((o) => [Math.round(o.x), Math.round(o.y), Math.round(o.r)]);
}

export function sanitizeInput(raw: unknown): PlayerInput | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const num = (v: unknown, lo: number, hi: number) => {
    const n = typeof v === "number" && Number.isFinite(v) ? v : 0;
    return clamp(n, lo, hi);
  };
  return {
    seq: Math.max(0, Math.min(1e9, Math.floor(num(o.seq, 0, 1e9)))),
    mx: num(o.mx, -1, 1),
    my: num(o.my, -1, 1),
    aim: num(o.aim, -Math.PI * 2, Math.PI * 2),
    fire: o.fire === true,
    dash: o.dash === true,
  };
}

export const createBullet = (b: SimBullet) => b;
