/**
 * All client -> server calls go through here.
 *
 * When the frontend is deployed on GitHub Pages (static) the backend lives on a
 * separate Node host. Set NEXT_PUBLIC_API_BASE at build time, e.g.
 *   NEXT_PUBLIC_API_BASE=https://lastdrop-api.example.com
 * When frontend and backend are served by the same Next.js server (default)
 * the base stays empty and relative URLs are used.
 */
const RAW_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "";
export const API_BASE = RAW_BASE.replace(/\/$/, "");

export function apiUrl(path: string): string {
  return `${API_BASE}${path}`;
}

export const IS_REMOTE_API = API_BASE.length > 0;
