import type { PlayerInput } from "@/game/core/types";
import { apiUrl } from "./api";
import type { ChatMessage, PublicRoom, ServerMessage } from "@/server/rooms";

export type NetStatus = "connecting" | "online" | "reconnecting" | "offline";

export interface NetHandlers {
  onLobby?: (room: PublicRoom) => void;
  onSnap?: (snap: Extract<ServerMessage, { t: "snap" }>["s"], serverTs: number) => void;
  onMap?: (obstacles: number[][], seed: number) => void;
  onChat?: (m: ChatMessage) => void;
  onResults?: (rows: Extract<ServerMessage, { t: "results" }>["rows"], winner: string | null) => void;
  onStatus?: (status: NetStatus, ping: number) => void;
  onBye?: (reason: string) => void;
}

export interface RoomCredentials {
  code: string;
  playerId: string;
  token: string;
}

export class NetClient {
  private es: EventSource | null = null;
  private inputTimer: ReturnType<typeof setInterval> | null = null;
  private failures = 0;
  private closed = false;
  private pendingInput: PlayerInput | null = null;
  private inFlight = false;
  private lastSendAt = 0;

  status: NetStatus = "connecting";
  ping = 0;

  constructor(
    public creds: RoomCredentials,
    private handlers: NetHandlers,
  ) {}

  connect() {
    this.closed = false;
    this.openStream();
    if (!this.inputTimer) {
      this.inputTimer = setInterval(() => this.flushInput(), 50);
    }
  }

  private setStatus(s: NetStatus) {
    if (this.status === s) return;
    this.status = s;
    this.handlers.onStatus?.(s, this.ping);
  }

  private openStream() {
    if (this.closed) return;
    this.es?.close();
    const { code, playerId, token } = this.creds;
    const url = apiUrl(`/api/rooms/${encodeURIComponent(code)}/stream?playerId=${encodeURIComponent(
      playerId,
    )}&token=${encodeURIComponent(token)}`);
    this.setStatus(this.failures > 0 ? "reconnecting" : "connecting");
    const es = new EventSource(url);
    this.es = es;

    es.onopen = () => {
      this.failures = 0;
      this.setStatus("online");
    };
    es.onmessage = (ev) => {
      let msg: ServerMessage;
      try {
        msg = JSON.parse(ev.data) as ServerMessage;
      } catch {
        return;
      }
      this.setStatus("online");
      switch (msg.t) {
        case "lobby":
          this.handlers.onLobby?.(msg.room);
          break;
        case "snap":
          this.handlers.onSnap?.(msg.s, msg.ts);
          break;
        case "map":
          this.handlers.onMap?.(msg.obstacles, msg.seed);
          break;
        case "chat":
          this.handlers.onChat?.(msg.m);
          break;
        case "results":
          this.handlers.onResults?.(msg.rows, msg.winner);
          break;
        case "bye":
          this.handlers.onBye?.(msg.reason);
          this.close();
          break;
      }
    };
    es.onerror = () => {
      this.failures++;
      if (this.failures > 8) {
        this.setStatus("offline");
        this.handlers.onBye?.("Lost connection to the match server.");
        this.close();
        return;
      }
      this.setStatus("reconnecting");
    };
  }

  queueInput(input: PlayerInput) {
    this.pendingInput = input;
  }

  private async flushInput() {
    if (this.closed || !this.pendingInput || this.inFlight) return;
    const input = this.pendingInput;
    this.pendingInput = null;
    this.inFlight = true;
    const started = performance.now();
    this.lastSendAt = started;
    try {
      const res = await this.action("input", { input });
      if (res.ok) {
        this.ping = Math.round(performance.now() - started);
        if (this.status === "reconnecting" && this.es?.readyState === EventSource.OPEN) {
          this.setStatus("online");
        }
      }
    } catch {
      /* transient */
    } finally {
      this.inFlight = false;
    }
  }

  async action(
    action: string,
    extra: Record<string, unknown> = {},
  ): Promise<{ ok: boolean; error?: string; room?: PublicRoom }> {
    const { code, playerId, token } = this.creds;
    try {
      const res = await fetch(apiUrl(`/api/rooms/${encodeURIComponent(code)}/action`), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, playerId, token, ...extra }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string; room?: PublicRoom };
      return data;
    } catch {
      return { ok: false, error: "Network error." };
    }
  }

  get lastPing() {
    return this.ping;
  }

  get idleMs() {
    return performance.now() - this.lastSendAt;
  }

  close() {
    this.closed = true;
    this.es?.close();
    this.es = null;
    if (this.inputTimer) clearInterval(this.inputTimer);
    this.inputTimer = null;
  }
}
