import type { MatchPhase, SimEvent } from "@/game/core/types";

export interface ViewPlayer {
  id: string;
  name: string;
  colorIndex: number;
  x: number;
  y: number;
  aim: number;
  hp: number;
  alive: boolean;
  isBot: boolean;
  connected: boolean;
  score: number;
  kills: number;
  dash: boolean;
  flash: boolean;
  placement: number;
}

export interface ViewBullet {
  id: number;
  x: number;
  y: number;
  c: number;
}

export interface ViewPickup {
  id: number;
  x: number;
  y: number;
  kind: number;
}

export interface ViewState {
  phase: MatchPhase;
  phaseTime: number;
  elapsed: number;
  storm: { x: number; y: number; r: number };
  players: ViewPlayer[];
  bullets: ViewBullet[];
  pickups: ViewPickup[];
  obstacles: Array<{ x: number; y: number; r: number }>;
  winner: string | null;
}

export interface MatchSource {
  readonly kind: "local" | "net";
  /** advance / interpolate. Returns the view to render. */
  update(dt: number, getInput: (aim: number) => { seq: number; mx: number; my: number; aim: number; fire: boolean; dash: boolean }): ViewState;
  drainEvents(): SimEvent[];
  readonly selfId: string;
  dispose(): void;
}

export const EMPTY_VIEW: ViewState = {
  phase: "lobby",
  phaseTime: 0,
  elapsed: 0,
  storm: { x: 900, y: 900, r: 880 },
  players: [],
  bullets: [],
  pickups: [],
  obstacles: [],
  winner: null,
};
