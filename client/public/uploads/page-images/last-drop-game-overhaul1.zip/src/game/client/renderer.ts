import { PLAYER_COLORS, RULES, WORLD } from "@/game/core/sim";
import type { SimEvent } from "@/game/core/types";
import type { ViewState } from "./view";

export type QualityTier = "low" | "high";

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  kind: "drop" | "ring" | "text";
  text?: string;
}

export interface RenderOptions {
  quality: QualityTier;
  reducedMotion: boolean;
  selfId: string;
  showHitNumbers: boolean;
}

export class Renderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private particles: Particle[] = [];
  private shake = 0;
  private hitStop = 0;
  private camX = WORLD.center;
  private camY = WORLD.center;
  private scale = 1;
  private dpr = 1;
  private cssW = 0;
  private cssH = 0;
  private time = 0;
  /** screen-space position of the local player (used for mouse aiming) */
  selfScreen = { x: 0, y: 0 };

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("Canvas 2D is not available in this browser.");
    this.ctx = ctx;
    this.resize("high");
  }

  resize(quality: QualityTier) {
    const rect = this.canvas.getBoundingClientRect();
    const maxDpr = quality === "low" ? 1 : 2;
    const dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
    const w = Math.max(320, Math.round(rect.width));
    const h = Math.max(240, Math.round(rect.height));
    this.cssW = w;
    this.cssH = h;
    this.dpr = dpr;
    const pxW = Math.round(w * dpr);
    const pxH = Math.round(h * dpr);
    if (this.canvas.width !== pxW || this.canvas.height !== pxH) {
      this.canvas.width = pxW;
      this.canvas.height = pxH;
    }
    const maxDim = Math.max(w, h);
    this.scale = Math.min(1.15, Math.max(0.42, maxDim / 1080));
  }

  get viewport() {
    return { w: this.cssW, h: this.cssH };
  }

  spawnEvents(events: SimEvent[], view: ViewState, opts: RenderOptions) {
    const low = opts.quality === "low";
    for (const ev of events) {
      const color = ev.id
        ? PLAYER_COLORS[view.players.find((p) => p.id === ev.id)?.colorIndex ?? 0]
        : "#7dd3fc";
      switch (ev.t) {
        case "shot":
          if (!low) this.burst(ev.x, ev.y, 3, color, 70, 0.22, 2);
          break;
        case "hit": {
          this.burst(ev.x, ev.y, low ? 4 : 10, "#bae6fd", 150, 0.4, 3);
          if (ev.id === opts.selfId) {
            this.shake = Math.min(14, this.shake + (opts.reducedMotion ? 2 : 7));
            this.hitStop = opts.reducedMotion ? 0 : 0.035;
          } else if (ev.by === opts.selfId) {
            this.shake = Math.min(8, this.shake + (opts.reducedMotion ? 0 : 2));
            if (opts.showHitNumbers && ev.v) {
              this.particles.push({
                x: ev.x,
                y: ev.y,
                vx: 0,
                vy: -42,
                life: 0.7,
                maxLife: 0.7,
                size: 16,
                color: "#fde68a",
                kind: "text",
                text: String(Math.round(ev.v)),
              });
            }
          }
          break;
        }
        case "pickup":
          this.ring(ev.x, ev.y, ev.v === 1 ? "#38bdf8" : "#7dd3fc", 0.5);
          this.burst(ev.x, ev.y, low ? 4 : 12, "#7dd3fc", 120, 0.5, 3);
          break;
        case "dash":
          if (!low) this.ring(ev.x, ev.y, color, 0.35);
          break;
        case "kill":
          this.burst(ev.x, ev.y, low ? 10 : 28, color, 260, 0.9, 4);
          this.ring(ev.x, ev.y, color, 0.7);
          this.shake = Math.min(20, this.shake + (opts.reducedMotion ? 3 : 11));
          break;
        case "storm":
          if (!low) this.burst(ev.x, ev.y, 2, "#f97316", 60, 0.4, 2);
          break;
      }
    }
  }

  private burst(x: number, y: number, n: number, color: string, speed: number, life: number, size: number) {
    const cap = 420;
    for (let i = 0; i < n && this.particles.length < cap; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.3 + Math.random() * 0.7);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life,
        maxLife: life,
        size: size * (0.6 + Math.random()),
        color,
        kind: "drop",
      });
    }
  }

  private ring(x: number, y: number, color: string, life: number) {
    this.particles.push({
      x,
      y,
      vx: 0,
      vy: 0,
      life,
      maxLife: life,
      size: 10,
      color,
      kind: "ring",
    });
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles[i] = this.particles[this.particles.length - 1];
        this.particles.pop();
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 1 - 2.4 * dt;
      p.vy *= 1 - 2.4 * dt;
    }
  }

  render(view: ViewState, dt: number, opts: RenderOptions) {
    const ctx = this.ctx;
    this.time += dt;
    if (this.hitStop > 0) {
      this.hitStop -= dt;
      dt *= 0.25;
    }
    this.updateParticles(dt);
    this.shake = Math.max(0, this.shake - dt * 42);

    const self = view.players.find((p) => p.id === opts.selfId);
    const spectate = !self || !self.alive ? view.players.find((p) => p.alive) : self;
    const focus = self && self.alive ? self : spectate ?? self;
    const targetX = focus ? focus.x : WORLD.center;
    const targetY = focus ? focus.y : WORLD.center;
    const follow = 1 - Math.exp(-11 * dt);
    this.camX += (targetX - this.camX) * follow;
    this.camY += (targetY - this.camY) * follow;

    const w = this.cssW;
    const h = this.cssH;
    const s = this.scale;
    const shakeX = this.shake ? (Math.random() - 0.5) * this.shake : 0;
    const shakeY = this.shake ? (Math.random() - 0.5) * this.shake : 0;

    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.fillStyle = "#050b16";
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    ctx.translate(w / 2 + shakeX, h / 2 + shakeY);
    ctx.scale(s, s);
    ctx.translate(-this.camX, -this.camY);

    const low = opts.quality === "low";

    // arena floor
    const grd = ctx.createRadialGradient(
      WORLD.center,
      WORLD.center,
      60,
      WORLD.center,
      WORLD.center,
      WORLD.radius,
    );
    grd.addColorStop(0, "#0d2238");
    grd.addColorStop(1, "#071423");
    ctx.beginPath();
    ctx.arc(WORLD.center, WORLD.center, WORLD.radius, 0, Math.PI * 2);
    ctx.fillStyle = grd;
    ctx.fill();

    if (!low) {
      ctx.save();
      ctx.clip();
      ctx.strokeStyle = "rgba(56,189,248,0.07)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let g = 0; g <= WORLD.size; g += 120) {
        ctx.moveTo(g, 0);
        ctx.lineTo(g, WORLD.size);
        ctx.moveTo(0, g);
        ctx.lineTo(WORLD.size, g);
      }
      ctx.stroke();
      ctx.restore();
    }

    ctx.strokeStyle = "rgba(125,211,252,0.35)";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(WORLD.center, WORLD.center, WORLD.radius, 0, Math.PI * 2);
    ctx.stroke();

    // obstacles
    for (const o of view.obstacles) {
      ctx.beginPath();
      ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2);
      ctx.fillStyle = "#14293f";
      ctx.fill();
      ctx.strokeStyle = "rgba(148,197,255,0.25)";
      ctx.lineWidth = 3;
      ctx.stroke();
      if (!low) {
        ctx.beginPath();
        ctx.arc(o.x - o.r * 0.25, o.y - o.r * 0.28, o.r * 0.42, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(125,211,252,0.07)";
        ctx.fill();
      }
    }

    // pickups
    for (const pk of view.pickups) {
      const pulse = 1 + Math.sin(this.time * 4 + pk.id) * 0.1;
      const r = (pk.kind === 1 ? 17 : 11) * pulse;
      ctx.beginPath();
      ctx.arc(pk.x, pk.y, r, 0, Math.PI * 2);
      ctx.fillStyle = pk.kind === 1 ? "#22d3ee" : "#38bdf8";
      ctx.fill();
      ctx.beginPath();
      ctx.arc(pk.x, pk.y, r + 6, 0, Math.PI * 2);
      ctx.strokeStyle = pk.kind === 1 ? "rgba(34,211,238,0.45)" : "rgba(56,189,248,0.3)";
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // bullets
    for (const b of view.bullets) {
      const color = PLAYER_COLORS[b.c % PLAYER_COLORS.length];
      ctx.beginPath();
      ctx.arc(b.x, b.y, RULES.bulletRadius, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      if (!low) {
        ctx.beginPath();
        ctx.arc(b.x, b.y, RULES.bulletRadius + 4, 0, Math.PI * 2);
        ctx.fillStyle = color.replace(")", ", 0.25)").replace("rgb", "rgba");
        ctx.globalAlpha = 0.25;
        ctx.fill();
        ctx.globalAlpha = 1;
      }
    }

    // particles
    for (const p of this.particles) {
      const a = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = a;
      if (p.kind === "ring") {
        ctx.beginPath();
        ctx.arc(p.x, p.y, (1 - a) * 60 + 8, 0, Math.PI * 2);
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 3 * a + 1;
        ctx.stroke();
      } else if (p.kind === "text") {
        ctx.font = `bold ${p.size}px ui-sans-serif, system-ui, sans-serif`;
        ctx.fillStyle = p.color;
        ctx.textAlign = "center";
        ctx.fillText(p.text ?? "", p.x, p.y);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    // players
    for (const p of view.players) {
      const color = PLAYER_COLORS[p.colorIndex % PLAYER_COLORS.length];
      if (!p.alive) {
        ctx.globalAlpha = 0.18;
        ctx.beginPath();
        ctx.arc(p.x, p.y, RULES.playerRadius, 0, Math.PI * 2);
        ctx.fillStyle = "#64748b";
        ctx.fill();
        ctx.globalAlpha = 1;
        continue;
      }

      if (p.dash && !low) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, RULES.playerRadius + 10, 0, Math.PI * 2);
        ctx.strokeStyle = color;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 4;
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      // barrel
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.aim);
      ctx.fillStyle = "rgba(226,246,255,0.85)";
      ctx.fillRect(RULES.playerRadius - 4, -4, 18, 8);
      ctx.restore();

      // body (drop shape)
      ctx.beginPath();
      ctx.arc(p.x, p.y, RULES.playerRadius, 0, Math.PI * 2);
      ctx.fillStyle = p.flash ? "#ffffff" : color;
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = p.id === opts.selfId ? "#f8fafc" : "rgba(2,6,23,0.6)";
      ctx.stroke();

      if (!low) {
        ctx.beginPath();
        ctx.arc(p.x - 5, p.y - 6, 5, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255,255,255,0.45)";
        ctx.fill();
      }

      // hydration ring
      const pct = Math.max(0, Math.min(1, p.hp / RULES.maxHp));
      ctx.beginPath();
      ctx.arc(p.x, p.y, RULES.playerRadius + 7, -Math.PI / 2, -Math.PI / 2 + pct * Math.PI * 2);
      ctx.strokeStyle = pct > 0.5 ? "#38bdf8" : pct > 0.25 ? "#facc15" : "#ef4444";
      ctx.lineWidth = 4;
      ctx.stroke();

      // name
      ctx.font = "600 13px ui-sans-serif, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillStyle = p.id === opts.selfId ? "#e0f2fe" : "rgba(226,232,240,0.78)";
      ctx.fillText(
        `${p.name}${p.isBot ? " ·AI" : ""}${p.connected ? "" : " ⚠"}`,
        p.x,
        p.y - RULES.playerRadius - 14,
      );

      if (p.id === opts.selfId) {
        this.selfScreen = {
          x: w / 2 + (p.x - this.camX) * s,
          y: h / 2 + (p.y - this.camY) * s,
        };
      }
    }

    // storm overlay
    ctx.save();
    ctx.beginPath();
    ctx.rect(
      this.camX - w / (2 * s) - 50,
      this.camY - h / (2 * s) - 50,
      w / s + 100,
      h / s + 100,
    );
    ctx.arc(view.storm.x, view.storm.y, view.storm.r, 0, Math.PI * 2, true);
    ctx.fillStyle = "rgba(244,63,94,0.17)";
    ctx.fill("evenodd");
    ctx.restore();

    ctx.beginPath();
    ctx.arc(view.storm.x, view.storm.y, view.storm.r, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(248,113,113,${0.55 + Math.sin(this.time * 3) * 0.2})`;
    ctx.lineWidth = 5;
    ctx.stroke();

    ctx.restore();

    this.drawMinimap(view, opts);
  }

  private drawMinimap(view: ViewState, opts: RenderOptions) {
    const ctx = this.ctx;
    const size = Math.max(74, Math.min(124, this.cssW * 0.17));
    const pad = 12;
    const x = this.cssW - size - pad;
    const y = pad + 54;
    const k = size / WORLD.size;

    ctx.save();
    ctx.globalAlpha = 0.82;
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(2,10,22,0.75)";
    ctx.fill();
    ctx.strokeStyle = "rgba(125,211,252,0.35)";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(x + view.storm.x * k, y + view.storm.y * k, view.storm.r * k, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(248,113,113,0.8)";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    for (const p of view.players) {
      if (!p.alive) continue;
      ctx.beginPath();
      ctx.arc(x + p.x * k, y + p.y * k, p.id === opts.selfId ? 3.6 : 2.6, 0, Math.PI * 2);
      ctx.fillStyle =
        p.id === opts.selfId ? "#ffffff" : PLAYER_COLORS[p.colorIndex % PLAYER_COLORS.length];
      ctx.fill();
    }
    ctx.restore();
  }
}
