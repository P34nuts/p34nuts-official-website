/**
 * Tiny WebAudio synth. No audio assets are shipped - every sound is generated,
 * which keeps the bundle small and avoids licensing issues.
 */

export type SfxName =
  | "click"
  | "ready"
  | "tick"
  | "start"
  | "shot"
  | "hit"
  | "damage"
  | "pickup"
  | "dash"
  | "kill"
  | "victory"
  | "defeat"
  | "join"
  | "message";

interface AudioSettings {
  sfx: number;
  music: number;
}

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicTimer: ReturnType<typeof setInterval> | null = null;
  private musicStep = 0;
  private settings: AudioSettings = { sfx: 0.7, music: 0.35 };
  private lastPlayed = new Map<string, number>();

  setSettings(s: Partial<AudioSettings>) {
    this.settings = { ...this.settings, ...s };
    if (this.sfxGain) this.sfxGain.gain.value = this.settings.sfx;
    if (this.musicGain) this.musicGain.gain.value = this.settings.music * 0.35;
  }

  /** Must be called from a user gesture on mobile browsers. */
  unlock() {
    const ctx = this.ensure();
    if (ctx && ctx.state === "suspended") void ctx.resume();
  }

  private ensure(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (this.ctx) return this.ctx;
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    try {
      this.ctx = new Ctor();
    } catch {
      return null;
    }
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(this.ctx.destination);
    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = this.settings.sfx;
    this.sfxGain.connect(this.master);
    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = this.settings.music * 0.35;
    this.musicGain.connect(this.master);
    return this.ctx;
  }

  private tone(opts: {
    freq: number;
    to?: number;
    dur: number;
    type?: OscillatorType;
    gain?: number;
    delay?: number;
    dest?: GainNode | null;
  }) {
    const ctx = this.ensure();
    if (!ctx || ctx.state === "closed") return;
    const dest = opts.dest ?? this.sfxGain;
    if (!dest) return;
    const t0 = ctx.currentTime + (opts.delay ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = opts.type ?? "sine";
    osc.frequency.setValueAtTime(opts.freq, t0);
    if (opts.to && opts.to !== opts.freq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, opts.to), t0 + opts.dur);
    }
    const peak = opts.gain ?? 0.25;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(peak, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + opts.dur);
    osc.connect(g);
    g.connect(dest);
    osc.start(t0);
    osc.stop(t0 + opts.dur + 0.02);
  }

  private noise(dur: number, gain = 0.2, filterFreq = 1200) {
    const ctx = this.ensure();
    if (!ctx || !this.sfxGain) return;
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const biquad = ctx.createBiquadFilter();
    biquad.type = "lowpass";
    biquad.frequency.value = filterFreq;
    const g = ctx.createGain();
    g.gain.value = gain;
    src.connect(biquad);
    biquad.connect(g);
    g.connect(this.sfxGain);
    src.start();
  }

  play(name: SfxName) {
    if (this.settings.sfx <= 0) return;
    const now = typeof performance !== "undefined" ? performance.now() : Date.now();
    const last = this.lastPlayed.get(name) ?? 0;
    const minGap = name === "shot" || name === "hit" ? 45 : 20;
    if (now - last < minGap) return;
    this.lastPlayed.set(name, now);

    switch (name) {
      case "click":
        this.tone({ freq: 520, to: 700, dur: 0.07, type: "triangle", gain: 0.14 });
        break;
      case "ready":
        this.tone({ freq: 440, to: 880, dur: 0.14, type: "triangle", gain: 0.16 });
        break;
      case "tick":
        this.tone({ freq: 660, dur: 0.1, type: "square", gain: 0.12 });
        break;
      case "start":
        this.tone({ freq: 330, to: 990, dur: 0.35, type: "sawtooth", gain: 0.18 });
        this.tone({ freq: 660, to: 1320, dur: 0.3, type: "sine", gain: 0.12, delay: 0.05 });
        break;
      case "shot":
        this.tone({ freq: 760, to: 240, dur: 0.1, type: "triangle", gain: 0.13 });
        break;
      case "hit":
        this.noise(0.12, 0.16, 2200);
        this.tone({ freq: 300, to: 120, dur: 0.1, type: "square", gain: 0.1 });
        break;
      case "damage":
        this.noise(0.2, 0.22, 900);
        this.tone({ freq: 180, to: 70, dur: 0.22, type: "sawtooth", gain: 0.16 });
        break;
      case "pickup":
        this.tone({ freq: 880, to: 1500, dur: 0.14, type: "sine", gain: 0.16 });
        break;
      case "dash":
        this.noise(0.16, 0.14, 3200);
        break;
      case "kill":
        this.tone({ freq: 220, to: 70, dur: 0.4, type: "sawtooth", gain: 0.2 });
        this.noise(0.35, 0.18, 700);
        break;
      case "victory":
        [523, 659, 784, 1046].forEach((f, i) =>
          this.tone({ freq: f, dur: 0.3, type: "triangle", gain: 0.18, delay: i * 0.12 }),
        );
        break;
      case "defeat":
        [392, 330, 262].forEach((f, i) =>
          this.tone({ freq: f, dur: 0.35, type: "sine", gain: 0.16, delay: i * 0.16 }),
        );
        break;
      case "join":
        this.tone({ freq: 620, to: 930, dur: 0.12, type: "sine", gain: 0.13 });
        break;
      case "message":
        this.tone({ freq: 740, dur: 0.06, type: "sine", gain: 0.1 });
        break;
    }
  }

  startMusic(intensity: "menu" | "match" = "menu") {
    this.stopMusic();
    const ctx = this.ensure();
    if (!ctx || this.settings.music <= 0) return;
    const menuScale = [196, 233, 262, 294, 349];
    const matchScale = [147, 175, 196, 233, 262];
    const scale = intensity === "menu" ? menuScale : matchScale;
    const period = intensity === "menu" ? 620 : 420;
    this.musicStep = 0;
    this.musicTimer = setInterval(() => {
      if (this.settings.music <= 0) return;
      const i = this.musicStep++;
      const note = scale[(i * 3) % scale.length];
      this.tone({
        freq: note,
        dur: intensity === "menu" ? 0.8 : 0.5,
        type: "sine",
        gain: 0.1,
        dest: this.musicGain,
      });
      if (i % 4 === 0) {
        this.tone({
          freq: note / 2,
          dur: 1.2,
          type: "triangle",
          gain: 0.08,
          dest: this.musicGain,
        });
      }
    }, period);
  }

  stopMusic() {
    if (this.musicTimer) clearInterval(this.musicTimer);
    this.musicTimer = null;
  }
}

export const audio = new AudioEngine();

export function vibrate(pattern: number | number[], enabled: boolean) {
  if (!enabled) return;
  if (typeof navigator === "undefined" || !("vibrate" in navigator)) return;
  try {
    navigator.vibrate(pattern);
  } catch {
    /* ignore */
  }
}
