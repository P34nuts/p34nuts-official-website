import type { PlayerInput } from "@/game/core/types";

export interface TouchStickState {
  active: boolean;
  x: number; // -1..1
  y: number; // -1..1
}

export type InputScheme = "keyboard" | "touch" | "gamepad";

/**
 * Merges keyboard + mouse + touch sticks + gamepad into a single normalised
 * PlayerInput. The React layer writes touch state into this controller, the
 * game loop reads getInput() once per frame.
 */
export class InputController {
  private keys = new Set<string>();
  private pointerX = 0;
  private pointerY = 0;
  private pointerDown = false;
  private pointerSeen = false;
  private canvas: HTMLCanvasElement | null = null;
  private seq = 1;
  private dashLatched = false;
  private detachFns: Array<() => void> = [];

  moveStick: TouchStickState = { active: false, x: 0, y: 0 };
  aimStick: TouchStickState = { active: false, x: 0, y: 0 };
  touchDash = false;
  autoFire = true;
  lastScheme: InputScheme = "keyboard";
  /** screen position of the local player, set by the renderer each frame */
  selfScreen = { x: 0, y: 0 };
  onPause: (() => void) | null = null;

  attach(canvas: HTMLCanvasElement) {
    this.canvas = canvas;

    const keyDown = (e: KeyboardEvent) => {
      const code = e.code;
      if (
        [
          "ArrowUp",
          "ArrowDown",
          "ArrowLeft",
          "ArrowRight",
          "Space",
          "KeyW",
          "KeyA",
          "KeyS",
          "KeyD",
        ].includes(code)
      ) {
        e.preventDefault();
      }
      if (code === "Escape") this.onPause?.();
      if (!this.keys.has(code)) this.lastScheme = "keyboard";
      this.keys.add(code);
    };
    const keyUp = (e: KeyboardEvent) => this.keys.delete(e.code);
    const blur = () => {
      this.keys.clear();
      this.pointerDown = false;
    };
    const move = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      this.pointerX = e.clientX;
      this.pointerY = e.clientY;
      this.pointerSeen = true;
      this.lastScheme = "keyboard";
    };
    const down = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      this.pointerDown = true;
      this.pointerSeen = true;
      this.pointerX = e.clientX;
      this.pointerY = e.clientY;
    };
    const up = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      this.pointerDown = false;
    };
    const contextMenu = (e: Event) => e.preventDefault();

    window.addEventListener("keydown", keyDown, { passive: false });
    window.addEventListener("keyup", keyUp);
    window.addEventListener("blur", blur);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    canvas.addEventListener("contextmenu", contextMenu);

    this.detachFns = [
      () => window.removeEventListener("keydown", keyDown),
      () => window.removeEventListener("keyup", keyUp),
      () => window.removeEventListener("blur", blur),
      () => window.removeEventListener("pointermove", move),
      () => window.removeEventListener("pointerdown", down),
      () => window.removeEventListener("pointerup", up),
      () => window.removeEventListener("pointercancel", up),
      () => canvas.removeEventListener("contextmenu", contextMenu),
    ];
  }

  detach() {
    this.detachFns.forEach((fn) => fn());
    this.detachFns = [];
    this.keys.clear();
    this.canvas = null;
  }

  requestDash() {
    this.touchDash = true;
  }

  private gamepadInput(): { mx: number; my: number; ax: number; ay: number; fire: boolean; dash: boolean } | null {
    if (typeof navigator === "undefined" || !navigator.getGamepads) return null;
    const pads = navigator.getGamepads();
    for (const pad of pads) {
      if (!pad) continue;
      const dead = (v: number) => (Math.abs(v) < 0.18 ? 0 : v);
      const mx = dead(pad.axes[0] ?? 0);
      const my = dead(pad.axes[1] ?? 0);
      const ax = dead(pad.axes[2] ?? 0);
      const ay = dead(pad.axes[3] ?? 0);
      const fire =
        (pad.buttons[7]?.value ?? 0) > 0.3 ||
        pad.buttons[5]?.pressed === true ||
        pad.buttons[0]?.pressed === true;
      const dash =
        pad.buttons[6]?.pressed === true ||
        pad.buttons[4]?.pressed === true ||
        pad.buttons[1]?.pressed === true;
      if (mx || my || ax || ay || fire || dash) return { mx, my, ax, ay, fire, dash };
    }
    return null;
  }

  getInput(currentAim: number): PlayerInput {
    let mx = 0;
    let my = 0;
    let fire = false;
    let dash = false;
    let aim = currentAim;
    let aimSet = false;

    // keyboard
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) mx -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) mx += 1;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) my -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) my += 1;
    if (this.keys.has("Space") || this.keys.has("ShiftLeft") || this.keys.has("ShiftRight")) {
      dash = true;
    }
    if (this.pointerDown || this.keys.has("KeyJ") || this.keys.has("Enter")) fire = true;

    if (this.canvas && this.pointerSeen) {
      const dx = this.pointerX - this.selfScreen.x;
      const dy = this.pointerY - this.selfScreen.y;
      if (Math.hypot(dx, dy) > 4) {
        aim = Math.atan2(dy, dx);
        aimSet = true;
      }
    }

    // touch sticks override when active
    if (this.moveStick.active) {
      mx = this.moveStick.x;
      my = this.moveStick.y;
      this.lastScheme = "touch";
    }
    if (this.aimStick.active) {
      const mag = Math.hypot(this.aimStick.x, this.aimStick.y);
      if (mag > 0.2) {
        aim = Math.atan2(this.aimStick.y, this.aimStick.x);
        aimSet = true;
        fire = true;
      }
      this.lastScheme = "touch";
    } else if (this.autoFire && this.lastScheme === "touch" && this.moveStick.active) {
      fire = true;
    }
    if (this.touchDash) {
      dash = true;
      this.touchDash = false;
    }

    // gamepad
    const pad = this.gamepadInput();
    if (pad) {
      this.lastScheme = "gamepad";
      if (pad.mx || pad.my) {
        mx = pad.mx;
        my = pad.my;
      }
      if (pad.ax || pad.ay) {
        aim = Math.atan2(pad.ay, pad.ax);
        aimSet = true;
        fire = fire || this.autoFire;
      }
      fire = fire || pad.fire;
      dash = dash || pad.dash;
    }

    // dash is edge triggered so holding the key does not drain hydration
    let dashEdge = false;
    if (dash && !this.dashLatched) dashEdge = true;
    this.dashLatched = dash;

    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }
    if (!aimSet && mag > 0.1) aim = Math.atan2(my, mx);

    return { seq: this.seq++, mx, my, aim, fire, dash: dashEdge };
  }
}
