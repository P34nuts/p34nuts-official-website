export type QualityMode = "auto" | "low" | "high";

export interface GameSettings {
  name: string;
  sfx: number;
  music: number;
  quality: QualityMode;
  vibration: boolean;
  showFps: boolean;
  leftHanded: boolean;
  autoFire: boolean;
}

export interface LocalStats {
  soloBest: number;
  soloMatches: number;
  soloWins: number;
  onlineWins: number;
  achievements: string[];
  seenHowTo: boolean;
}

const SETTINGS_KEY = "lastdrop.settings.v1";
const STATS_KEY = "lastdrop.stats.v1";
const ID_KEY = "lastdrop.pid.v1";

export const DEFAULT_SETTINGS: GameSettings = {
  name: "",
  sfx: 0.7,
  music: 0.3,
  quality: "auto",
  vibration: true,
  showFps: false,
  leftHanded: false,
  autoFire: true,
};

export const DEFAULT_STATS: LocalStats = {
  soloBest: 0,
  soloMatches: 0,
  soloWins: 0,
  onlineWins: 0,
  achievements: [],
  seenHowTo: false,
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return { ...fallback, ...(JSON.parse(raw) as Partial<T>) };
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota / private mode - ignore */
  }
}

export const loadSettings = () => read(SETTINGS_KEY, DEFAULT_SETTINGS);
export const saveSettings = (s: GameSettings) => write(SETTINGS_KEY, s);
export const loadStats = () => read(STATS_KEY, DEFAULT_STATS);
export const saveStats = (s: LocalStats) => write(STATS_KEY, s);

export function getPlayerId(): string {
  if (typeof window === "undefined") return "server000000";
  try {
    const existing = window.localStorage.getItem(ID_KEY);
    if (existing && /^[A-Za-z0-9_-]{6,64}$/.test(existing)) return existing;
  } catch {
    /* ignore */
  }
  const id =
    "p-" +
    Math.random().toString(36).slice(2, 10) +
    Math.random().toString(36).slice(2, 10);
  try {
    window.localStorage.setItem(ID_KEY, id);
  } catch {
    /* ignore */
  }
  return id;
}

/** Short shareable friend code derived from the local player id. */
export function friendCode(name: string, playerId: string): string {
  let h = 0;
  for (let i = 0; i < playerId.length; i++) h = (h * 31 + playerId.charCodeAt(i)) >>> 0;
  const num = (h % 9000) + 1000;
  const base = (name || "PLAYER").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "PLAYER";
  return `${base}-${num}`;
}

export const ACHIEVEMENTS: Array<{ code: string; label: string; hint: string }> = [
  { code: "first_blood", label: "First Blood", hint: "Eliminate one opponent" },
  { code: "survivor", label: "Survivor", hint: "Survive 60 seconds in a match" },
  { code: "winner", label: "Last Drop", hint: "Win a match" },
  { code: "hoarder", label: "Hoarder", hint: "Collect 10 water drops in one match" },
  { code: "sharpshooter", label: "Sharpshooter", hint: "Deal 300 damage in one match" },
  { code: "triple", label: "Triple Threat", hint: "Get 3 eliminations in one match" },
];

export function levelFromXp(xp: number): { level: number; progress: number; next: number } {
  let level = 1;
  let need = 300;
  let remaining = Math.max(0, xp);
  while (remaining >= need && level < 99) {
    remaining -= need;
    level++;
    need = Math.round(need * 1.18);
  }
  return { level, progress: remaining, next: need };
}
