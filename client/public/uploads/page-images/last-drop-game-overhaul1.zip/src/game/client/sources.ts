import {
  MAX_PLAYERS,
  RULES,
  WORLD,
  createMatch,
  matchResults,
  stepMatch,
} from "@/game/core/sim";
import type { PlayerInput, SimEvent, SimState, WireSnapshot } from "@/game/core/types";
import type { MatchSource, ViewPlayer, ViewState } from "./view";

const FIXED_DT = 1 / 60;

function viewFromSim(state: SimState): ViewState {
  return {
    phase: state.phase,
    phaseTime: state.phaseTime,
    elapsed: state.elapsed,
    storm: { ...state.storm },
    players: state.players.map<ViewPlayer>((p) => ({
      id: p.id,
      name: p.name,
      colorIndex: p.colorIndex,
      x: p.x,
      y: p.y,
      aim: p.aim,
      hp: p.hp,
      alive: p.alive,
      isBot: p.isBot,
      connected: p.connected,
      score: Math.round(p.score),
      kills: p.kills,
      dash: p.dashTime > 0,
      flash: p.hitFlash > 0,
      placement: p.placement,
    })),
    bullets: state.bullets.map((b) => ({
      id: b.id,
      x: b.x,
      y: b.y,
      c: state.players.find((p) => p.id === b.owner)?.colorIndex ?? 0,
    })),
    pickups: state.pickups.filter((p) => p.active).map((p) => ({ id: p.id, x: p.x, y: p.y, kind: p.kind })),
    obstacles: state.obstacles,
    winner: state.winnerId,
  };
}

/** Offline / practice: the exact same simulation runs locally in the browser. */
export class LocalSource implements MatchSource {
  readonly kind = "local" as const;
  readonly selfId: string;
  state: SimState;
  private acc = 0;
  private events: SimEvent[] = [];
  private inputMap = new Map<string, PlayerInput>();

  constructor(selfId: string, selfName: string, botCount: number) {
    this.selfId = selfId;
    const bots = ["Rivulet", "Monsoon", "Geyser", "Cascade", "Tidal", "Drizzle", "Torrent"];
    const n = Math.max(1, Math.min(MAX_PLAYERS - 1, botCount));
    const seats = [
      { id: selfId, name: selfName, isBot: false, colorIndex: 0 },
      ...Array.from({ length: n }, (_, i) => ({
        id: `bot_${i}`,
        name: bots[i % bots.length],
        isBot: true,
        colorIndex: i + 1,
      })),
    ];
    this.state = createMatch(seats);
  }

  update(dt: number, getInput: (aim: number) => PlayerInput): ViewState {
    const self = this.state.players.find((p) => p.id === this.selfId);
    const input = getInput(self?.aim ?? 0);
    this.inputMap.set(this.selfId, input);
    this.acc = Math.min(this.acc + dt, 0.25);
    let guard = 0;
    while (this.acc >= FIXED_DT && guard++ < 8) {
      this.acc -= FIXED_DT;
      stepMatch(this.state, FIXED_DT, this.inputMap);
      if (this.state.events.length) {
        this.events.push(...this.state.events);
        this.state.events = [];
      }
      // dash is edge-triggered: consume it after one step
      if (input.dash) this.inputMap.set(this.selfId, { ...input, dash: false });
    }
    return viewFromSim(this.state);
  }

  drainEvents(): SimEvent[] {
    const e = this.events;
    this.events = [];
    return e;
  }

  results() {
    return matchResults(this.state);
  }

  dispose() {
    this.events = [];
  }
}

interface Buffered {
  at: number;
  snap: WireSnapshot;
}

const INTERP_DELAY = 110; // ms

/** Online: renders interpolated authoritative snapshots + local prediction. */
export class NetSource implements MatchSource {
  readonly kind = "net" as const;
  readonly selfId: string;
  private buffer: Buffered[] = [];
  private events: SimEvent[] = [];
  private obstacles: Array<{ x: number; y: number; r: number }> = [];
  private pred = { x: WORLD.center, y: WORLD.center, vx: 0, vy: 0, init: false };
  private lastView: ViewState | null = null;
  onInput: ((input: PlayerInput) => void) | null = null;

  constructor(selfId: string) {
    this.selfId = selfId;
  }

  setMap(obstacles: number[][]) {
    this.obstacles = obstacles.map(([x, y, r]) => ({ x, y, r }));
  }

  pushSnapshot(snap: WireSnapshot) {
    const now = performance.now();
    this.buffer.push({ at: now, snap });
    if (this.buffer.length > 24) this.buffer.shift();
    if (snap.ev?.length) this.events.push(...snap.ev);
  }

  private latest(): WireSnapshot | null {
    return this.buffer.length ? this.buffer[this.buffer.length - 1].snap : null;
  }

  private predict(dt: number, input: PlayerInput, authoritative: { x: number; y: number } | null) {
    const p = this.pred;
    if (!p.init && authoritative) {
      p.x = authoritative.x;
      p.y = authoritative.y;
      p.init = true;
    }
    let mx = input.mx;
    let my = input.my;
    const mag = Math.hypot(mx, my);
    if (mag > 1) {
      mx /= mag;
      my /= mag;
    }
    const targetVx = mx * RULES.moveSpeed;
    const targetVy = my * RULES.moveSpeed;
    const blend = 1 - Math.exp(-(mag > 0.02 ? RULES.accel : RULES.friction) * dt);
    p.vx += (targetVx - p.vx) * blend;
    p.vy += (targetVy - p.vy) * blend;
    p.x += p.vx * dt;
    p.y += p.vy * dt;

    for (const o of this.obstacles) {
      const dx = p.x - o.x;
      const dy = p.y - o.y;
      const d = Math.hypot(dx, dy);
      const min = o.r + RULES.playerRadius;
      if (d < min && d > 0.0001) {
        p.x = o.x + (dx / d) * min;
        p.y = o.y + (dy / d) * min;
      }
    }
    const bdx = p.x - WORLD.center;
    const bdy = p.y - WORLD.center;
    const bd = Math.hypot(bdx, bdy);
    const maxD = WORLD.radius - RULES.playerRadius;
    if (bd > maxD) {
      p.x = WORLD.center + (bdx / bd) * maxD;
      p.y = WORLD.center + (bdy / bd) * maxD;
    }

    if (authoritative) {
      const err = Math.hypot(authoritative.x - p.x, authoritative.y - p.y);
      if (err > 190) {
        p.x = authoritative.x;
        p.y = authoritative.y;
      } else {
        const k = 1 - Math.exp(-5 * dt);
        p.x += (authoritative.x - p.x) * k;
        p.y += (authoritative.y - p.y) * k;
      }
    }
  }

  update(dt: number, getInput: (aim: number) => PlayerInput): ViewState {
    const latest = this.latest();
    const selfAuth = latest?.pl.find((p) => p.i === this.selfId) ?? null;
    const input = getInput(selfAuth?.a ?? 0);
    this.onInput?.(input);

    if (!latest) {
      return (
        this.lastView ?? {
          phase: "countdown",
          phaseTime: 0,
          elapsed: 0,
          storm: { x: WORLD.center, y: WORLD.center, r: WORLD.radius },
          players: [],
          bullets: [],
          pickups: [],
          obstacles: this.obstacles,
          winner: null,
        }
      );
    }

    // pick interpolation pair
    const renderTime = performance.now() - INTERP_DELAY;
    let a: Buffered | null = null;
    let b: Buffered | null = null;
    for (let i = this.buffer.length - 1; i >= 0; i--) {
      if (this.buffer[i].at <= renderTime) {
        a = this.buffer[i];
        b = this.buffer[i + 1] ?? null;
        break;
      }
    }
    if (!a) {
      a = this.buffer[0];
      b = this.buffer[1] ?? null;
    }
    const t =
      a && b && b.at > a.at ? Math.max(0, Math.min(1, (renderTime - a.at) / (b.at - a.at))) : 1;
    const snapA = a.snap;
    const snapB = b?.snap ?? a.snap;
    const lerp = (p: number, q: number) => p + (q - p) * t;
    const lerpAngle = (p: number, q: number) => {
      let d = q - p;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      return p + d * t;
    };

    const alive = selfAuth?.l === 1;
    if (alive) this.predict(dt, input, { x: selfAuth!.x, y: selfAuth!.y });
    else this.pred.init = false;

    const players: ViewPlayer[] = snapB.pl.map((pb) => {
      const pa = snapA.pl.find((p) => p.i === pb.i) ?? pb;
      const isSelf = pb.i === this.selfId;
      return {
        id: pb.i,
        name: pb.n,
        colorIndex: pb.c,
        x: isSelf && alive ? this.pred.x : lerp(pa.x, pb.x),
        y: isSelf && alive ? this.pred.y : lerp(pa.y, pb.y),
        aim: isSelf && alive ? input.aim : lerpAngle(pa.a, pb.a),
        hp: pb.h,
        alive: pb.l === 1,
        isBot: pb.b === 1,
        connected: pb.o === 1,
        score: pb.s,
        kills: pb.k,
        dash: pb.d === 1,
        flash: pb.f === 1,
        placement: pb.p,
      };
    });

    const bullets = snapB.bu.map(([id, x, y, c]) => {
      const prev = snapA.bu.find((bb) => bb[0] === id);
      return prev
        ? { id, x: lerp(prev[1], x), y: lerp(prev[2], y), c }
        : { id, x, y, c };
    });

    const view: ViewState = {
      phase: snapB.ph,
      phaseTime: snapB.pt,
      elapsed: snapB.el,
      storm: { x: snapB.st[0], y: snapB.st[1], r: lerp(snapA.st[2], snapB.st[2]) },
      players,
      bullets,
      pickups: snapB.pu.map(([id, x, y, kind]) => ({ id, x, y, kind })),
      obstacles: this.obstacles,
      winner: snapB.w,
    };
    this.lastView = view;
    return view;
  }

  drainEvents(): SimEvent[] {
    const e = this.events;
    this.events = [];
    return e;
  }

  dispose() {
    this.buffer = [];
    this.events = [];
  }
}
