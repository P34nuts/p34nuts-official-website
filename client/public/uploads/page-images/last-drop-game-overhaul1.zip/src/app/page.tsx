"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { GameView } from "@/components/GameView";
import { Lobby } from "@/components/Lobby";
import { MainMenu, type ProfileData } from "@/components/MainMenu";
import { apiUrl } from "@/game/client/api";
import { audio } from "@/game/client/audio";
import { NetClient, type NetStatus } from "@/game/client/net";
import { LocalSource, NetSource } from "@/game/client/sources";
import {
  DEFAULT_SETTINGS,
  DEFAULT_STATS,
  getPlayerId,
  loadSettings,
  loadStats,
  saveSettings,
  saveStats,
  type GameSettings,
  type LocalStats,
} from "@/game/client/storage";
import type { MatchSource } from "@/game/client/view";
import type { MatchResultRow } from "@/game/core/types";
import type { ChatMessage, PublicRoom } from "@/server/rooms";

type Screen = "menu" | "lobby" | "game";

export default function Page() {
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState<Screen>("menu");
  const [settings, setSettings] = useState<GameSettings>(DEFAULT_SETTINGS);
  const [stats, setStats] = useState<LocalStats>(DEFAULT_STATS);
  const [playerId, setPlayerId] = useState("");
  const [name, setName] = useState("");
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [source, setSource] = useState<MatchSource | null>(null);
  const [room, setRoom] = useState<PublicRoom | null>(null);
  const [chat, setChat] = useState<ChatMessage[]>([]);
  const [netStatus, setNetStatus] = useState<NetStatus>("offline");
  const [ping, setPing] = useState(0);
  const [results, setResults] = useState<MatchResultRow[] | null>(null);
  const [winnerId, setWinnerId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isTouch, setIsTouch] = useState(false);
  const [debug, setDebug] = useState(false);
  const [prefillCode, setPrefillCode] = useState("");
  const [serverInfo, setServerInfo] = useState<{ rooms: number; players: number } | null>(null);

  const netRef = useRef<NetClient | null>(null);
  const netSourceRef = useRef<NetSource | null>(null);
  const screenRef = useRef<Screen>("menu");
  const localRef = useRef<LocalSource | null>(null);
  screenRef.current = screen;

  /* ---------------------------------------------------------------- */
  /* boot                                                              */
  /* ---------------------------------------------------------------- */
  useEffect(() => {
    const s = loadSettings();
    setSettings(s);
    setStats(loadStats());
    const id = getPlayerId();
    setPlayerId(id);
    setName(s.name || `Drop${Math.floor(Math.random() * 900 + 100)}`);
    audio.setSettings({ sfx: s.sfx, music: s.music });

    const params = new URLSearchParams(window.location.search);
    const roomParam = (params.get("room") ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (roomParam.length === 5) setPrefillCode(roomParam);
    setDebug(params.get("debug") === "1");

    const unlockAudio = () => audio.unlock();
    window.addEventListener("pointerdown", unlockAudio, { once: true });
    window.addEventListener("keydown", unlockAudio, { once: true });

    const coarse =
      window.matchMedia?.("(pointer: coarse)").matches ||
      "ontouchstart" in window ||
      navigator.maxTouchPoints > 0;
    setIsTouch(coarse);
    setReady(true);

    void fetch(apiUrl(`/api/profile?playerId=${encodeURIComponent(id)}`))
      .then((r) => r.json())
      .then((d: { ok: boolean; profile: ProfileData | null }) => {
        if (d.ok && d.profile) setProfile(d.profile);
      })
      .catch(() => undefined);

    void fetch(apiUrl("/api/rooms"))
      .then((r) => r.json())
      .then((d: { rooms: number; players: number }) => setServerInfo(d))
      .catch(() => undefined);

    if ("serviceWorker" in navigator && window.location.protocol === "https:") {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("/sw.js").catch(() => undefined);
      });
    }
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveSettings({ ...settings, name });
    audio.setSettings({ sfx: settings.sfx, music: settings.music });
  }, [settings, name, ready]);

  useEffect(() => {
    const t = setInterval(() => {
      const net = netRef.current;
      if (net) setPing(net.lastPing);
    }, 1000);
    return () => clearInterval(t);
  }, []);

  // browser / Android hardware back button
  useEffect(() => {
    const onPop = () => {
      if (screenRef.current === "game") {
        leaveMatch();
      } else if (screenRef.current === "lobby") {
        leaveMatch();
      }
      window.history.pushState({ screen: "menu" }, "");
    };
    window.history.pushState({ screen: "menu" }, "");
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const persistStats = useCallback((next: LocalStats) => {
    setStats(next);
    saveStats(next);
  }, []);

  /* ---------------------------------------------------------------- */
  /* solo                                                              */
  /* ---------------------------------------------------------------- */
  const startSolo = useCallback(
    (bots: number) => {
      audio.unlock();
      audio.startMusic("match");
      const src = new LocalSource(playerId || "local", name || "You", bots);
      localRef.current = src;
      setResults(null);
      setWinnerId(null);
      setSource(src);
      setScreen("game");
    },
    [playerId, name],
  );

  const finishSolo = useCallback(() => {
    const src = localRef.current;
    if (!src) return;
    const rows = src.results();
    setResults(rows);
    setWinnerId(src.state.winnerId);
    audio.stopMusic();

    const self = src.state.players.find((p) => p.id === src.selfId);
    const mine = rows.find((r) => r.playerId === src.selfId);
    if (!self || !mine) return;

    const unlocked = new Set(stats.achievements);
    if (mine.kills >= 1) unlocked.add("first_blood");
    if (mine.survivedFor >= 60) unlocked.add("survivor");
    if (mine.placement === 1) unlocked.add("winner");
    if (self.pickups >= 10) unlocked.add("hoarder");
    if (mine.damage >= 300) unlocked.add("sharpshooter");
    if (mine.kills >= 3) unlocked.add("triple");
    persistStats({
      ...stats,
      soloBest: Math.max(stats.soloBest, mine.score),
      soloMatches: stats.soloMatches + 1,
      soloWins: stats.soloWins + (mine.placement === 1 ? 1 : 0),
      achievements: [...unlocked],
      seenHowTo: true,
    });

    void fetch(apiUrl("/api/profile"), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        playerId,
        name,
        score: mine.score,
        kills: mine.kills,
        damage: mine.damage,
        placement: mine.placement,
        survivedFor: mine.survivedFor,
      }),
    })
      .then((r) => r.json())
      .then((d: { ok: boolean; profile: ProfileData | null }) => {
        if (d.ok && d.profile) setProfile(d.profile);
      })
      .catch(() => undefined);
  }, [stats, persistStats, playerId, name]);

  /* ---------------------------------------------------------------- */
  /* online                                                            */
  /* ---------------------------------------------------------------- */
  const teardownNet = useCallback(() => {
    netRef.current?.close();
    netRef.current = null;
    netSourceRef.current?.dispose();
    netSourceRef.current = null;
  }, []);

  const connect = useCallback(
    (code: string, token: string, initial: PublicRoom) => {
      teardownNet();
      const netSource = new NetSource(playerId);
      netSourceRef.current = netSource;
      const net = new NetClient(
        { code, playerId, token },
        {
          onLobby: (r) => {
            setRoom(r);
            setChat(r.chat);
            if (r.phase === "countdown" || r.phase === "playing") {
              if (screenRef.current !== "game") {
                setResults(null);
                setWinnerId(null);
                setSource(netSourceRef.current);
                setScreen("game");
                audio.startMusic("match");
              }
            } else if (r.phase === "lobby") {
              if (screenRef.current === "game") {
                setResults(null);
                setWinnerId(null);
                setScreen("lobby");
                audio.stopMusic();
              }
            }
          },
          onMap: (obstacles) => netSourceRef.current?.setMap(obstacles),
          onSnap: (snap) => netSourceRef.current?.pushSnapshot(snap),
          onChat: (m) => {
            setChat((c) => [...c.slice(-40), m]);
            if (!m.system) audio.play("message");
          },
          onResults: (rows, winner) => {
            setResults(rows);
            setWinnerId(winner);
            audio.stopMusic();
            if (winner === playerId) {
              const next = {
                ...loadStats(),
                onlineWins: loadStats().onlineWins + 1,
                achievements: [...new Set([...loadStats().achievements, "winner"])],
              };
              persistStats(next);
            }
            void fetch(apiUrl(`/api/profile?playerId=${encodeURIComponent(playerId)}`))
              .then((r) => r.json())
              .then((d: { ok: boolean; profile: ProfileData | null }) => {
                if (d.ok && d.profile) setProfile(d.profile);
              })
              .catch(() => undefined);
          },
          onStatus: (status, p) => {
            setNetStatus(status);
            setPing(p);
          },
          onBye: (reason) => {
            setError(reason);
            teardownNet();
            setScreen("menu");
            setRoom(null);
            setSource(null);
            audio.stopMusic();
          },
        },
      );
      netSource.onInput = (input) => net.queueInput(input);
      netRef.current = net;
      net.connect();
      setRoom(initial);
      setChat(initial.chat);
      setScreen(initial.phase === "lobby" ? "lobby" : "lobby");
    },
    [playerId, teardownNet, persistStats],
  );

  const roomRequest = useCallback(
    async (action: "create" | "join" | "quick", code?: string) => {
      audio.unlock();
      setBusy(action);
      setError(null);
      try {
        const res = await fetch(apiUrl("/api/rooms"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action, playerId, name, code }),
        });
        const data = (await res.json()) as {
          ok: boolean;
          error?: string;
          token?: string;
          room?: PublicRoom;
        };
        if (!data.ok || !data.room || !data.token) {
          setError(data.error ?? "Could not reach the match server. Solo play still works.");
          return;
        }
        connect(data.room.code, data.token, data.room);
        audio.play("join");
      } catch {
        setError("Match server unreachable — you can still play solo.");
      } finally {
        setBusy(null);
      }
    },
    [playerId, name, connect],
  );

  const leaveMatch = useCallback(() => {
    const net = netRef.current;
    if (net) void net.action("leave");
    teardownNet();
    localRef.current?.dispose();
    localRef.current = null;
    setSource(null);
    setRoom(null);
    setResults(null);
    setWinnerId(null);
    setScreen("menu");
    audio.stopMusic();
  }, [teardownNet]);

  const onMatchEnded = useCallback(() => {
    if (localRef.current && screenRef.current === "game") finishSolo();
  }, [finishSolo]);

  /* ---------------------------------------------------------------- */
  /* render                                                            */
  /* ---------------------------------------------------------------- */
  if (!ready) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-slate-950">
        <div className="text-center">
          <h1 className="text-3xl font-black uppercase tracking-[0.3em] text-sky-300">Last Drop</h1>
          <p className="mt-3 animate-pulse text-xs uppercase tracking-[0.3em] text-slate-500">
            Loading…
          </p>
        </div>
      </main>
    );
  }

  if (screen === "game" && source) {
    const isHost = room ? room.hostId === playerId : true;
    const online = source.kind === "net";
    return (
      <main className="h-dvh w-full overflow-hidden bg-slate-950">
        <GameView
          source={source}
          settings={settings}
          isTouch={isTouch}
          netStatus={online ? netStatus : undefined}
          ping={ping}
          debug={debug}
          results={results}
          winnerId={winnerId}
          onMatchEnded={onMatchEnded}
          onLeave={leaveMatch}
          onRematch={
            online
              ? isHost
                ? () => {
                    const net = netRef.current;
                    if (!net) return;
                    void net.action("lobby").then(() => net.action("start"));
                  }
                : null
              : () => startSolo(Math.max(1, (localRef.current?.state.players.length ?? 4) - 1))
          }
          rematchLabel={online ? "Rematch" : "Play again"}
          waitingLabel="Waiting for the host…"
        />
      </main>
    );
  }

  if (screen === "lobby" && room) {
    return (
      <main className="min-h-dvh bg-slate-950">
        <Lobby
          room={room}
          selfId={playerId}
          netStatus={netStatus}
          ping={ping}
          chat={chat}
          error={error}
          onReady={(r) => {
            audio.play("ready");
            void netRef.current?.action("ready", { ready: r });
          }}
          onStart={() => {
            audio.play("click");
            void netRef.current?.action("start").then((res) => {
              if (!res.ok && res.error) setError(res.error);
            });
          }}
          onAddBot={() => void netRef.current?.action("bot")}
          onRemoveBot={() => void netRef.current?.action("unbot")}
          onLeave={leaveMatch}
          onChat={(text) => void netRef.current?.action("chat", { text })}
        />
      </main>
    );
  }

  return (
    <main className="min-h-dvh bg-slate-950">
      <MainMenu
        key={prefillCode}
        name={name}
        onNameChange={setName}
        settings={settings}
        onSettings={setSettings}
        stats={stats}
        profile={profile}
        playerId={playerId}
        busy={busy}
        error={error}
        online={serverInfo}
        onSolo={startSolo}
        onCreateRoom={() => void roomRequest("create")}
        onJoinRoom={(code) => void roomRequest("join", code)}
        onQuickMatch={() => void roomRequest("quick")}
        prefillCode={prefillCode}
        onSeenHowTo={() => persistStats({ ...loadStats(), seenHowTo: true })}
      />
    </main>
  );
}
