import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Last Drop — Battle Royale",
  description:
    "Last Drop is a fast arcade battle royale. Your hydration is your health — collect water, outplay rivals and be the last drop standing. Play solo or with friends in a shared room.",
  applicationName: "Last Drop",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "Last Drop",
    statusBarStyle: "black-translucent",
  },
  icons: {
    icon: [{ url: "/icons/icon.svg", type: "image/svg+xml" }],
    apple: [{ url: "/icons/icon-192.png" }],
  },
  openGraph: {
    title: "Last Drop — Battle Royale",
    description: "Arcade battle royale where hydration is health. Solo or multiplayer.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#020617",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
