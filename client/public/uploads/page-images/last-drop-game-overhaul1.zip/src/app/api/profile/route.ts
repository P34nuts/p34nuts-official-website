import { getProfile, recordSoloResult, sanitizeId, sanitizeName } from "@/server/rooms";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const playerId = sanitizeId(url.searchParams.get("playerId"));
  if (!playerId) return Response.json({ ok: false, error: "Invalid id." }, { status: 400 });
  try {
    const profile = await getProfile(playerId);
    return Response.json({ ok: true, profile });
  } catch {
    return Response.json({ ok: true, profile: null });
  }
}

/**
 * Solo/practice results. These are explicitly flagged as solo and are worth
 * reduced XP, never count as online wins and never enter the ranked leaderboard
 * position for wins - so a manipulated client payload cannot fake online results.
 */
export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const o = (body ?? {}) as Record<string, unknown>;
  const playerId = sanitizeId(o.playerId);
  if (!playerId) return Response.json({ ok: false, error: "Invalid id." }, { status: 400 });
  const name = sanitizeName(o.name);
  const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : 0);

  try {
    await recordSoloResult({
      playerId,
      name,
      score: num(o.score),
      kills: num(o.kills),
      damage: num(o.damage),
      placement: num(o.placement) || 99,
      survivedFor: num(o.survivedFor),
    });
    const profile = await getProfile(playerId);
    return Response.json({ ok: true, profile });
  } catch {
    return Response.json({ ok: false, error: "Could not save." }, { status: 500 });
  }
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
