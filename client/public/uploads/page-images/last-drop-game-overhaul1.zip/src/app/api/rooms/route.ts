import {
  createRoom,
  findQuickMatchRoom,
  joinRoom,
  normalizeCode,
  publicRoom,
  roomStats,
  sanitizeId,
  sanitizeName,
} from "@/server/rooms";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({ ok: true, ...roomStats() });
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const o = (body ?? {}) as Record<string, unknown>;
  const playerId = sanitizeId(o.playerId);
  if (!playerId) return Response.json({ ok: false, error: "Invalid player id." }, { status: 400 });
  const name = sanitizeName(o.name);
  const action = typeof o.action === "string" ? o.action : "";

  if (action === "create") {
    const res = createRoom(playerId, name, o.isPublic === true);
    if ("error" in res) return Response.json({ ok: false, error: res.error }, { status: 429 });
    return Response.json({ ok: true, token: res.token, room: publicRoom(res.room) });
  }

  if (action === "join") {
    const code = normalizeCode(o.code);
    if (!code) return Response.json({ ok: false, error: "Invalid room code." }, { status: 400 });
    const res = joinRoom(code, playerId, name);
    if ("error" in res) return Response.json({ ok: false, error: res.error }, { status: 404 });
    return Response.json({ ok: true, token: res.token, room: publicRoom(res.room) });
  }

  if (action === "quick") {
    const existing = findQuickMatchRoom();
    if (existing) {
      const res = joinRoom(existing.code, playerId, name);
      if (!("error" in res)) {
        return Response.json({ ok: true, token: res.token, room: publicRoom(res.room) });
      }
    }
    const res = createRoom(playerId, name, true);
    if ("error" in res) return Response.json({ ok: false, error: res.error }, { status: 429 });
    return Response.json({ ok: true, token: res.token, room: publicRoom(res.room) });
  }

  return Response.json({ ok: false, error: "Unknown action." }, { status: 400 });
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
