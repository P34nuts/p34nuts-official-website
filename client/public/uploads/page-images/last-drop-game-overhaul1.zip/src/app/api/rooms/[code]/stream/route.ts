import { authMember, getRoom, normalizeCode, subscribe, type ServerMessage } from "@/server/rooms";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request, ctx: { params: Promise<{ code: string }> }) {
  const { code: rawCode } = await ctx.params;
  const code = normalizeCode(rawCode);
  if (!code) return new Response("bad code", { status: 400 });

  const url = new URL(request.url);
  const playerId = url.searchParams.get("playerId") ?? "";
  const token = url.searchParams.get("token") ?? "";

  const room = getRoom(code);
  if (!room) return new Response("room closed", { status: 404 });
  const member = authMember(room, playerId, token);
  if (!member) return new Response("forbidden", { status: 403 });

  const encoder = new TextEncoder();
  let unsubscribe: (() => void) | null = null;
  let keepAlive: ReturnType<typeof setInterval> | null = null;

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      const write = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          closed = true;
        }
      };

      const send = (msg: ServerMessage) => write(`data: ${JSON.stringify(msg)}\n\n`);

      write(`retry: 1500\n\n`);
      unsubscribe = subscribe(room, member, send);

      keepAlive = setInterval(() => write(`: ping ${Date.now()}\n\n`), 15000);
      (keepAlive as unknown as { unref?: () => void }).unref?.();

      const abort = () => {
        closed = true;
        if (keepAlive) clearInterval(keepAlive);
        keepAlive = null;
        unsubscribe?.();
        unsubscribe = null;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      request.signal.addEventListener("abort", abort);
    },
    cancel() {
      if (keepAlive) clearInterval(keepAlive);
      unsubscribe?.();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
