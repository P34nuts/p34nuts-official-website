import { sanitizeInput } from "@/game/core/sim";
import {
  addBot,
  applyInput,
  authMember,
  backToLobby,
  getRoom,
  leaveRoom,
  normalizeCode,
  postChat,
  publicRoom,
  removeBot,
  setReady,
  startMatch,
} from "@/server/rooms";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request, ctx: { params: Promise<{ code: string }> }) {
  const { code: rawCode } = await ctx.params;
  const code = normalizeCode(rawCode);
  if (!code) return Response.json({ ok: false, error: "Invalid room code." }, { status: 400 });

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const o = (body ?? {}) as Record<string, unknown>;
  const playerId = typeof o.playerId === "string" ? o.playerId : "";
  const token = typeof o.token === "string" ? o.token : "";
  const action = typeof o.action === "string" ? o.action : "";

  const room = getRoom(code);
  if (!room) return Response.json({ ok: false, error: "Room closed." }, { status: 404 });
  const member = authMember(room, playerId, token);
  if (!member) return Response.json({ ok: false, error: "Not authorised." }, { status: 403 });

  switch (action) {
    case "input": {
      const input = sanitizeInput(o.input);
      if (!input) return Response.json({ ok: false, error: "Bad input." }, { status: 400 });
      applyInput(room, member, input);
      return Response.json({ ok: true });
    }
    case "ready": {
      setReady(room, member, o.ready === true);
      return Response.json({ ok: true, room: publicRoom(room) });
    }
    case "start": {
      if (room.hostId !== member.id) {
        return Response.json({ ok: false, error: "Only the host can start." }, { status: 403 });
      }
      const err = startMatch(room);
      if (err) return Response.json({ ok: false, error: err }, { status: 409 });
      return Response.json({ ok: true });
    }
    case "lobby": {
      if (room.hostId !== member.id) {
        return Response.json({ ok: false, error: "Only the host can do that." }, { status: 403 });
      }
      backToLobby(room);
      return Response.json({ ok: true, room: publicRoom(room) });
    }
    case "bot": {
      if (room.hostId !== member.id) {
        return Response.json({ ok: false, error: "Only the host can do that." }, { status: 403 });
      }
      if (room.state && room.state.phase !== "ended") {
        return Response.json({ ok: false, error: "Match in progress." }, { status: 409 });
      }
      const err = addBot(room);
      if (err) return Response.json({ ok: false, error: err }, { status: 409 });
      return Response.json({ ok: true, room: publicRoom(room) });
    }
    case "unbot": {
      if (room.hostId !== member.id) {
        return Response.json({ ok: false, error: "Only the host can do that." }, { status: 403 });
      }
      removeBot(room);
      return Response.json({ ok: true, room: publicRoom(room) });
    }
    case "chat": {
      const err = postChat(room, member, typeof o.text === "string" ? o.text : "");
      if (err) return Response.json({ ok: false, error: err }, { status: 429 });
      return Response.json({ ok: true });
    }
    case "leave": {
      leaveRoom(room, member);
      return Response.json({ ok: true });
    }
    default:
      return Response.json({ ok: false, error: "Unknown action." }, { status: 400 });
  }
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
