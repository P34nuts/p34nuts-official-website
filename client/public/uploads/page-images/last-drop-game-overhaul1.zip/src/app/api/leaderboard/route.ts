import { db } from "@/db";
import { profiles } from "@/db/schema";
import { desc } from "drizzle-orm";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: profiles.id,
        name: profiles.name,
        xp: profiles.xp,
        wins: profiles.wins,
        matches: profiles.matches,
        kills: profiles.kills,
        bestScore: profiles.bestScore,
      })
      .from(profiles)
      .orderBy(desc(profiles.bestScore))
      .limit(20);
    return Response.json({
      ok: true,
      rows: rows.map((r, i) => ({ ...r, rank: i + 1, id: r.id.slice(0, 6) })),
    });
  } catch {
    return Response.json({ ok: false, rows: [] }, { status: 200 });
  }
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
