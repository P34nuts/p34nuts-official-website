import {
  boolean,
  index,
  integer,
  pgTable,
  serial,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/** Guest-first profile. The id is a client generated opaque token stored in localStorage. */
export const profiles = pgTable(
  "profiles",
  {
    id: varchar("id", { length: 64 }).primaryKey(),
    name: varchar("name", { length: 24 }).notNull(),
    xp: integer("xp").notNull().default(0),
    matches: integer("matches").notNull().default(0),
    wins: integer("wins").notNull().default(0),
    kills: integer("kills").notNull().default(0),
    damage: integer("damage").notNull().default(0),
    bestScore: integer("best_score").notNull().default(0),
    streak: integer("streak").notNull().default(0),
    bestStreak: integer("best_streak").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("profiles_best_score_idx").on(t.bestScore)],
);

export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  roomCode: varchar("room_code", { length: 8 }).notNull(),
  mode: varchar("mode", { length: 16 }).notNull().default("online"),
  playerCount: integer("player_count").notNull().default(0),
  durationSec: integer("duration_sec").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const matchResults = pgTable(
  "match_results",
  {
    id: serial("id").primaryKey(),
    matchId: integer("match_id").notNull(),
    profileId: varchar("profile_id", { length: 64 }),
    name: varchar("name", { length: 24 }).notNull(),
    isBot: boolean("is_bot").notNull().default(false),
    placement: integer("placement").notNull(),
    score: integer("score").notNull(),
    kills: integer("kills").notNull(),
    damage: integer("damage").notNull(),
    survivedFor: integer("survived_for").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("match_results_score_idx").on(t.score), index("match_results_match_idx").on(t.matchId)],
);

export const achievementsUnlocked = pgTable("achievements_unlocked", {
  id: serial("id").primaryKey(),
  profileId: varchar("profile_id", { length: 64 }).notNull(),
  code: varchar("code", { length: 32 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Profile = typeof profiles.$inferSelect;
export type MatchResultRecord = typeof matchResults.$inferSelect;
