"use client";

import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "ghost" | "danger" | "subtle";

const variants: Record<Variant, string> = {
  primary:
    "bg-gradient-to-b from-sky-400 to-sky-600 text-slate-950 shadow-[0_6px_0_#075985] hover:from-sky-300 hover:to-sky-500 active:translate-y-[3px] active:shadow-[0_3px_0_#075985]",
  ghost:
    "bg-slate-900/70 text-sky-100 border border-sky-400/30 hover:border-sky-300/70 hover:bg-slate-800/80",
  danger:
    "bg-gradient-to-b from-rose-400 to-rose-600 text-slate-950 shadow-[0_6px_0_#881337] hover:from-rose-300 active:translate-y-[3px] active:shadow-[0_3px_0_#881337]",
  subtle: "bg-slate-800/60 text-slate-200 hover:bg-slate-700/70",
};

export function Button({
  variant = "primary",
  className = "",
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      {...rest}
      className={`inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-extrabold uppercase tracking-[0.12em] transition-all duration-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-300 disabled:cursor-not-allowed disabled:opacity-40 ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Panel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`rounded-2xl border border-sky-400/15 bg-slate-950/70 p-4 shadow-[0_18px_60px_-25px_rgba(56,189,248,0.6)] backdrop-blur-md ${className}`}
    >
      {children}
    </div>
  );
}

export function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-slate-950/80 p-3 backdrop-blur-sm sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={onClose}
    >
      <div
        className="safe-pad max-h-[88dvh] w-full max-w-lg overflow-y-auto rounded-2xl border border-sky-400/20 bg-slate-950 p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between gap-4">
          <h2 className="text-lg font-black uppercase tracking-[0.2em] text-sky-300">{title}</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-800 text-xl text-slate-300 hover:bg-slate-700"
          >
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Stat({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-xl bg-slate-900/70 px-3 py-2 text-center">
      <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">{label}</div>
      <div className="text-lg font-black text-sky-200">{value}</div>
    </div>
  );
}

export function Slider({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 flex justify-between text-xs font-bold uppercase tracking-widest text-slate-300">
        {label} <span className="text-sky-300">{Math.round(value * 100)}%</span>
      </span>
      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-10 w-full accent-sky-400"
      />
    </label>
  );
}

export function Toggle({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex min-h-[48px] w-full items-center justify-between rounded-xl bg-slate-900/70 px-4 text-sm font-bold uppercase tracking-widest text-slate-200"
    >
      {label}
      <span
        className={`relative h-7 w-12 rounded-full transition-colors ${checked ? "bg-sky-500" : "bg-slate-700"}`}
      >
        <span
          className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${checked ? "left-6" : "left-1"}`}
        />
      </span>
    </button>
  );
}
