"use client";

import { useCallback, useRef } from "react";
import type { InputController } from "@/game/client/input";

interface StickProps {
  side: "left" | "right";
  label: string;
  onChange: (x: number, y: number, active: boolean) => void;
}

function Stick({ side, label, onChange }: StickProps) {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);
  const pointerId = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });

  const setKnob = useCallback((dx: number, dy: number) => {
    const knob = knobRef.current;
    if (knob) knob.style.transform = `translate(${dx}px, ${dy}px)`;
  }, []);

  const handleDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerId.current !== null) return;
    pointerId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    const rect = baseRef.current!.getBoundingClientRect();
    origin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    handleMove(e);
  };

  const handleMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerId.current !== e.pointerId) return;
    const rect = baseRef.current?.getBoundingClientRect();
    const max = Math.max(42, (rect?.width ?? 136) * 0.38);
    let dx = e.clientX - origin.current.x;
    let dy = e.clientY - origin.current.y;
    const mag = Math.hypot(dx, dy);
    if (mag > max) {
      dx = (dx / mag) * max;
      dy = (dy / mag) * max;
    }
    setKnob(dx, dy);
    onChange(dx / max, dy / max, true);
  };

  const handleUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerId.current !== e.pointerId) return;
    pointerId.current = null;
    setKnob(0, 0);
    onChange(0, 0, false);
  };

  return (
    <div
      ref={baseRef}
      onPointerDown={handleDown}
      onPointerMove={handleMove}
      onPointerUp={handleUp}
      onPointerCancel={handleUp}
      aria-label={label}
      data-side={side}
      className="pointer-events-auto relative h-[clamp(104px,27vw,136px)] w-[clamp(104px,27vw,136px)] touch-none select-none rounded-full border-2 border-sky-300/25 bg-slate-900/35" 
    >
      <div
        ref={knobRef}
        className="absolute h-[46%] w-[46%] rounded-full border border-sky-200/40 bg-sky-400/30"
        style={{ left: "27%", top: "27%" }}
      />
      <span className="pointer-events-none absolute inset-x-0 -bottom-5 text-center text-[10px] font-bold uppercase tracking-widest text-sky-200/60">
        {label}
      </span>
    </div>
  );
}

export function TouchControls({
  getController,
  leftHanded,
  onPause,
}: {
  getController: () => InputController | null;
  leftHanded: boolean;
  onPause: () => void;
}) {
  const moveStick = (
    <Stick
      side="left"
      label="Move"
      onChange={(x, y, active) => {
        const c = getController();
        if (!c) return;
        c.moveStick.x = x;
        c.moveStick.y = y;
        c.moveStick.active = active;
      }}
    />
  );
  const aimStick = (
    <Stick
      side="right"
      label="Aim / Fire"
      onChange={(x, y, active) => {
        const c = getController();
        if (!c) return;
        c.aimStick.x = x;
        c.aimStick.y = y;
        c.aimStick.active = active;
      }}
    />
  );

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      <div
        className="absolute bottom-0 left-0 right-0 flex items-end justify-between px-3 sm:px-5"
        style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 22px)" }}
      >
        <div className="flex flex-col items-start gap-4">{leftHanded ? aimStick : moveStick}</div>
        <div className="flex flex-col items-end gap-3">
          <button
            type="button"
            aria-label="Dash"
            onPointerDown={(e) => {
              e.preventDefault();
              getController()?.requestDash();
            }}
            className="pointer-events-auto mb-2 h-[clamp(60px,16vw,76px)] w-[clamp(60px,16vw,76px)] touch-none rounded-full border-2 border-amber-300/50 bg-amber-400/20 text-[11px] font-black uppercase tracking-widest text-amber-200 active:bg-amber-400/40"
          >
            Dash
          </button>
          {leftHanded ? moveStick : aimStick}
        </div>
      </div>
      <button
        type="button"
        onClick={onPause}
        aria-label="Pause"
        className="pointer-events-auto absolute right-3 h-11 w-11 rounded-xl border border-slate-500/40 bg-slate-900/70 text-lg text-slate-200"
        style={{ top: "calc(env(safe-area-inset-top, 0px) + 8px)" }}
      >
        ❚❚
      </button>
    </div>
  );
}
