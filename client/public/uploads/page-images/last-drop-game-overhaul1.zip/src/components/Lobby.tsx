"use client";

import { useEffect, useRef, useState } from "react";
import { PLAYER_COLORS } from "@/game/core/sim";
import type { ChatMessage, PublicRoom } from "@/server/rooms";
import type { NetStatus } from "@/game/client/net";
import { Button, Panel } from "./ui";

interface Props {
  room: PublicRoom;
  selfId: string;
  netStatus: NetStatus;
  ping: number;
  chat: ChatMessage[];
  error: string | null;
  onReady: (ready: boolean) => void;
  onStart: () => void;
  onAddBot: () => void;
  onRemoveBot: () => void;
  onLeave: () => void;
  onChat: (text: string) => void;
}

export function Lobby(props: Props) {
  const { room, selfId, netStatus, ping, chat, error } = props;
  const isHost = room.hostId === selfId;
  const me = room.players.find((p) => p.id === selfId);
  const humans = room.players.filter((p) => !p.isBot);
  const everyoneReady = humans.every((p) => p.ready || p.id === room.hostId);
  const [copied, setCopied] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const chatRef = useRef<HTMLDivElement | null>(null);

  const shareUrl =
    typeof window !== "undefined"
      ? `${window.location.origin}${window.location.pathname}?room=${room.code}`
      : "";

  useEffect(() => {
    chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight });
  }, [chat.length]);

  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      /* clipboard unavailable */
    }
    setCopied(label);
    setTimeout(() => setCopied(null), 1600);
  };

  const share = async () => {
    const data = {
      title: "Last Drop",
      text: `Join my Last Drop match — room ${room.code}`,
      url: shareUrl,
    };
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share(data);
        return;
      } catch {
        /* user cancelled */
      }
    }
    void copy(shareUrl, "link");
  };

  return (
    <div className="safe-pad mx-auto flex min-h-dvh w-full max-w-3xl flex-col gap-4 overflow-y-auto px-4 py-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black uppercase tracking-[0.2em] text-sky-300">Lobby</h1>
          <p className="text-[11px] uppercase tracking-widest text-slate-500">
            {room.isPublic ? "Quick match room" : "Private room"}
          </p>
        </div>
        <div
          className={`rounded-lg px-3 py-1 text-[10px] font-black uppercase tracking-widest ${
            netStatus === "online"
              ? "bg-emerald-500/15 text-emerald-300"
              : netStatus === "offline"
                ? "bg-rose-500/20 text-rose-300"
                : "bg-amber-500/20 text-amber-200"
          }`}
        >
          {netStatus === "online" ? `online · ${ping}ms` : netStatus}
        </div>
      </div>

      <Panel>
        <div className="flex flex-col items-center gap-3 sm:flex-row sm:justify-between">
          <div className="text-center sm:text-left">
            <div className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">
              Room code
            </div>
            <div className="font-mono text-4xl font-black tracking-[0.3em] text-sky-200">
              {room.code}
            </div>
          </div>
          <div className="flex w-full gap-2 sm:w-auto">
            <Button variant="ghost" className="flex-1" onClick={() => copy(room.code, "code")}>
              {copied === "code" ? "Copied!" : "Copy code"}
            </Button>
            <Button variant="ghost" className="flex-1" onClick={share}>
              {copied === "link" ? "Link copied!" : "Share invite"}
            </Button>
          </div>
        </div>
      </Panel>

      <Panel>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">
            Players {room.players.length}/{room.maxPlayers}
          </h2>
          {isHost && (
            <div className="flex gap-2">
              <button
                onClick={props.onAddBot}
                className="rounded-lg bg-slate-800 px-3 py-1.5 text-[10px] font-black uppercase tracking-widest text-slate-200 hover:bg-slate-700"
              >
                + Bot
              </button>
              <button
                onClick={props.onRemoveBot}
                className="rounded-lg bg-slate-800 px-3 py-1.5 text-[10px] font-black uppercase tracking-widest text-slate-200 hover:bg-slate-700"
              >
                − Bot
              </button>
            </div>
          )}
        </div>
        <ul className="flex flex-col gap-2">
          {room.players.map((p, i) => (
            <li
              key={p.id}
              className="flex items-center justify-between gap-3 rounded-xl bg-slate-900/70 px-3 py-2.5"
            >
              <div className="flex min-w-0 items-center gap-3">
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-600">
                  P{i + 1}
                </span>
                <span
                  className="h-3 w-3 shrink-0 rounded-full"
                  style={{ background: PLAYER_COLORS[p.colorIndex % PLAYER_COLORS.length] }}
                />
                <span className="truncate font-bold text-slate-100">
                  {p.name}
                  {p.id === selfId && <span className="ml-1 text-sky-400">(you)</span>}
                  {p.isBot && <span className="ml-1 text-slate-500">·AI</span>}
                </span>
                {p.id === room.hostId && (
                  <span className="rounded bg-amber-400/20 px-1.5 py-0.5 text-[9px] font-black uppercase tracking-widest text-amber-300">
                    Host
                  </span>
                )}
              </div>
              <span
                className={`shrink-0 text-[10px] font-black uppercase tracking-widest ${
                  !p.connected && !p.isBot
                    ? "text-amber-400"
                    : p.ready || p.id === room.hostId
                      ? "text-emerald-400"
                      : "text-slate-500"
                }`}
              >
                {!p.connected && !p.isBot
                  ? "● offline"
                  : p.ready || p.id === room.hostId
                    ? "● ready"
                    : "○ not ready"}
              </span>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel className="flex min-h-[180px] flex-col">
        <h2 className="mb-2 text-xs font-black uppercase tracking-[0.2em] text-slate-400">Chat</h2>
        <div ref={chatRef} className="mb-2 h-28 flex-1 overflow-y-auto pr-1 text-sm">
          {chat.length === 0 && (
            <p className="text-xs text-slate-600">Say hi to your opponents…</p>
          )}
          {chat.map((m) => (
            <p key={m.id} className={m.system ? "text-xs italic text-slate-500" : "text-slate-300"}>
              {!m.system && <span className="font-bold text-sky-300">{m.name}: </span>}
              {m.text}
            </p>
          ))}
        </div>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const text = draft.trim();
            if (!text) return;
            props.onChat(text.slice(0, 160));
            setDraft("");
          }}
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value.slice(0, 160))}
            placeholder="Message…"
            maxLength={160}
            className="h-11 w-full rounded-xl border border-slate-600/40 bg-slate-900/80 px-3 text-sm text-slate-100 outline-none focus:border-sky-400"
          />
          <Button type="submit" variant="subtle" className="shrink-0 px-4">
            Send
          </Button>
        </form>
      </Panel>

      {error && (
        <p className="rounded-lg bg-rose-500/15 px-3 py-2 text-center text-xs font-bold text-rose-200">
          {error}
        </p>
      )}

      <div className="sticky bottom-0 flex flex-col gap-2 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent pb-2 pt-3 sm:flex-row">
        {isHost ? (
          <Button className="flex-1" onClick={props.onStart} disabled={room.players.length < 1}>
            {everyoneReady ? "Start match" : "Start anyway"}
          </Button>
        ) : (
          <Button
            className="flex-1"
            variant={me?.ready ? "ghost" : "primary"}
            onClick={() => props.onReady(!me?.ready)}
          >
            {me?.ready ? "Not ready" : "Ready up"}
          </Button>
        )}
        <Button variant="danger" className="sm:w-40" onClick={props.onLeave}>
          Leave
        </Button>
      </div>
    </div>
  );
}
