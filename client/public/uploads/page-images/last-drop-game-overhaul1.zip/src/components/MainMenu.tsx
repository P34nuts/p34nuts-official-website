"use client";

import { useEffect, useState } from "react";
import { apiUrl } from "@/game/client/api";
import { audio } from "@/game/client/audio";
import {
  ACHIEVEMENTS,
  friendCode,
  levelFromXp,
  type GameSettings,
  type LocalStats,
} from "@/game/client/storage";
import { Button, Modal, Panel, Slider, Stat, Toggle } from "./ui";

export interface ProfileData {
  id: string;
  name: string;
  xp: number;
  matches: number;
  wins: number;
  kills: number;
  bestScore: number;
  streak: number;
  bestStreak: number;
}

interface Props {
  name: string;
  onNameChange: (v: string) => void;
  settings: GameSettings;
  onSettings: (s: GameSettings) => void;
  stats: LocalStats;
  profile: ProfileData | null;
  playerId: string;
  busy: string | null;
  error: string | null;
  online: { rooms: number; players: number } | null;
  onSolo: (bots: number) => void;
  onCreateRoom: () => void;
  onJoinRoom: (code: string) => void;
  onQuickMatch: () => void;
  prefillCode: string;
  onSeenHowTo: () => void;
}

export function MainMenu(props: Props) {
  const {
    name,
    onNameChange,
    settings,
    onSettings,
    stats,
    profile,
    playerId,
    busy,
    error,
    online,
    onSolo,
    onCreateRoom,
    onJoinRoom,
    onQuickMatch,
    prefillCode,
    onSeenHowTo,
  } = props;

  const [tab, setTab] = useState<"main" | "multi">(prefillCode ? "multi" : "main");
  const [code, setCode] = useState(prefillCode);
  const [modal, setModal] = useState<null | "settings" | "howto" | "board" | "profile">(
    stats.seenHowTo ? null : "howto",
  );
  const [board, setBoard] = useState<
    Array<{ rank: number; name: string; bestScore: number; wins: number; matches: number }>
  >([]);
  const [bots, setBots] = useState(3);

  useEffect(() => {
    if (modal !== "board") return;
    let cancelled = false;
    void fetch(apiUrl("/api/leaderboard"))
      .then((r) => r.json())
      .then((d: { ok: boolean; rows?: typeof board }) => {
        if (!cancelled && d.ok && d.rows) setBoard(d.rows);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [modal]);

  const click = () => audio.play("click");
  const level = levelFromXp(profile?.xp ?? 0);

  return (
    <div className="safe-pad relative flex min-h-dvh w-full flex-col items-center justify-center gap-5 overflow-y-auto px-4 py-8">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 top-10 h-72 w-72 rounded-full bg-sky-500/20 blur-3xl" />
        <div className="absolute -right-20 bottom-0 h-80 w-80 rounded-full bg-cyan-400/10 blur-3xl" />
      </div>

      <header className="relative text-center">
        <h1 className="text-5xl font-black uppercase tracking-[0.18em] text-transparent sm:text-6xl bg-gradient-to-b from-sky-200 to-sky-500 bg-clip-text drop-shadow-[0_6px_30px_rgba(56,189,248,0.35)]">
          Last Drop
        </h1>
        <p className="mt-2 text-[11px] font-bold uppercase tracking-[0.35em] text-sky-300/70">
          Battle Royale · stay hydrated
        </p>
      </header>

      <Panel className="relative w-full max-w-md">
        <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
          Player name
        </label>
        <input
          value={name}
          onChange={(e) => onNameChange(e.target.value.slice(0, 16))}
          placeholder="Enter a name"
          maxLength={16}
          className="mt-1 h-12 w-full rounded-xl border border-sky-400/20 bg-slate-900/80 px-4 text-base font-bold text-sky-100 outline-none placeholder:text-slate-600 focus:border-sky-400"
        />

        {tab === "main" ? (
          <div className="mt-4 flex flex-col gap-3">
            <Button
              onClick={() => {
                click();
                onSolo(bots);
              }}
              disabled={!!busy}
            >
              ▶ Play solo
            </Button>
            <div className="flex items-center justify-between rounded-xl bg-slate-900/60 px-4 py-2 text-xs font-bold uppercase tracking-widest text-slate-300">
              <span>AI opponents</span>
              <div className="flex items-center gap-2">
                <button
                  className="h-9 w-9 rounded-lg bg-slate-800 text-lg"
                  aria-label="fewer bots"
                  onClick={() => setBots((b) => Math.max(1, b - 1))}
                >
                  −
                </button>
                <span className="w-6 text-center text-base text-sky-200">{bots}</span>
                <button
                  className="h-9 w-9 rounded-lg bg-slate-800 text-lg"
                  aria-label="more bots"
                  onClick={() => setBots((b) => Math.min(7, b + 1))}
                >
                  +
                </button>
              </div>
            </div>
            <Button
              variant="ghost"
              onClick={() => {
                click();
                setTab("multi");
              }}
            >
              ⚔ Multiplayer
            </Button>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="subtle" onClick={() => setModal("howto")}>
                How to play
              </Button>
              <Button variant="subtle" onClick={() => setModal("settings")}>
                Settings
              </Button>
              <Button variant="subtle" onClick={() => setModal("board")}>
                Leaderboard
              </Button>
              <Button variant="subtle" onClick={() => setModal("profile")}>
                Profile
              </Button>
            </div>
          </div>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            <Button
              onClick={() => {
                click();
                onCreateRoom();
              }}
              disabled={!!busy}
            >
              {busy === "create" ? "Creating…" : "✦ Create room"}
            </Button>
            <div className="flex gap-2">
              <input
                value={code}
                onChange={(e) =>
                  setCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5))
                }
                placeholder="CODE"
                inputMode="text"
                autoCapitalize="characters"
                className="h-12 w-full rounded-xl border border-sky-400/20 bg-slate-900/80 px-4 text-center text-xl font-black tracking-[0.4em] text-sky-100 outline-none focus:border-sky-400"
              />
              <Button
                className="shrink-0"
                onClick={() => {
                  click();
                  onJoinRoom(code);
                }}
                disabled={code.length !== 5 || !!busy}
              >
                {busy === "join" ? "…" : "Join"}
              </Button>
            </div>
            <Button variant="ghost" onClick={onQuickMatch} disabled={!!busy}>
              {busy === "quick" ? "Searching…" : "⚡ Quick match"}
            </Button>
            <Button
              variant="subtle"
              onClick={() => {
                click();
                setTab("main");
              }}
            >
              ← Back
            </Button>
          </div>
        )}

        {error && (
          <p className="mt-3 rounded-lg bg-rose-500/15 px-3 py-2 text-center text-xs font-bold text-rose-200">
            {error}
          </p>
        )}
      </Panel>

      <div className="relative flex w-full max-w-md items-center justify-between gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-500">
        <span>
          {online ? `${online.players} online · ${online.rooms} rooms` : "Server idle"}
        </span>
        <span>Lvl {level.level} · {profile?.xp ?? 0} XP</span>
      </div>

      {modal === "settings" && (
        <Modal title="Settings" onClose={() => setModal(null)}>
          <div className="flex flex-col gap-4">
            <Slider
              label="SFX"
              value={settings.sfx}
              onChange={(v) => onSettings({ ...settings, sfx: v })}
            />
            <Slider
              label="Music"
              value={settings.music}
              onChange={(v) => onSettings({ ...settings, music: v })}
            />
            <div>
              <span className="mb-1 block text-xs font-bold uppercase tracking-widest text-slate-300">
                Graphics
              </span>
              <div className="grid grid-cols-3 gap-2">
                {(["auto", "low", "high"] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => onSettings({ ...settings, quality: q })}
                    className={`min-h-[44px] rounded-xl text-xs font-black uppercase tracking-widest ${
                      settings.quality === q
                        ? "bg-sky-500 text-slate-950"
                        : "bg-slate-800 text-slate-300"
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
            <Toggle
              label="Vibration"
              checked={settings.vibration}
              onChange={(v) => onSettings({ ...settings, vibration: v })}
            />
            <Toggle
              label="Auto fire (touch)"
              checked={settings.autoFire}
              onChange={(v) => onSettings({ ...settings, autoFire: v })}
            />
            <Toggle
              label="Left handed layout"
              checked={settings.leftHanded}
              onChange={(v) => onSettings({ ...settings, leftHanded: v })}
            />
            <Button
              variant="ghost"
              onClick={() => {
                const doc = document;
                if (doc.fullscreenElement) void doc.exitFullscreen?.();
                else void doc.documentElement.requestFullscreen?.().catch(() => undefined);
              }}
            >
              Toggle fullscreen
            </Button>
            <Button
              variant="ghost"
              onClick={() =>
                onSettings({
                  ...settings,
                  sfx: 0.7,
                  music: 0.3,
                  quality: "auto",
                  vibration: true,
                  autoFire: true,
                  leftHanded: false,
                })
              }
            >
              Reset settings
            </Button>
          </div>
        </Modal>
      )}

      {modal === "howto" && (
        <Modal
          title="How to play"
          onClose={() => {
            setModal(null);
            onSeenHowTo();
          }}
        >
          <div className="space-y-4 text-sm text-slate-300">
            <p className="rounded-xl bg-sky-500/10 p-3 text-sky-100">
              You are a drop of water. Your <b>hydration</b> drains constantly and it is also your
              health. Collect water, shoot rivals, stay inside the shrinking zone. The last drop
              standing wins.
            </p>
            <div>
              <h3 className="mb-1 text-xs font-black uppercase tracking-widest text-sky-300">
                Desktop
              </h3>
              <ul className="space-y-1 text-xs">
                <li>WASD / Arrows — move</li>
                <li>Mouse — aim · hold left button to shoot</li>
                <li>Space / Shift — dash (costs hydration)</li>
                <li>Esc — pause (solo)</li>
                <li>Gamepad supported: sticks + triggers</li>
              </ul>
            </div>
            <div>
              <h3 className="mb-1 text-xs font-black uppercase tracking-widest text-sky-300">
                Mobile
              </h3>
              <ul className="space-y-1 text-xs">
                <li>Left stick — move</li>
                <li>Right stick — aim &amp; fire</li>
                <li>Dash button — quick escape</li>
              </ul>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-[11px] uppercase tracking-widest">
              <div className="rounded-lg bg-slate-900 p-2">💧 Drop<br />+22 hydration</div>
              <div className="rounded-lg bg-slate-900 p-2">🌊 Surge<br />+42 hydration</div>
              <div className="rounded-lg bg-slate-900 p-2">🔥 Zone<br />−17/sec</div>
            </div>
          </div>
        </Modal>
      )}

      {modal === "board" && (
        <Modal title="Leaderboard" onClose={() => setModal(null)}>
          {board.length === 0 ? (
            <p className="text-sm text-slate-400">No scores recorded yet. Play a match!</p>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="text-[10px] uppercase tracking-widest text-slate-500">
                <tr>
                  <th className="py-2">#</th>
                  <th>Player</th>
                  <th className="text-right">Best</th>
                  <th className="text-right">Wins</th>
                </tr>
              </thead>
              <tbody>
                {board.map((r) => (
                  <tr key={r.rank} className="border-t border-slate-800 text-slate-300">
                    <td className="py-2">{r.rank}</td>
                    <td className="truncate">{r.name}</td>
                    <td className="text-right font-mono text-sky-300">{r.bestScore}</td>
                    <td className="text-right font-mono">{r.wins}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Modal>
      )}

      {modal === "profile" && (
        <Modal title="Profile" onClose={() => setModal(null)}>
          <div className="space-y-4">
            <div className="rounded-xl bg-slate-900/70 p-4">
              <div className="text-xs uppercase tracking-widest text-slate-400">Friend code</div>
              <div className="text-xl font-black tracking-widest text-sky-200">
                {friendCode(name, playerId)}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Stat label="Level" value={level.level} />
              <Stat label="XP" value={profile?.xp ?? 0} />
              <Stat label="Best" value={Math.max(profile?.bestScore ?? 0, stats.soloBest)} />
              <Stat label="Matches" value={profile?.matches ?? stats.soloMatches} />
              <Stat label="Wins" value={profile?.wins ?? 0} />
              <Stat label="Kills" value={profile?.kills ?? 0} />
            </div>
            <div>
              <h3 className="mb-2 text-xs font-black uppercase tracking-widest text-sky-300">
                Achievements
              </h3>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {ACHIEVEMENTS.map((a) => {
                  const got = stats.achievements.includes(a.code);
                  return (
                    <div
                      key={a.code}
                      className={`rounded-lg p-2 text-xs ${got ? "bg-sky-500/15 text-sky-100" : "bg-slate-900/70 text-slate-500"}`}
                    >
                      <div className="font-bold uppercase tracking-widest">
                        {got ? "★" : "☆"} {a.label}
                      </div>
                      <div className="text-[10px]">{a.hint}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
