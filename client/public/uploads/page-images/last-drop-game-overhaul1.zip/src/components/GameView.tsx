"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { PLAYER_COLORS, RULES } from "@/game/core/sim";
import type { MatchResultRow, SimEvent } from "@/game/core/types";
import { audio, vibrate } from "@/game/client/audio";
import { InputController } from "@/game/client/input";
import { Renderer, type QualityTier, type RenderOptions } from "@/game/client/renderer";
import type { MatchSource, ViewState } from "@/game/client/view";
import type { NetStatus } from "@/game/client/net";
import type { GameSettings } from "@/game/client/storage";
import { TouchControls } from "./TouchControls";
import { Button, Panel } from "./ui";

interface HudState {
  hp: number;
  alive: number;
  total: number;
  time: number;
  phase: string;
  countdown: number;
  score: number;
  kills: number;
  dead: boolean;
  inStorm: boolean;
  board: Array<{ id: string; name: string; score: number; kills: number; alive: boolean; color: number }>;
}

const EMPTY_HUD: HudState = {
  hp: 100,
  alive: 0,
  total: 0,
  time: 0,
  phase: "countdown",
  countdown: 0,
  score: 0,
  kills: 0,
  dead: false,
  inStorm: false,
  board: [],
};

export interface GameViewProps {
  source: MatchSource;
  settings: GameSettings;
  isTouch: boolean;
  netStatus?: NetStatus;
  ping?: number;
  debug: boolean;
  results: MatchResultRow[] | null;
  winnerId: string | null;
  onMatchEnded: () => void;
  onLeave: () => void;
  onRematch: (() => void) | null;
  rematchLabel?: string;
  waitingLabel?: string;
}

export function GameView(props: GameViewProps) {
  const {
    source,
    settings,
    isTouch,
    netStatus,
    ping,
    debug,
    results,
    winnerId,
    onMatchEnded,
    onLeave,
    onRematch,
  } = props;

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const controllerRef = useRef<InputController | null>(null);
  const settingsRef = useRef(settings);
  const pausedRef = useRef(false);
  const endedRef = useRef(false);
  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [paused, setPaused] = useState(false);
  const [feed, setFeed] = useState<Array<{ id: number; text: string }>>([]);
  const [fps, setFps] = useState(60);
  const [quality, setQuality] = useState<QualityTier>("high");
  const feedId = useRef(0);

  settingsRef.current = settings;

  const reducedMotion = useMemo(() => {
    if (typeof window === "undefined") return false;
    return window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
  }, []);

  const pushFeed = useCallback((text: string) => {
    const id = ++feedId.current;
    setFeed((f) => [...f.slice(-4), { id, text }]);
    setTimeout(() => setFeed((f) => f.filter((x) => x.id !== id)), 4200);
  }, []);

  const togglePause = useCallback(() => {
    if (source.kind !== "local") return;
    setPaused((p) => {
      pausedRef.current = !p;
      return !p;
    });
  }, [source.kind]);

  // main loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let renderer: Renderer;
    try {
      renderer = new Renderer(canvas);
    } catch {
      return;
    }
    const controller = new InputController();
    controller.attach(canvas);
    controller.autoFire = settingsRef.current.autoFire;
    controller.onPause = () => {
      if (source.kind === "local") {
        pausedRef.current = !pausedRef.current;
        setPaused(pausedRef.current);
      }
    };
    controllerRef.current = controller;
    endedRef.current = false;

    let tier: QualityTier =
      settingsRef.current.quality === "low"
        ? "low"
        : settingsRef.current.quality === "high"
          ? "high"
          : (navigator.hardwareConcurrency ?? 4) <= 4 && window.innerWidth < 900
            ? "low"
            : "high";
    setQuality(tier);
    renderer.resize(tier);

    const onResize = () => renderer.resize(tier);
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(onResize) : null;
    if (ro && wrapRef.current) ro.observe(wrapRef.current);

    let raf = 0;
    let last = performance.now();
    let hudAcc = 0;
    let fpsAcc = 0;
    let fpsFrames = 0;
    let slowTime = 0;
    let lastView: ViewState | null = null;

    const handleEvents = (events: SimEvent[], view: ViewState) => {
      const s = settingsRef.current;
      for (const ev of events) {
        const self = ev.id === source.selfId;
        switch (ev.t) {
          case "shot":
            if (self) audio.play("shot");
            break;
          case "hit":
            if (self) {
              audio.play("damage");
              vibrate(28, s.vibration);
            } else if (ev.by === source.selfId) {
              audio.play("hit");
            }
            break;
          case "pickup":
            if (self) audio.play("pickup");
            break;
          case "dash":
            if (self) audio.play("dash");
            break;
          case "countdown":
            if ((ev.v ?? 0) > 0) audio.play("tick");
            break;
          case "start":
            audio.play("start");
            break;
          case "kill": {
            const victim = view.players.find((p) => p.id === ev.id);
            const killer = view.players.find((p) => p.id === ev.by);
            pushFeed(
              killer
                ? `${killer.name} drained ${victim?.name ?? "?"}`
                : `${victim?.name ?? "?"} ran dry`,
            );
            audio.play("kill");
            if (self) vibrate([40, 60, 90], s.vibration);
            break;
          }
          case "end": {
            if (!endedRef.current) {
              endedRef.current = true;
              const won = ev.id === source.selfId;
              audio.play(won ? "victory" : "defeat");
              vibrate(won ? [60, 50, 120] : 120, s.vibration);
              onMatchEnded();
            }
            break;
          }
        }
      }
    };

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      let dt = (now - last) / 1000;
      last = now;
      if (!Number.isFinite(dt) || dt < 0) dt = 0;
      dt = Math.min(dt, 0.1);

      fpsAcc += dt;
      fpsFrames++;
      if (fpsAcc >= 0.5) {
        const current = fpsFrames / fpsAcc;
        setFps(Math.round(current));
        fpsAcc = 0;
        fpsFrames = 0;
        if (settingsRef.current.quality === "auto") {
          if (current < 45) slowTime += 0.5;
          else slowTime = Math.max(0, slowTime - 0.25);
          if (slowTime > 2.5 && tier === "high") {
            tier = "low";
            setQuality("low");
            renderer.resize(tier);
            slowTime = 0;
          }
        }
      }

      const effectiveDt = pausedRef.current ? 0 : dt;
      const view = source.update(effectiveDt, (aim) => {
        controller.autoFire = settingsRef.current.autoFire;
        if (pausedRef.current) return { seq: 0, mx: 0, my: 0, aim, fire: false, dash: false };
        return controller.getInput(aim);
      });
      lastView = view;

      const opts: RenderOptions = {
        quality: tier,
        reducedMotion,
        selfId: source.selfId,
        showHitNumbers: true,
      };
      const events = source.drainEvents();
      if (events.length) {
        renderer.spawnEvents(events, view, opts);
        handleEvents(events, view);
      }
      renderer.render(view, effectiveDt, opts);
      controller.selfScreen = renderer.selfScreen;

      hudAcc += dt;
      if (hudAcc > 0.1) {
        hudAcc = 0;
        const self = view.players.find((p) => p.id === source.selfId);
        const alive = view.players.filter((p) => p.alive).length;
        const inStorm = self
          ? Math.hypot(self.x - view.storm.x, self.y - view.storm.y) > view.storm.r
          : false;
        setHud({
          hp: self ? Math.max(0, self.hp) : 0,
          alive,
          total: view.players.length,
          time: view.phase === "playing" ? view.phaseTime : 0,
          phase: view.phase,
          countdown: view.phase === "countdown" ? Math.ceil(view.phaseTime) : 0,
          score: self ? self.score : 0,
          kills: self ? self.kills : 0,
          dead: !!self && !self.alive,
          inStorm,
          board: [...view.players]
            .sort((a, b) => Number(b.alive) - Number(a.alive) || b.score - a.score)
            .slice(0, 8)
            .map((p) => ({
              id: p.id,
              name: p.name,
              score: p.score,
              kills: p.kills,
              alive: p.alive,
              color: p.colorIndex,
            })),
        });
      }
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      ro?.disconnect();
      controller.detach();
      controllerRef.current = null;
      void lastView;
    };
  }, [source, reducedMotion, pushFeed, onMatchEnded]);

  const timeLabel = `${Math.floor(hud.time / 60)}:${String(Math.floor(hud.time % 60)).padStart(2, "0")}`;
  const hpPct = Math.max(0, Math.min(100, hud.hp));
  const showResults = results !== null;

  return (
    <div ref={wrapRef} className="relative h-full w-full overflow-hidden bg-slate-950">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" />

      {/* top bar */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 px-3"
        style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 8px)" }}
      >
        <div className="flex flex-col gap-1">
          <div className="rounded-lg bg-slate-950/70 px-3 py-1.5 text-xs font-black uppercase tracking-widest text-sky-200 ring-1 ring-sky-400/20">
            {hud.alive}/{hud.total} alive
          </div>
          <div className="hidden min-w-[150px] flex-col gap-0.5 rounded-lg bg-slate-950/60 p-2 text-[11px] ring-1 ring-slate-500/20 sm:flex">
            {hud.board.map((p, i) => (
              <div
                key={p.id}
                className={`flex items-center justify-between gap-2 ${p.alive ? "" : "opacity-40 line-through"}`}
              >
                <span className="flex items-center gap-1.5 truncate">
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ background: PLAYER_COLORS[p.color % PLAYER_COLORS.length] }}
                  />
                  <span className="truncate font-bold text-slate-200">
                    {i + 1}. {p.name}
                  </span>
                </span>
                <span className="font-mono text-sky-300">{p.score}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-col gap-1">
            {feed.map((f) => (
              <div
                key={f.id}
                className="animate-slide-in rounded-md bg-rose-500/15 px-2 py-1 text-[11px] font-bold text-rose-200 ring-1 ring-rose-400/30"
              >
                {f.text}
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center gap-1">
          <div className="rounded-lg bg-slate-950/70 px-4 py-1.5 font-mono text-lg font-black text-sky-100 ring-1 ring-sky-400/20">
            {timeLabel}
          </div>
          {netStatus && (
            <div
              className={`rounded-md px-2 py-0.5 text-[10px] font-black uppercase tracking-widest ${
                netStatus === "online"
                  ? "bg-emerald-500/15 text-emerald-300"
                  : netStatus === "offline"
                    ? "bg-rose-500/20 text-rose-300"
                    : "bg-amber-500/20 text-amber-200"
              }`}
            >
              {netStatus === "online" ? `online · ${ping ?? 0}ms` : netStatus}
            </div>
          )}
        </div>

        <div className="w-[96px]" />
      </div>

      {/* hydration */}
      <div
        className="pointer-events-none absolute inset-x-0 z-10 mx-auto flex w-full max-w-[440px] flex-col items-center gap-1 px-5"
        style={{
          bottom: isTouch
            ? "calc(env(safe-area-inset-bottom, 0px) + 190px)"
            : "calc(env(safe-area-inset-bottom, 0px) + 18px)",
        }}
      >
        <div className="flex w-full items-center justify-between text-[10px] font-black uppercase tracking-[0.2em] text-sky-200/80">
          <span>Hydration</span>
          <span>
            {Math.round(hpPct)} · {hud.score} pts · {hud.kills} kills
          </span>
        </div>
        <div className="h-3 w-full overflow-hidden rounded-full bg-slate-800/80 ring-1 ring-sky-400/20">
          <div
            className={`h-full rounded-full transition-[width] duration-100 ${
              hpPct > 50 ? "bg-sky-400" : hpPct > 25 ? "bg-amber-400" : "bg-rose-500"
            }`}
            style={{ width: `${hpPct}%` }}
          />
        </div>
      </div>

      {/* centre messages */}
      {hud.phase === "countdown" && !showResults && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="animate-pop text-center">
            <div className="text-7xl font-black text-sky-200 drop-shadow-[0_0_30px_rgba(56,189,248,0.6)]">
              {hud.countdown > 0 ? hud.countdown : "GO!"}
            </div>
            <div className="mt-2 text-xs font-bold uppercase tracking-[0.3em] text-slate-300">
              Stay hydrated · last drop wins
            </div>
          </div>
        </div>
      )}

      {hud.inStorm && !hud.dead && hud.phase === "playing" && (
        <div className="pointer-events-none absolute inset-0 z-10 flex items-start justify-center pt-24">
          <div className="animate-pulse rounded-lg bg-rose-600/80 px-4 py-2 text-sm font-black uppercase tracking-widest text-white">
            ⚠ Evaporating — get back inside
          </div>
        </div>
      )}

      {hud.dead && !showResults && (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="rounded-xl bg-slate-950/80 px-6 py-4 text-center ring-1 ring-rose-400/30">
            <div className="text-2xl font-black uppercase tracking-widest text-rose-300">
              You ran dry
            </div>
            <div className="mt-1 text-xs uppercase tracking-widest text-slate-300">
              Spectating · {hud.alive} still alive
            </div>
          </div>
        </div>
      )}

      {/* touch controls */}
      {isTouch && !showResults && !paused && (
        <TouchControls
          getController={() => controllerRef.current}
          leftHanded={settings.leftHanded}
          onPause={() => (source.kind === "local" ? togglePause() : onLeave())}
        />
      )}

      {!isTouch && (
        <button
          onClick={() => (source.kind === "local" ? togglePause() : onLeave())}
          className="absolute right-3 z-20 rounded-lg border border-slate-500/40 bg-slate-900/70 px-3 py-2 text-xs font-bold uppercase tracking-widest text-slate-200 hover:bg-slate-800"
          style={{ top: "calc(env(safe-area-inset-top, 0px) + 92px)" }}
        >
          {source.kind === "local" ? "Esc · Pause" : "Leave"}
        </button>
      )}

      {debug && (
        <div className="absolute bottom-2 left-2 z-30 rounded-lg bg-black/70 p-2 font-mono text-[10px] text-lime-300">
          <div>fps {fps}</div>
          <div>q {quality}</div>
          <div>src {source.kind}</div>
          <div>net {netStatus ?? "-"} {ping ?? 0}ms</div>
          <div>phase {hud.phase}</div>
          <div>players {hud.total}</div>
        </div>
      )}

      {paused && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/80 p-4">
          <Panel className="w-full max-w-sm text-center">
            <h2 className="mb-4 text-2xl font-black uppercase tracking-[0.2em] text-sky-300">
              Paused
            </h2>
            <div className="flex flex-col gap-3">
              <Button onClick={togglePause}>Resume</Button>
              <Button variant="ghost" onClick={onLeave}>
                Quit match
              </Button>
            </div>
          </Panel>
        </div>
      )}

      {showResults && (
        <ResultsOverlay
          rows={results ?? []}
          selfId={source.selfId}
          winnerId={winnerId}
          onLeave={onLeave}
          onRematch={onRematch}
          rematchLabel={props.rematchLabel ?? "Rematch"}
          waitingLabel={props.waitingLabel}
        />
      )}
    </div>
  );
}

function ResultsOverlay({
  rows,
  selfId,
  winnerId,
  onLeave,
  onRematch,
  rematchLabel,
  waitingLabel,
}: {
  rows: MatchResultRow[];
  selfId: string;
  winnerId: string | null;
  onLeave: () => void;
  onRematch: (() => void) | null;
  rematchLabel: string;
  waitingLabel?: string;
}) {
  const won = winnerId === selfId;
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/88 p-3 backdrop-blur-sm">
      <Panel className="safe-pad max-h-[92dvh] w-full max-w-lg overflow-y-auto">
        <div className="text-center">
          <div
            className={`text-3xl font-black uppercase tracking-[0.3em] ${won ? "text-amber-300" : "text-sky-300"}`}
          >
            {won ? "Victory" : "Match over"}
          </div>
          <div className="mt-1 text-xs uppercase tracking-[0.2em] text-slate-400">
            {won ? "You were the last drop" : `Winner: ${rows.find((r) => r.playerId === winnerId)?.name ?? "—"}`}
          </div>
        </div>

        <div className="mt-4 overflow-hidden rounded-xl ring-1 ring-slate-600/30">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900/80 text-[10px] uppercase tracking-widest text-slate-400">
              <tr>
                <th className="px-3 py-2">#</th>
                <th className="px-2 py-2">Player</th>
                <th className="px-2 py-2 text-right">Score</th>
                <th className="px-2 py-2 text-right">K</th>
                <th className="px-3 py-2 text-right">Dmg</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr
                  key={r.playerId}
                  className={`border-t border-slate-700/40 ${
                    r.playerId === selfId ? "bg-sky-500/10 font-bold text-sky-100" : "text-slate-300"
                  }`}
                >
                  <td className="px-3 py-2">{r.placement}</td>
                  <td className="px-2 py-2 truncate">
                    {r.name}
                    {r.isBot ? " ·AI" : ""}
                  </td>
                  <td className="px-2 py-2 text-right font-mono">{r.score}</td>
                  <td className="px-2 py-2 text-right font-mono">{r.kills}</td>
                  <td className="px-3 py-2 text-right font-mono">{r.damage}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex flex-col gap-3 sm:flex-row">
          {onRematch ? (
            <Button className="flex-1" onClick={onRematch}>
              {rematchLabel}
            </Button>
          ) : (
            <div className="flex-1 rounded-xl bg-slate-900/70 px-4 py-3 text-center text-xs font-bold uppercase tracking-widest text-slate-400">
              {waitingLabel ?? "Waiting for host…"}
            </div>
          )}
          <Button variant="ghost" className="flex-1" onClick={onLeave}>
            Leave
          </Button>
        </div>
        <p className="mt-3 text-center text-[10px] uppercase tracking-widest text-slate-500">
          Hydration drains every second — {RULES.pickupWater} per drop collected
        </p>
      </Panel>
    </div>
  );
}
