import type { NextConfig } from "next";

/**
 * Two supported build modes:
 *  1. Fullstack (default)  -> `next build` + `next start`: frontend + multiplayer
 *     backend from a single Node process (Render / Railway / Fly / Docker / VPS).
 *  2. Static client         -> `npm run build:pages`: exports the client only for
 *     GitHub Pages; it talks to a remote backend via NEXT_PUBLIC_API_BASE.
 */
const isStatic = process.env.STATIC_EXPORT === "1";
const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

const allowedOrigin = process.env.CORS_ALLOW_ORIGIN ?? "*";

const nextConfig: NextConfig = {
  ...(isStatic
    ? {
        output: "export" as const,
        basePath: basePath || undefined,
        assetPrefix: basePath || undefined,
        images: { unoptimized: true },
        trailingSlash: true,
      }
    : {}),
  ...(isStatic
    ? {}
    : {
        async headers() {
          return [
            {
              source: "/api/:path*",
              headers: [
                { key: "Access-Control-Allow-Origin", value: allowedOrigin },
                { key: "Access-Control-Allow-Methods", value: "GET,POST,OPTIONS" },
                { key: "Access-Control-Allow-Headers", value: "Content-Type" },
                { key: "Access-Control-Max-Age", value: "86400" },
              ],
            },
          ];
        },
      }),
};

export default nextConfig;
