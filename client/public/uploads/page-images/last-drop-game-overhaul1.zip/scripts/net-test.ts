/**
 * Multiplayer integration QA against a running server.
 *   BASE=http://localhost:3100 npx tsx scripts/net-test.ts
 * Covers: create, join, bots, chat, start, SSE snapshots, input acks,
 * disconnect handling, match end, results broadcast and DB persistence.
 */
const BASE = process.env.BASE ?? "http://localhost:3000";

let failures = 0;
function check(label: string, cond: boolean, extra = "") {
  if (cond) console.log(`  ✓ ${label}`);
  else {
    failures++;
    console.error(`  ✗ ${label} ${extra}`);
  }
}

type Json = Record<string, unknown>;

async function post(path: string, body: Json): Promise<Json> {
  const res = await fetch(BASE + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return (await res.json()) as Json;
}

interface Collected {
  lobby: number;
  snaps: number;
  chat: string[];
  results: { rows: Array<{ name: string; placement: number; score: number }>; winner: string } | null;
  map: boolean;
  lastSnap: Json | null;
  stop: () => void;
}

function openStream(code: string, playerId: string, token: string): Collected {
  const ctrl = new AbortController();
  const out: Collected = {
    lobby: 0,
    snaps: 0,
    chat: [],
    results: null,
    map: false,
    lastSnap: null,
    stop: () => ctrl.abort(),
  };
  void (async () => {
    try {
      const res = await fetch(
        `${BASE}/api/rooms/${code}/stream?playerId=${playerId}&token=${token}`,
        { signal: ctrl.signal },
      );
      const reader = res.body!.getReader();
      const dec = new TextDecoder();
      let buf = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop() ?? "";
        for (const part of parts) {
          const line = part.split("\n").find((l) => l.startsWith("data: "));
          if (!line) continue;
          const msg = JSON.parse(line.slice(6)) as Json;
          if (msg.t === "lobby") out.lobby++;
          else if (msg.t === "snap") {
            out.snaps++;
            out.lastSnap = msg.s as Json;
          } else if (msg.t === "chat") out.chat.push(String((msg.m as Json).text));
          else if (msg.t === "map") out.map = true;
          else if (msg.t === "results") out.results = msg as unknown as Collected["results"];
        }
      }
    } catch {
      /* aborted */
    }
  })();
  return out;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function main() {
  const hostId = `p-host${Date.now().toString(36)}`;
  const guestId = `p-guest${Date.now().toString(36)}`;

  console.log("\n[1] Room creation + join");
  const created = (await post("/api/rooms", {
    action: "create",
    playerId: hostId,
    name: "Frank",
  })) as { ok: boolean; token: string; room: { code: string } };
  check("room created", created.ok && !!created.token);
  const code = created.room.code;
  check("room code is 5 chars", /^[A-Z0-9]{5}$/.test(code), code);

  const joined = (await post("/api/rooms", {
    action: "join",
    playerId: guestId,
    name: "Alex",
    code,
  })) as { ok: boolean; token: string; room: { players: unknown[] } };
  check("guest joined", joined.ok && joined.room.players.length === 2);

  const badJoin = (await post("/api/rooms", {
    action: "join",
    playerId: "p-nobody1",
    name: "Nope",
    code: "ZZZZZ",
  })) as { ok: boolean };
  check("unknown room rejected", badJoin.ok === false);

  const badAuth = (await post(`/api/rooms/${code}/action`, {
    action: "start",
    playerId: guestId,
    token: "forged-token",
  })) as { ok: boolean };
  check("forged token rejected", badAuth.ok === false);

  const notHost = (await post(`/api/rooms/${code}/action`, {
    action: "start",
    playerId: guestId,
    token: joined.token,
  })) as { ok: boolean };
  check("non-host cannot start", notHost.ok === false);

  console.log("\n[2] Streams + lobby sync");
  const hostStream = openStream(code, hostId, created.token);
  const guestStream = openStream(code, guestId, joined.token);
  await sleep(600);
  check("host receives lobby state", hostStream.lobby > 0);
  check("guest receives lobby state", guestStream.lobby > 0);

  await post(`/api/rooms/${code}/action`, {
    action: "chat",
    playerId: guestId,
    token: joined.token,
    text: "<script>alert(1)</script> hi",
  });
  const spam = (await post(`/api/rooms/${code}/action`, {
    action: "chat",
    playerId: guestId,
    token: joined.token,
    text: "spam",
  })) as { ok: boolean };
  await sleep(400);
  check("chat delivered to host", hostStream.chat.some((c) => c.includes("hi")));
  check("chat rate limited", spam.ok === false);

  await post(`/api/rooms/${code}/action`, { action: "bot", playerId: hostId, token: created.token });
  await sleep(300);

  console.log("\n[3] Match start + authoritative snapshots");
  const started = (await post(`/api/rooms/${code}/action`, {
    action: "start",
    playerId: hostId,
    token: created.token,
  })) as { ok: boolean };
  check("host started the match", started.ok === true);
  await sleep(1200);
  check("map sent to clients", hostStream.map);
  check("snapshots streaming", hostStream.snaps > 10, `snaps=${hostStream.snaps}`);
  check("guest also receives snapshots", guestStream.snaps > 10, `snaps=${guestStream.snaps}`);

  // drive inputs for a few seconds
  let seq = 1;
  const driver = setInterval(() => {
    void post(`/api/rooms/${code}/action`, {
      action: "input",
      playerId: hostId,
      token: created.token,
      input: { seq: seq++, mx: Math.cos(seq / 9), my: Math.sin(seq / 9), aim: seq / 5, fire: true, dash: false },
    });
  }, 60);
  await sleep(2500);
  const snap = hostStream.lastSnap as unknown as {
    pl: Array<{ i: string; q: number; x: number; h: number }>;
    ph: string;
  };
  const hostPl = snap.pl.find((p) => p.i === hostId)!;
  check("server acks input sequence", hostPl.q > 5, `ack=${hostPl.q}`);
  check("phase is playing", snap.ph === "playing", snap.ph);
  check("hydration drains over time", hostPl.h < 100, `hp=${hostPl.h}`);
  clearInterval(driver);

  console.log("\n[4] Disconnect handling");
  guestStream.stop();
  await sleep(1500);
  const snap2 = hostStream.lastSnap as unknown as { pl: Array<{ i: string; o: number }> };
  check(
    "disconnected player flagged offline",
    snap2.pl.find((p) => p.i === guestId)?.o === 0,
  );
  const rejoin = (await post("/api/rooms", {
    action: "join",
    playerId: guestId,
    name: "Alex",
    code,
  })) as { ok: boolean; token: string };
  check("reconnect issues a fresh token", rejoin.ok && !!rejoin.token);
  const guestStream2 = openStream(code, guestId, rejoin.token);
  await sleep(900);
  check("reconnected client resumes snapshots", guestStream2.snaps > 5, `snaps=${guestStream2.snaps}`);

  console.log("\n[5] Match end + persistence (waiting for the match to resolve…)");
  const deadline = Date.now() + 150_000;
  while (!hostStream.results && Date.now() < deadline) await sleep(1000);
  check("results broadcast", hostStream.results !== null);
  if (hostStream.results) {
    const rows = hostStream.results.rows;
    check("results contain every seat", rows.length === 3, `rows=${rows.length}`);
    check("placement 1 exists", rows.some((r) => r.placement === 1));
    console.log(
      "    final:",
      rows.map((r) => `${r.placement}. ${r.name} ${r.score}`).join(" | "),
    );
  }

  await sleep(1500);
  const board = (await (await fetch(`${BASE}/api/leaderboard`)).json()) as {
    ok: boolean;
    rows: Array<{ name: string }>;
  };
  check("leaderboard reachable", board.ok);
  check("match persisted a profile", board.rows.length > 0, `rows=${board.rows.length}`);

  const profile = (await (
    await fetch(`${BASE}/api/profile?playerId=${hostId}`)
  ).json()) as { ok: boolean; profile: { matches: number } | null };
  check("host profile stored", !!profile.profile && profile.profile.matches >= 1);

  console.log("\n[6] Leave + cleanup");
  await post(`/api/rooms/${code}/action`, {
    action: "leave",
    playerId: hostId,
    token: created.token,
  });
  hostStream.stop();
  guestStream2.stop();
  await sleep(500);

  console.log(failures === 0 ? "\n✅ All network tests passed\n" : `\n❌ ${failures} failed\n`);
  process.exit(failures === 0 ? 0 : 1);
}

void main();
