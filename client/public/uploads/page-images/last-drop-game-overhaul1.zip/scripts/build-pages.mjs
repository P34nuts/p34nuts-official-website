#!/usr/bin/env node
/**
 * Builds the static client bundle for GitHub Pages.
 *
 *   NEXT_PUBLIC_API_BASE=https://your-backend.example.com \
 *   NEXT_PUBLIC_BASE_PATH=/last-drop \
 *   node scripts/build-pages.mjs
 *
 * Output: ./out  (upload this folder to GitHub Pages)
 *
 * The API route handlers are excluded from this build because GitHub Pages
 * cannot run a server - the exported client talks to NEXT_PUBLIC_API_BASE.
 * Solo/practice mode runs completely offline in the browser, so the static
 * build is fully playable even without a backend.
 */
import { cpSync, existsSync, mkdirSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import { execSync } from "node:child_process";
import { join, resolve } from "node:path";

const root = resolve(process.cwd());
const work = join(root, ".pages-build");

if (!process.env.NEXT_PUBLIC_API_BASE) {
  console.warn(
    "\n⚠  NEXT_PUBLIC_API_BASE is not set — the exported build will only support solo play.\n",
  );
}

rmSync(work, { recursive: true, force: true });
mkdirSync(work, { recursive: true });

for (const entry of [
  "src",
  "public",
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "postcss.config.mjs",
  "next.config.ts",
  "eslint.config.mjs",
]) {
  if (existsSync(join(root, entry))) {
    cpSync(join(root, entry), join(work, entry), { recursive: true });
  }
}

// API routes cannot be exported statically
rmSync(join(work, "src/app/api"), { recursive: true, force: true });

// reuse the installed dependencies
try {
  symlinkSync(join(root, "node_modules"), join(work, "node_modules"), "dir");
} catch {
  cpSync(join(root, "node_modules"), join(work, "node_modules"), { recursive: true });
}

execSync("npx next build", {
  cwd: work,
  stdio: "inherit",
  env: { ...process.env, STATIC_EXPORT: "1" },
});

rmSync(join(root, "out"), { recursive: true, force: true });
cpSync(join(work, "out"), join(root, "out"), { recursive: true });
writeFileSync(join(root, "out/.nojekyll"), "");
// SPA style fallback for deep links such as /?room=ABCDE
if (existsSync(join(root, "out/index.html"))) {
  cpSync(join(root, "out/index.html"), join(root, "out/404.html"));
}
rmSync(work, { recursive: true, force: true });

console.log("\n✅ Static client exported to ./out (deploy this to GitHub Pages)\n");
