/**
 * Headless simulation QA.
 * Run with:  npx tsx scripts/sim-test.ts
 * Validates match termination, physics sanity, scoring and input hardening.
 */
import {
  RULES,
  WORLD,
  createMatch,
  encodeSnapshot,
  matchResults,
  sanitizeInput,
  stepMatch,
} from "../src/game/core/sim";
import type { PlayerInput } from "../src/game/core/types";

let failures = 0;
function check(label: string, cond: boolean, extra = "") {
  if (cond) {
    console.log(`  ✓ ${label}`);
  } else {
    failures++;
    console.error(`  ✗ ${label} ${extra}`);
  }
}

function runMatch(bots: number, withHuman: boolean, seed: number) {
  const seats = [
    ...(withHuman ? [{ id: "human", name: "You", isBot: false, colorIndex: 0 }] : []),
    ...Array.from({ length: bots }, (_, i) => ({
      id: `bot_${i}`,
      name: `Bot${i}`,
      isBot: true,
      colorIndex: i + 1,
    })),
  ];
  const state = createMatch(seats, seed);
  const dt = 1 / RULES.tickRate;
  const inputs = new Map<string, PlayerInput>();
  let simTime = 0;
  let outOfBounds = 0;
  let nan = 0;

  while (state.phase !== "ended" && simTime < RULES.countdown + RULES.matchDuration + 10) {
    if (withHuman) {
      // a simple "human": circle strafe + constant fire
      const ang = simTime * 1.4;
      inputs.set("human", {
        seq: Math.floor(simTime * 20),
        mx: Math.cos(ang),
        my: Math.sin(ang),
        aim: ang,
        fire: true,
        dash: Math.random() < 0.01,
      });
    }
    stepMatch(state, dt, inputs);
    state.events = [];
    simTime += dt;
    for (const p of state.players) {
      if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || !Number.isFinite(p.hp)) nan++;
      if (Math.hypot(p.x - WORLD.center, p.y - WORLD.center) > WORLD.radius + 1) outOfBounds++;
    }
  }
  return { state, simTime, outOfBounds, nan };
}

console.log("\n[1] Full match with 7 bots + 1 human");
{
  const { state, simTime, outOfBounds, nan } = runMatch(7, true, 12345);
  check("match reaches ended phase", state.phase === "ended");
  check("exactly one winner", !!state.winnerId);
  check("no NaN state", nan === 0, `nan=${nan}`);
  check("nobody leaves the arena", outOfBounds === 0, `violations=${outOfBounds}`);
  check("match finishes within the time limit", simTime <= RULES.matchDuration + 6, `${simTime.toFixed(1)}s`);
  const rows = matchResults(state);
  check("results row per player", rows.length === 8);
  check("placements start at 1", rows[0].placement === 1);
  check("winner has the top placement", rows[0].playerId === state.winnerId);
  check("scores are finite", rows.every((r) => Number.isFinite(r.score)));
  console.log(
    "    winner:",
    rows[0].name,
    "score",
    rows[0].score,
    "kills",
    rows[0].kills,
    "duration",
    simTime.toFixed(1) + "s",
  );
}

console.log("\n[2] 40 bot-only matches (stability / termination)");
{
  let ended = 0;
  let totalKills = 0;
  let maxTime = 0;
  for (let i = 0; i < 40; i++) {
    const { state, simTime } = runMatch(4, false, 1000 + i * 7);
    if (state.phase === "ended") ended++;
    totalKills += state.players.reduce((a, p) => a + p.kills, 0);
    maxTime = Math.max(maxTime, simTime);
  }
  check("all 40 matches terminated", ended === 40, `${ended}/40`);
  check("bots actually fight (kills > 0)", totalKills > 0, `kills=${totalKills}`);
  check("no match ran past the limit", maxTime <= RULES.matchDuration + 6, `${maxTime.toFixed(1)}s`);
  console.log(`    total bot eliminations across 40 matches: ${totalKills}`);
}

console.log("\n[3] Snapshot encoding");
{
  const state = createMatch([
    { id: "a", name: "A", isBot: false, colorIndex: 0 },
    { id: "b", name: "B", isBot: true, colorIndex: 1 },
  ]);
  for (let i = 0; i < 200; i++) stepMatch(state, 1 / 20, new Map());
  const snap = encodeSnapshot(state);
  const json = JSON.stringify(snap);
  check("snapshot serialises", json.length > 50);
  check("snapshot stays small (<6KB)", json.length < 6000, `${json.length}B`);
  check("players present", snap.pl.length === 2);
  check("pickups present", snap.pu.length > 0);
}

console.log("\n[4] Input hardening");
{
  check("rejects null", sanitizeInput(null) === null);
  check("rejects string", sanitizeInput("hack") === null);
  const evil = sanitizeInput({ seq: 1e30, mx: 999, my: -999, aim: NaN, fire: "yes", dash: 1 });
  check("clamps movement", !!evil && evil.mx === 1 && evil.my === -1);
  check("sanitises NaN aim", !!evil && Number.isFinite(evil.aim));
  check("booleans are strict", !!evil && evil.fire === false && evil.dash === false);
  check("seq is bounded", !!evil && evil.seq <= 1e9);
}

console.log("\n[5] Speed-hack resistance (sim ignores client positions)");
{
  const state = createMatch([
    { id: "a", name: "A", isBot: false, colorIndex: 0 },
    { id: "b", name: "B", isBot: true, colorIndex: 1 },
  ]);
  const start = { x: state.players[0].x, y: state.players[0].y };
  const inputs = new Map<string, PlayerInput>([
    ["a", { seq: 1, mx: 1, my: 0, aim: 0, fire: false, dash: false }],
  ]);
  for (let i = 0; i < 20; i++) stepMatch(state, 1 / 20, inputs);
  const travelled = Math.hypot(state.players[0].x - start.x, state.players[0].y - start.y);
  check(
    "1s of full input moves at most moveSpeed",
    travelled <= RULES.moveSpeed * 1.05,
    `${travelled.toFixed(1)}u`,
  );
}

console.log(
  failures === 0 ? "\n✅ All simulation tests passed\n" : `\n❌ ${failures} test(s) failed\n`,
);
process.exit(failures === 0 ? 0 : 1);
