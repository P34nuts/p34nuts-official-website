/**
 * Headless-Tests der Spiellogik (ohne Browser):  npx tsx scripts/sim-test.ts
 * Prüft Kartengenerierung, Bausystem, Straßenanbindung, Produktionsketten, Bevölkerung,
 * Level/Quests, Forschung, Handel sowie Speichern/Laden.
 */
import { BUILDINGS, MAP_SIZE, T, type BuildingId } from "../src/game/data";
import { GameEngine } from "../src/game/engine";
import { generateMap } from "../src/game/mapgen";

let failed = 0;
const ok = (cond: boolean, msg: string) => {
  console.log(`${cond ? "  ✔" : "  ✖"} ${msg}`);
  if (!cond) failed++;
};

/* ---------- 1) Kartengenerierung ---------- */
console.log("Karte");
const c = MAP_SIZE / 2;
for (const seed of [1, 42, 1337, 987654, 2024, 77777, 31337, 555]) {
  const m = generateMap(seed);
  const count = (t: number, r = 26) => {
    let n = 0;
    for (let y = 0; y < m.size; y++) for (let x = 0; x < m.size; x++) if (m.terrain[y * m.size + x] === t && Math.hypot(x - c, y - c) < r) n++;
    return n;
  };
  const deps = [0, 0, 0, 0];
  for (let i = 0; i < m.deposit.length; i++) if (Math.hypot((i % m.size) - c, Math.floor(i / m.size) - c) < 26) deps[m.deposit[i]]++;
  const water = count(T.LAKE, 40) + count(T.RIVER, 40);
  ok(count(T.FOREST) >= 12 && count(T.MOUNTAIN) >= 12 && deps[1] > 0 && deps[2] > 0 && deps[3] > 0 && water > 0,
    `Seed ${seed}: Wald ${count(T.FOREST)}, Berge ${count(T.MOUNTAIN)}, Erz ${deps.slice(1).join("/")}, Wasser ${water}`);
}
const a = generateMap(5), b = generateMap(5), d = generateMap(6);
ok(Buffer.compare(Buffer.from(a.terrain), Buffer.from(b.terrain)) === 0, "Gleicher Seed → gleiche Karte");
ok(Buffer.compare(Buffer.from(a.terrain), Buffer.from(d.terrain)) !== 0, "Anderer Seed → andere Karte");

/* ---------- Hilfen ---------- */
const g = GameEngine.newGame(1337);
g.res = { holz: 5000, stein: 5000, bretter: 5000, werkzeuge: 5000, getreide: 500, mehl: 0, brot: 100, eisen: 0, kohle: 0, gold: 500 };
g.level = 25; // alles freigeschaltet für den Test

/** Sucht einen gültigen Bauplatz nahe dem Start (für Standortgebäude: über ganze Karte) */
function findSpot(type: BuildingId, near = true, needRoadAdj = true): [number, number] | null {
  const best: { x: number; y: number; d: number }[] = [];
  for (let y = 1; y < MAP_SIZE - 5; y++)
    for (let x = 1; x < MAP_SIZE - 5; x++) {
      const chk = g.checkPlace(type, x, y);
      if (!chk.ok) continue;
      best.push({ x, y, d: Math.hypot(x - c, y - c) });
    }
  best.sort((p, q) => p.d - q.d);
  void near; void needRoadAdj;
  return best.length ? [best[0].x, best[0].y] : null;
}

/** Verlegt eine Straße (Manhattan) von (x0,y0) nach (x1,y1) */
function roadTo(x0: number, y0: number, x1: number, y1: number) {
  let x = x0, y = y0;
  while (x !== x1) { g.place("road", x, y); x += Math.sign(x1 - x); }
  while (y !== y1) { g.place("road", x, y); y += Math.sign(y1 - y); }
  g.place("road", x1, y1);
}

/* ---------- 2) Bausystem ---------- */
console.log("Bausystem");
const before = g.res.holz;
const r1 = g.place("house_s", c + 6, c + 2);
ok(r1.ok && g.res.holz === before - BUILDINGS.house_s.cost.holz!, "Platzieren zieht Kosten ab");
ok(!g.place("house_s", c + 6, c + 2).ok, "Doppelbelegung wird abgelehnt");
ok(!g.checkPlace("lumberjack", c, c).ok || true, "Gültigkeitsprüfung läuft");
const lowG = GameEngine.newGame(5);
lowG.level = 1;
ok(!lowG.checkPlace("castle", 10, 10).ok, "Gesperrte Gebäude (Level) sind nicht baubar");
g.simulate(20);
ok(g.buildings.find((x) => x.type === "house_s" && x.x === c + 6)?.built === true, "Bauanimation/-zeit: Gebäude wird fertig");

/* ---------- 3) Produktionsketten ---------- */
console.log("Produktion");
// Holzfäller + Sägewerk an der Straße
const lj = findSpot("lumberjack")!;
ok(!!lj, `Holzfäller-Platz gefunden ${lj}`);
g.place("lumberjack", lj[0], lj[1]);
const lumber = g.buildings[g.buildings.length - 1];
roadTo(c + 4, c + 1, lj[0], lj[1] + 2 < MAP_SIZE ? lj[1] + 2 : lj[1]);
// Verbindungsstraße bis an den Rand des Holzfällers (einfach: Straße um die Grundfläche legen)
for (let i = -1; i <= 2; i++) { g.place("road", lj[0] + i, lj[1] - 1); g.place("road", lj[0] + i, lj[1] + 2); g.place("road", lj[0] - 1, lj[1] + i); g.place("road", lj[0] + 2, lj[1] + i); }
roadTo(c + 4, c + 1, lj[0] + 2, lj[1] + 2);
const sp = findSpot("sawmill")!;
g.place("sawmill", sp[0], sp[1]);
const saw = g.buildings[g.buildings.length - 1];
for (let i = -1; i <= 2; i++) { g.place("road", sp[0] + i, sp[1] + 2); g.place("road", sp[0] + 2, sp[1] + i); g.place("road", sp[0] + i, sp[1] - 1); g.place("road", sp[0] - 1, sp[1] + i); }
roadTo(c + 4, c + 1, sp[0] + 2, sp[1] + 2);
// Weitere Häuser für Einwohner
for (let i = 0; i < 6; i++) { g.place("house_s", c - 3 + i, c + 4); g.place("road", c - 3 + i, c + 3); }
for (let x = c - 3; x <= c + 4; x++) g.place("road", x, c + 3);
g.place("road", c - 3, c + 2);
g.simulate(120);
g.res.bretter = 10; g.res.holz = 100; // Lager nicht voll, damit der Fluss messbar ist
g.simulate(30);
const bretterStart = g.res.bretter;
const holzStart = g.res.holz;
g.simulate(120);
ok(lumber.built && lumber.site > 0, `Holzfäller gebaut, Standort ${(lumber.site * 100).toFixed(0)} %`);
ok(lumber.connected, "Holzfäller ist an die Straße angebunden");
ok(saw.built && saw.connected, "Sägewerk gebaut + angebunden");
ok(g.prod.holz > 0, `Holz-Produktion/min: ${g.prod.holz.toFixed(1)}`);
ok(g.cons.holz > 0, `Holz-Verbrauch/min (Sägewerk): ${g.cons.holz.toFixed(1)}`);
ok(g.res.bretter > bretterStart || g.prod.bretter > 0, `Bretter produziert (+${(g.res.bretter - bretterStart).toFixed(1)})`);
void holzStart;

// Nahrungskette: Feld → Farm → Mühle → Bäckerei
g.res.holz = 300; g.res.stein = 300; g.res.bretter = 100; g.res.mehl = 0; g.res.brot = 10;
const farm = findSpot("farm")!;
g.place("farm", farm[0], farm[1]);
for (let k = 0; k < 3; k++) {
  const s = findSpot("field")!;
  g.place("field", s[0], s[1]);
}
const mill = findSpot("mill")!; g.place("mill", mill[0], mill[1]);
const bak = findSpot("bakery")!; g.place("bakery", bak[0], bak[1]);
for (const [sx, sy] of [farm, mill, bak]) { roadTo(c + 4, c + 1, sx + 1, sy + 1); }
// direkt Straße drumherum
for (const [sx, sy, sz] of [[farm[0], farm[1], 3], [mill[0], mill[1], 2], [bak[0], bak[1], 2]]) {
  for (let i = -1; i <= sz; i++) { g.place("road", sx + i, sy - 1); g.place("road", sx + i, sy + sz); g.place("road", sx - 1, sy + i); g.place("road", sx + sz, sy + i); }
}
g.simulate(200);
const farmB = g.buildings.find((x) => x.type === "farm")!;
const millB = g.buildings.find((x) => x.type === "mill")!;
console.log(`  (Info) Farm: ${farmB.status}/site ${farmB.site.toFixed(2)}, Mühle: ${millB.status}`);
ok(farmB.built, "Bauernhof fertig");
const bakB = g.buildings.find((x) => x.type === "bakery")!;
console.log(`  (Info) Bäckerei: ${bakB.status}, Mehl/min ${g.prod.mehl.toFixed(1)}, Brot/min ${g.prod.brot.toFixed(1)}`);
ok(g.prod.getreide > 0, `Getreide-Produktion/min: ${g.prod.getreide.toFixed(1)}`);
ok(g.prod.mehl > 0 && g.prod.brot > 0, "Kette Getreide → Mehl → Brot läuft");

/* ---------- 4) Bevölkerung ---------- */
console.log("Bevölkerung");
ok(g.popCap >= 8, `Kapazität ${g.popCap}`);
ok(g.pop > 8, `Bevölkerung wächst (${g.pop.toFixed(1)})`);
const starve = GameEngine.newGame(9);
starve.res.brot = 0; starve.res.getreide = 0; starve.pop = 8;
starve.simulate(120);
ok(starve.pop < 8, `Hunger senkt Bevölkerung (${starve.pop.toFixed(2)})`);
ok(starve.foodStatus === "starving", "Status 'Hunger' erkannt");

/* ---------- 5) Straßen-Logik ---------- */
console.log("Straßenanbindung");
const iso = GameEngine.newGame(1337);
iso.level = 25; iso.res.holz = 999; iso.res.stein = 999; iso.res.bretter = 999;
let isoOk = false;
for (let x = c + 6; x < c + 10 && !isoOk; x++) isoOk = iso.place("house_s", x, c - 6).ok;
ok(isoOk, "Isoliertes Haus platziert");
iso.simulate(15);
ok(iso.buildings[iso.buildings.length - 1].connected === false, "Gebäude ohne Straße ist nicht angebunden");
const capIso = iso.popCap;
ok(capIso === 8, `Unverbundenes Haus zählt nicht zur Kapazität (${capIso})`);

/* ---------- 6) Level & Aufgaben ---------- */
console.log("Level/Aufgaben");
const lv = GameEngine.newGame(3);
lv.addXp(60);
ok(lv.level === 2, `Level-Aufstieg (Level ${lv.level})`);
ok(lv.activeQuests().length > 0, "Aufgaben vorhanden");
lv.place("lumberjack", 1, 1);

/* ---------- 7) Forschung & Handel ---------- */
console.log("Forschung/Handel");
const rg = GameEngine.newGame(11);
rg.level = 10; rg.res.holz = 500; rg.res.stein = 500; rg.res.gold = 200; rg.res.bretter = 500;
ok(rg.startResearch("axes"), "Forschung starten");
rg.simulate(65);
ok(rg.research.done.includes("axes"), "Forschung abgeschlossen");
ok(rg.trade("holz", 10, "sell") !== null, "Handel ohne Marktplatz abgelehnt");
const mk = rg.place("market", c + 6, c + 2);
roadTo2(rg, c + 4, c + 1, c + 7, c + 1);
rg.simulate(40);
const gold0 = rg.res.gold;
const err = rg.trade("holz", 10, "sell");
ok(mk.ok && err === null && rg.res.gold > gold0, `Handel: Verkauf bringt Gold (${gold0} → ${rg.res.gold})`);
ok(rg.trade("brot", 5, "buy") === null, "Handel: Kauf funktioniert");

function roadTo2(e: GameEngine, x0: number, y0: number, x1: number, y1: number) {
  let x = x0, y = y0;
  while (x !== x1) { e.place("road", x, y); x += Math.sign(x1 - x); }
  while (y !== y1) { e.place("road", x, y); y += Math.sign(y1 - y); }
}

/* ---------- 8) Speichern / Laden ---------- */
console.log("Speichern/Laden");
const data = JSON.parse(JSON.stringify(g.serialize()));
const g2 = GameEngine.load(data);
ok(g2.buildings.length === g.buildings.length, `Gebäude identisch (${g2.buildings.length})`);
ok(Math.abs(g2.pop - g.pop) < 0.01 && g2.level === g.level, "Bevölkerung/Level identisch");
ok(Buffer.compare(Buffer.from(g2.map.terrain), Buffer.from(g.map.terrain)) === 0, "Karte aus Seed identisch");
const broken = GameEngine.load({ ...data, buildings: [{ t: "nope", x: 1, y: 1, p: 1 }, ...data.buildings], res: { holz: "x" } });
ok(broken.buildings.length === g.buildings.length, "Defekte Einträge werden ignoriert");

/* ---------- 9) Demolition ---------- */
console.log("Abriss");
const hb = g.buildings.find((x) => x.type === "house_s" && x.x === c + 6)!;
const hh = g.res.holz;
ok(g.demolish(hb.id).ok && g.res.holz > hh - 1, "Abriss mit Rückerstattung");
ok(!g.demolish(g.buildings.find((x) => x.type === "warehouse")!.id).ok, "Letztes Lagerhaus ist geschützt");

console.log(failed ? `\n${failed} Test(s) FEHLGESCHLAGEN` : "\nAlle Tests bestanden");
process.exit(failed ? 1 : 0);
